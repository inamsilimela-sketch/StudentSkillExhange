package com.mycompany.studentskillexchange.servlet;

import com.mycompany.studentskillexchange.model.User;
import com.mycompany.studentskillexchange.utils.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;

@WebServlet("/MessageServlet")
public class MessageServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"error\":\"Not logged in\"}");
            return;
        }

        User currentUser = (User) session.getAttribute("user");
        String otherIdParam = request.getParameter("otherId");

        if (otherIdParam == null) {
            fetchConversations(currentUser.getId(), out);
            return;
        }

        int otherId;
        try {
            otherId = Integer.parseInt(otherIdParam);
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("[]");
            return;
        }

        markAsRead(currentUser.getId(), otherId);

        String sql =
            "SELECT id, sender_id, message, is_read, sent_at " +
            "FROM messages " +
            "WHERE (sender_id = ? AND receiver_id = ?) " +
            "   OR (sender_id = ? AND receiver_id = ?) " +
            "ORDER BY sent_at ASC";

        SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm");
        SimpleDateFormat dateFmt = new SimpleDateFormat("yyyy-MM-dd");
        timeFmt.setTimeZone(java.util.TimeZone.getDefault());
        dateFmt.setTimeZone(java.util.TimeZone.getDefault());

        StringBuilder json = new StringBuilder("[");
        boolean first = true;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, currentUser.getId());
            ps.setInt(2, otherId);
            ps.setInt(3, otherId);
            ps.setInt(4, currentUser.getId());

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                if (!first) json.append(",");
                first = false;

                boolean isSent = rs.getInt("sender_id") == currentUser.getId();
                java.sql.Timestamp ts = rs.getTimestamp("sent_at");
                String time = ts != null ? timeFmt.format(ts) : "00:00";
                String date = ts != null ? dateFmt.format(ts) : "";
                String text = rs.getString("message")
                        .replace("\\", "\\\\")
                        .replace("\"", "\\\"")
                        .replace("\n", "\\n")
                        .replace("\r", "");

                json.append("{")
                    .append("\"id\":").append(rs.getInt("id")).append(",")
                    .append("\"from\":\"").append(isSent ? "me" : "them").append("\",")
                    .append("\"text\":\"").append(text).append("\",")
                    .append("\"time\":\"").append(time).append("\",")
                    .append("\"date\":\"").append(date).append("\",")
                    .append("\"read\":").append(rs.getBoolean("is_read"))
                    .append("}");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("[]");
            return;
        }

        json.append("]");
        out.print(json.toString());
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"success\":false,\"message\":\"Not logged in\"}");
            return;
        }

        User currentUser = (User) session.getAttribute("user");
        String receiverIdParam = request.getParameter("receiverId");
        String messageText = request.getParameter("message");

        if (receiverIdParam == null || messageText == null || messageText.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"success\":false,\"message\":\"Missing fields\"}");
            return;
        }

        int receiverId;
        try {
            receiverId = Integer.parseInt(receiverIdParam);
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"success\":false,\"message\":\"Invalid receiver\"}");
            return;
        }

        if (receiverId == currentUser.getId()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"success\":false,\"message\":\"Cannot message yourself\"}");
            return;
        }

        String sql = "INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, currentUser.getId());
            ps.setInt(2, receiverId);
            ps.setString(3, messageText.trim());
            ps.executeUpdate();

            out.print("{\"success\":true}");

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"success\":false,\"message\":\"Database error\"}");
        }
    }

    private void fetchConversations(int userId, PrintWriter out) {
        String sql =
            "SELECT u.id, u.name, " +
            "       MAX(m.sent_at) AS last_time, " +
            "       SUBSTRING_INDEX(GROUP_CONCAT(m.message ORDER BY m.sent_at DESC SEPARATOR '||'), '||', 1) AS last_message, " +
            "       SUM(CASE WHEN m.receiver_id = ? AND m.is_read = FALSE THEN 1 ELSE 0 END) AS unread_count " +
            "FROM users u " +
            "JOIN messages m ON (m.sender_id = u.id AND m.receiver_id = ?) " +
            "               OR (m.sender_id = ? AND m.receiver_id = u.id) " +
            "WHERE u.id != ? " +
            "GROUP BY u.id, u.name " +
            "ORDER BY MAX(m.sent_at) DESC";

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        sdf.setTimeZone(java.util.TimeZone.getDefault());
        StringBuilder json = new StringBuilder("[");
        boolean first = true;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, userId);
            ps.setInt(3, userId);
            ps.setInt(4, userId);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                if (!first) json.append(",");
                first = false;

                String name = rs.getString("name");
                String[] parts = name.trim().split("\\s+");
                String initials = parts.length >= 2
                    ? "" + parts[0].charAt(0) + parts[parts.length - 1].charAt(0)
                    : "" + parts[0].charAt(0);

                String lastMsg = rs.getString("last_message");
                if (lastMsg == null) lastMsg = "";
                lastMsg = lastMsg.replace("\\", "\\\\").replace("\"", "\\\"");
                if (lastMsg.length() > 60) lastMsg = lastMsg.substring(0, 60) + "...";

                java.sql.Timestamp ts = rs.getTimestamp("last_time");
                String time = ts != null ? sdf.format(ts) : "";
                String safeName = name.replace("\"", "\\\"");

                json.append("{")
                    .append("\"id\":").append(rs.getInt("id")).append(",")
                    .append("\"name\":\"").append(safeName).append("\",")
                    .append("\"initials\":\"").append(initials.toUpperCase()).append("\",")
                    .append("\"lastMsg\":\"").append(lastMsg).append("\",")
                    .append("\"time\":\"").append(time).append("\",")
                    .append("\"unread\":").append(rs.getInt("unread_count"))
                    .append("}");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
            return;
        }

        json.append("]");
        out.print(json.toString());
    }

    private void markAsRead(int currentUserId, int senderId) {
        String sql = "UPDATE messages SET is_read = TRUE " +
                     "WHERE sender_id = ? AND receiver_id = ? AND is_read = FALSE";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, senderId);
            ps.setInt(2, currentUserId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
