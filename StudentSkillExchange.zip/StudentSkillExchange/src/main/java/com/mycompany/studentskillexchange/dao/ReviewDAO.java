package com.mycompany.studentskillexchange.dao;

import com.mycompany.studentskillsexchange.model.Review;
import com.mycompany.studentskillexchange.utils.DBConnection;
import java.sql.*;
import java.util.*;

public class ReviewDAO {

    // Add a new review
    public boolean addReview(Review review) {
        String sql = "INSERT INTO reviews(skill_id, user_id, comment, rating) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, review.getSkillId());
            ps.setInt(2, review.getUserId());
            ps.setString(3, review.getComment());
            ps.setInt(4, review.getRating());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Fetch all reviews for a skill
    public List<Review> getReviewsBySkill(int skillId) {
        List<Review> reviews = new ArrayList<>();
        String sql = "SELECT * FROM reviews WHERE skill_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, skillId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Review review = new Review();
                review.setId(rs.getInt("id"));
                review.setSkillId(rs.getInt("skill_id"));
                review.setUserId(rs.getInt("user_id"));
                review.setComment(rs.getString("comment"));
                review.setRating(rs.getInt("rating"));
                reviews.add(review);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return reviews;
    }
}
