package com.mycompany.studentskillexchange.servlet;

import com.mycompany.studentskillexchange.model.User;
import com.mycompany.studentskillexchange.utils.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/ViewProfileServlet")
public class ViewProfileServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String userIdParam = request.getParameter("userId");
        if (userIdParam == null) {
            response.sendRedirect("BrowseServlet");
            return;
        }

        int targetUserId;
        try {
            targetUserId = Integer.parseInt(userIdParam);
        } catch (NumberFormatException e) {
            response.sendRedirect("BrowseServlet");
            return;
        }

        // Load the target user's full profile from DB
        String sql = "SELECT id, name, role, bio, portfolio_photos, created_at FROM users WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, targetUserId);
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                response.sendRedirect("BrowseServlet");
                return;
            }

            // Build profile data
            User profileUser = new User();
            profileUser.setId(rs.getInt("id"));
            profileUser.setName(rs.getString("name"));
            profileUser.setRole(rs.getString("role"));
            profileUser.setBio(rs.getString("bio"));
            profileUser.setPortfolio(rs.getString("portfolio_photos"));

            if (rs.getTimestamp("created_at") != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("MMMM yyyy");
                profileUser.setJoinDate(sdf.format(rs.getTimestamp("created_at")));
            }

            // Load skills
            List<String> skills = new ArrayList<>();
            String skillSql = "SELECT skill_name FROM user_skills WHERE user_id = ? ORDER BY created_at ASC";
            try (PreparedStatement ps2 = conn.prepareStatement(skillSql)) {
                ps2.setInt(1, targetUserId);
                ResultSet rs2 = ps2.executeQuery();
                while (rs2.next()) {
                    skills.add(rs2.getString("skill_name"));
                }
            }
            
            // Increment profile views (don't count own profile)
            User loggedIn = (User) request.getSession().getAttribute("user");
            if (loggedIn.getId() != targetUserId) {
                String viewSql = "UPDATE users SET profile_views = profile_views + 1 WHERE id = ?";
                try (PreparedStatement pv = conn.prepareStatement(viewSql)) {
                     pv.setInt(1, targetUserId);
                     pv.executeUpdate();
                }
            }
            request.setAttribute("profileUser", profileUser);
            request.setAttribute("profileSkills", skills);
            request.getRequestDispatcher("Viewprofile.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("BrowseServlet");
        }
    }
}