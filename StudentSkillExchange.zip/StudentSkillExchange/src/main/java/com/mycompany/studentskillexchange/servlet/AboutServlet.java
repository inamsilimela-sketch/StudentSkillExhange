package com.mycompany.studentskillexchange.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AboutServlet")
public class AboutServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Example dynamic data (you can later get this from database)
        int totalUsers = 120;
        int totalSkills = 45;
        int totalRequests = 80;

        // Send data to JSP
        request.setAttribute("totalUsers", totalUsers);
        request.setAttribute("totalSkills", totalSkills);
        request.setAttribute("totalRequests", totalRequests);

        // Forward to about.jsp
        request.getRequestDispatcher("About.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}