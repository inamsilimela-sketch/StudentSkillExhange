/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentskillexchange.dao;

import com.mycompany.studentskillexchange.model.Notification;
import com.mycompany.studentskillexchange.utils.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NotificationDAO {
    
    private Connection getConnection() throws SQLException {
        return DBConnection.getConnection();
    }
    
    // Create a notification
    public boolean createNotification(int userId, int actorId, String type, 
                                      int referenceId, String message) {
        String sql = "INSERT INTO notifications (user_id, actor_id, type, reference_id, message) " +
                     "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            stmt.setInt(2, actorId);
            stmt.setString(3, type);
            stmt.setInt(4, referenceId);
            stmt.setString(5, message);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Get notifications for a user with pagination
    public Map<String, Object> getNotifications(int userId, int page, int limit) {
        Map<String, Object> result = new HashMap<>();
        List<Notification> notifications = new ArrayList<>();
        int offset = (page - 1) * limit;
        
        String sql = "SELECT n.*, u.name as actor_name " +
                     "FROM notifications n " +
                     "LEFT JOIN users u ON n.actor_id = u.id " +
                     "WHERE n.user_id = ? " +
                     "ORDER BY n.created_at DESC " +
                     "LIMIT ? OFFSET ?";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            stmt.setInt(2, limit);
            stmt.setInt(3, offset);
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Notification notif = new Notification();
                notif.setId(rs.getInt("id"));
                notif.setUserId(rs.getInt("user_id"));
                notif.setActorId(rs.getInt("actor_id"));
                notif.setActorName(rs.getString("actor_name"));
                notif.setType(rs.getString("type"));
                notif.setReferenceId(rs.getInt("reference_id"));
                notif.setMessage(rs.getString("message"));
                notif.setRead(rs.getBoolean("is_read"));
                notif.setCreatedAt(rs.getTimestamp("created_at"));
                notifications.add(notif);
            }
            
            // Get total count
            String countSql = "SELECT COUNT(*) as total FROM notifications WHERE user_id = ?";
            try (PreparedStatement countStmt = conn.prepareStatement(countSql)) {
                countStmt.setInt(1, userId);
                ResultSet countRs = countStmt.executeQuery();
                if (countRs.next()) {
                    int total = countRs.getInt("total");
                    result.put("total", total);
                    result.put("pages", (int) Math.ceil((double) total / limit));
                    result.put("hasMore", (page * limit) < total);
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        result.put("notifications", notifications);
        result.put("page", page);
        return result;
    }
    
    // Get unread count
    public int getUnreadCount(int userId) {
        String sql = "SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    // Get notification summary by type
    public Map<String, Integer> getNotificationSummary(int userId) {
        Map<String, Integer> summary = new HashMap<>();
        String sql = "SELECT type, COUNT(*) as count FROM notifications " +
                     "WHERE user_id = ? AND is_read = 0 GROUP BY type";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                summary.put(rs.getString("type"), rs.getInt("count"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return summary;
    }
    
    // Mark as read
    public boolean markAsRead(int notificationId, int userId) {
        String sql = "UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, notificationId);
            stmt.setInt(2, userId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Mark all as read
    public boolean markAllAsRead(int userId) {
        String sql = "UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Delete notification
    public boolean deleteNotification(int notificationId, int userId) {
        String sql = "DELETE FROM notifications WHERE id = ? AND user_id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, notificationId);
            stmt.setInt(2, userId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // ===== SPECIFIC NOTIFICATION TRIGGERS =====
    
    // Notify about new message
    public void notifyNewMessage(int receiverId, int senderId, int messageId, String preview) {
        String senderName = getUserName(senderId);
        String message = "New message from " + senderName;
        if (preview != null && !preview.isEmpty()) {
            message += ": " + (preview.length() > 60 ? preview.substring(0, 60) + "..." : preview);
        }
        createNotification(receiverId, senderId, "message", messageId, message);
    }
    
    // Notify about new rating/review
    public void notifyNewRating(int ratedUserId, int ratedById, int ratingId, int rating) {
        String raterName = getUserName(ratedById);
        String message = raterName + " left you a " + rating + "-star review ⭐";
        createNotification(ratedUserId, ratedById, "review", ratingId, message);
    }
    
    // Notify about new comment
    public void notifyNewComment(int profileOwnerId, int commenterId, int commentId, String preview) {
        String commenterName = getUserName(commenterId);
        String message = commenterName + " commented on your profile";
        if (preview != null && !preview.isEmpty()) {
            message += ": \"" + (preview.length() > 50 ? preview.substring(0, 50) + "..." : preview) + "\"";
        }
        createNotification(profileOwnerId, commenterId, "comment", commentId, message);
    }
    
    // Notify about profile view
    public void notifyProfileView(int viewedUserId, int viewerId) {
        // Don't notify if viewing own profile
        if (viewedUserId == viewerId) return;
        
        // Check if already viewed recently (within 3 hours)
        String checkSql = "SELECT COUNT(*) as count FROM profile_views_history " +
                         "WHERE viewer_id = ? AND viewed_user_id = ? " +
                         "AND viewed_at > DATE_SUB(NOW(), INTERVAL 3 HOUR)";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(checkSql)) {
            
            stmt.setInt(1, viewerId);
            stmt.setInt(2, viewedUserId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next() && rs.getInt("count") > 0) {
                // Already viewed recently, just update timestamp
                String updateSql = "UPDATE profile_views_history SET viewed_at = NOW() " +
                                  "WHERE viewer_id = ? AND viewed_user_id = ? " +
                                  "ORDER BY viewed_at DESC LIMIT 1";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setInt(1, viewerId);
                    updateStmt.setInt(2, viewedUserId);
                    updateStmt.executeUpdate();
                }
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        // Record the view
        String insertSql = "INSERT INTO profile_views_history (viewer_id, viewed_user_id) VALUES (?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(insertSql)) {
            stmt.setInt(1, viewerId);
            stmt.setInt(2, viewedUserId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        // Update profile views counter
        String updateCounterSql = "UPDATE users SET profile_views = profile_views + 1 WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(updateCounterSql)) {
            stmt.setInt(1, viewedUserId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        // Create notification
        String viewerName = getUserName(viewerId);
        String message = viewerName + " viewed your profile 👀";
        createNotification(viewedUserId, viewerId, "profile_view", 0, message);
    }
    
    // Helper: Get user name
    private String getUserName(int userId) {
        String sql = "SELECT name FROM users WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Someone";
    }
}
