package com.mycompany.studentskillexchange.dao;

import com.mycompany.studentskillexchange.model.Skill;
import java.sql.*;
import java.util.*;

public class SkillDAO {
    private Connection conn;

    public SkillDAO(Connection conn) {
        this.conn = conn;
    }

    public SkillDAO() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<Skill> getAllSkills() throws SQLException {
        List<Skill> skills = new ArrayList<>();
        String sql = "SELECT s.id, s.name, s.description, u.name AS ownerName, u.id AS ownerId " +
                     "FROM skills s JOIN users u ON s.owner_id = u.id";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Skill skill = new Skill();
            skill.setId(rs.getInt("id"));
            skill.setName(rs.getString("name"));
            skill.setDescription(rs.getString("description"));
            skill.setOwnerName(rs.getString("ownerName"));
            skill.setOwnerId(rs.getInt("ownerId"));
            skills.add(skill);
        }
        return skills;
    }

    public void addSkill(Skill skill) throws SQLException {
        String sql = "INSERT INTO skills (name, description, owner_id) VALUES (?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, skill.getName());
        ps.setString(2, skill.getDescription());
        ps.setInt(3, skill.getOwnerId());
        ps.executeUpdate();
    }
}
