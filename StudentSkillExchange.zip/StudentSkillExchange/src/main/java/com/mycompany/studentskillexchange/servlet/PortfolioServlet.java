/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.studentskillexchange.servlet;

import com.mycompany.studentskillexchange.model.User;
import com.mycompany.studentskillexchange.utils.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;


@WebServlet("/PortfolioServlet")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,      // 1MB
    maxFileSize       = 5 * 1024 * 1024,  // 5MB per file
    maxRequestSize    = 10 * 1024 * 1024  // 10MB total
)
public class PortfolioServlet extends HttpServlet {

    // Folder where uploaded photos are saved (inside your web app)
    private static final String UPLOAD_DIR = "portfolio_uploads";

    // ── POST: upload a photo OR remove a photo ─────────────────────────────
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"success\":false,\"message\":\"Not logged in\"}");
            return;
        }

        User user = (User) session.getAttribute("user");
        String action = request.getParameter("action");

        if ("remove".equals(action)) {
            removePhoto(request, response, user, out);
        } else {
            uploadPhoto(request, response, user, out);
        }
    }

    // ── Upload a new photo ─────────────────────────────────────────────────
    private void uploadPhoto(HttpServletRequest request, HttpServletResponse response,
                             User user, PrintWriter out) throws ServletException, IOException {

        Part filePart = request.getPart("photo");
        if (filePart == null || filePart.getSize() == 0) {
            out.print("{\"success\":false,\"message\":\"No file selected\"}");
            return;
        }

        // Validate file type
        String contentType = filePart.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            out.print("{\"success\":false,\"message\":\"Only image files are allowed\"}");
            return;
        }

        // Get current photos and check limit
        List<String> photos = getUserPhotos(user.getId());
        if (photos.size() >= 6) {
            out.print("{\"success\":false,\"message\":\"Maximum 6 photos allowed\"}");
            return;
        }

        // Create upload directory if it doesn't exist
        String uploadPath = "C:\\Users\\User\\sse_uploads";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdirs();

        // Generate unique filename
        String originalName = filePart.getSubmittedFileName();
        String extension    = originalName.substring(originalName.lastIndexOf('.'));
        String fileName     = "user_" + user.getId() + "_" + UUID.randomUUID().toString() + extension;
        String filePath     = uploadPath + File.separator + fileName;

        // Save file to disk
try (java.io.InputStream input = filePart.getInputStream();
     java.io.FileOutputStream fos = new java.io.FileOutputStream(filePath)) {
    byte[] buffer = new byte[4096];
    int bytesRead;
    while ((bytesRead = input.read(buffer)) != -1) {
        fos.write(buffer, 0, bytesRead);
    }
}

        // Save relative URL to DB
        String photoUrl = "PhotoServlet?file=" + fileName;
        photos.add(photoUrl);
        savePhotos(user.getId(), photos);

        // Update session
        user.setPortfolio(String.join(",", photos));
        request.getSession().setAttribute("user", user);

        out.print("{\"success\":true,\"url\":\"" + photoUrl + "\"}");
    }

    // ── Remove a photo ─────────────────────────────────────────────────────
    private void removePhoto(HttpServletRequest request, HttpServletResponse response,
                             User user, PrintWriter out) throws IOException {

        String photoUrl = request.getParameter("url");
        if (photoUrl == null || photoUrl.trim().isEmpty()) {
            out.print("{\"success\":false,\"message\":\"No photo specified\"}");
            return;
        }

        // Security: only allow removing files that belong to this user
        String fileName = photoUrl.replace("PhotoServlet?file=", "");
        if (!fileName.startsWith("user_" + user.getId() + "_")) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"success\":false,\"message\":\"Not allowed\"}");
            return;
        }

        // Remove from DB list
        List<String> photos = getUserPhotos(user.getId());
        photos.remove(photoUrl.trim());
        savePhotos(user.getId(), photos);

        // Delete file from disk
        String fullPath = getServletContext().getRealPath("") + File.separator +
                          UPLOAD_DIR + File.separator + fileName;
        new File(fullPath).delete();

        // Update session
        user.setPortfolio(photos.isEmpty() ? null : String.join(",", photos));
        request.getSession().setAttribute("user", user);

        out.print("{\"success\":true}");
    }

    // ── Get user's current photos from DB ──────────────────────────────────
    private List<String> getUserPhotos(int userId) {
        String sql = "SELECT portfolio_photos FROM users WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String csv = rs.getString("portfolio_photos");
                if (csv != null && !csv.trim().isEmpty()) {
                    return new ArrayList<>(Arrays.asList(csv.split(",")));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    // ── Save photos list back to DB ────────────────────────────────────────
    private void savePhotos(int userId, List<String> photos) {
        String csv = photos.isEmpty() ? null : String.join(",", photos);
        String sql = "UPDATE users SET portfolio_photos = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, csv);
            ps.setInt(2, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
