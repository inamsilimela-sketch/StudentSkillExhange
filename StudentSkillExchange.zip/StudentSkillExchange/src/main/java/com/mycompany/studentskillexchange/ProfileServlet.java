/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.studentskillexchange;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import com.mycompany.studentskillexchange.utils.DBConnection;



@MultipartConfig
@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String username = (String) request.getSession().getAttribute("username");
        String action = request.getParameter("action");
        
        if (username == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            Connection conn = DBConnection.getConnection();

            if ("addSkill".equals(action)) {
                String skill = request.getParameter("skill");

                String sql = "UPDATE users SET skills = CONCAT(IFNULL(skills,''), ?, ', ') WHERE username=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, skill);
                ps.setString(2, username);
                ps.executeUpdate();
            }

            else if ("saveDescription".equals(action)) {
                String description = request.getParameter("description");

                String sql = "UPDATE users SET description=? WHERE username=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, description);
                ps.setString(2, username);
                ps.executeUpdate();
            }

            else if ("uploadImages".equals(action)) {
                Part filePart = request.getPart("images");
                if (filePart != null && filePart.getSize() > 0) {
                    String fileName = filePart.getSubmittedFileName();

                    String uploadPath = getServletContext().getRealPath("") + "uploads/";

                    java.io.File uploadDir = new java.io.File(uploadPath);
                    if (!uploadDir.exists()) uploadDir.mkdir();

                    filePart.write(uploadPath + fileName);
                }
            }

            response.sendRedirect("profile.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}