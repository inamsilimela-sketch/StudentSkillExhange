package com.mycompany.studentskillexchange.servlet;

import com.mycompany.studentskillexchange.model.User;
import com.mycompany.studentskillexchange.utils.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/NotificationServlet")
public class NotificationServlet extends HttpServlet {

    // ── GET: fetch notifications or badge count ──────────────────────────────
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        User user = (User) req.getSession().getAttribute("user");
        if (user == null) {
            out.print("{\"error\":\"not logged in\"}");
            return;
        }

        String action = req.getParameter("action");

        // ── Mark all as read ─────────────────────────────────────────────────
        if ("markRead".equals(action)) {
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "UPDATE notifications SET is_read = TRUE WHERE user_id = ?")) {
                ps.setInt(1, user.getId());
                ps.executeUpdate();
                out.print("{\"success\":true}");
            } catch (SQLException e) {
                e.printStackTrace();
                out.print("{\"error\":\"db error\"}");
            }
            return;
        }
        
if ("markSeen".equals(action)) {
    String notifId = req.getParameter("id");
    if (notifId != null) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                 "UPDATE notifications SET is_read = TRUE WHERE id = ? AND user_id = ?")) {
            ps.setInt(1, Integer.parseInt(notifId));
            ps.setInt(2, user.getId());
            ps.executeUpdate();
            out.print("{\"success\":true}");
        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{\"error\":\"db error\"}");
        }
    }
    return;
}

        // ── Badge count only (for nav polling) ───────────────────────────────
        if ("count".equals(action)) {
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = FALSE")) {
                ps.setInt(1, user.getId());
                ResultSet rs = ps.executeQuery();
                int count = rs.next() ? rs.getInt(1) : 0;
                out.print("{\"unread\":" + count + "}");
            } catch (SQLException e) {
                e.printStackTrace();
                out.print("{\"unread\":0}");
            }
            return;
        }

        // ── Fetch all notifications ───────────────────────────────────────────
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT id, type, message, is_read, link, created_at " +
                     "FROM notifications WHERE user_id = ? " +
                     "ORDER BY created_at DESC LIMIT 50")) {

            ps.setInt(1, user.getId());
            ResultSet rs = ps.executeQuery();

            StringBuilder json = new StringBuilder("{\"notifications\":[");
            int unread = 0;
            boolean first = true;

            while (rs.next()) {
                if (!first) json.append(",");
                first = false;

                boolean isRead = rs.getBoolean("is_read");
                if (!isRead) unread++;

                String type = rs.getString("type");

                json.append("{")
                    .append("\"id\":").append(rs.getInt("id")).append(",")
                    .append("\"type\":\"").append(type).append("\",")
                    .append("\"icon\":\"").append(getIcon(type)).append("\",")
                    .append("\"message\":\"").append(escape(rs.getString("message"))).append("\",")
                    .append("\"link\":\"").append(rs.getString("link") != null ? rs.getString("link") : "#").append("\",")
                    .append("\"is_read\":").append(isRead).append(",")
                    .append("\"time\":\"").append(timeAgo(rs.getTimestamp("created_at"))).append("\"")
                    .append("}");
            }

            json.append("],\"unread\":").append(unread).append("}");
            out.print(json.toString());

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{\"error\":\"db error\",\"notifications\":[],\"unread\":0}");
        }
    }

    // ── POST: create a manual notification (e.g. profile view) ──────────────
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        String targetUserId = req.getParameter("targetUserId");
        String type         = req.getParameter("type");
        String message      = req.getParameter("message");
        String link         = req.getParameter("link");

        if (targetUserId == null || type == null || message == null) {
            out.print("{\"error\":\"missing params\"}");
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO notifications (user_id, type, message, link) VALUES (?,?,?,?)")) {
            ps.setInt(1, Integer.parseInt(targetUserId));
            ps.setString(2, type);
            ps.setString(3, message);
            ps.setString(4, link != null ? link : "#");
            ps.executeUpdate();
            out.print("{\"success\":true}");
        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{\"error\":\"db error\"}");
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private String getIcon(String type) {
        switch (type) {
            case "message":      return "&#128172;";
            case "review":       return "&#11088;";
            case "profile_view": return "&#128065;️";
            case "comment":      return "&#128173;";
            default:             return "&#128276;";
        }
    }

    private String timeAgo(Timestamp ts) {
        if (ts == null) return "";
        long diff  = System.currentTimeMillis() - ts.getTime();
        long mins  = diff / 60000;
        long hours = mins / 60;
        long days  = hours / 24;
        if (mins < 1)   return "just now";
        if (mins < 60)  return mins + "m ago";
        if (hours < 24) return hours + "h ago";
        if (days < 7)   return days + "d ago";
        return ts.toString().substring(0, 10);
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", " ")
                .replace("\r", "");
    }
}
