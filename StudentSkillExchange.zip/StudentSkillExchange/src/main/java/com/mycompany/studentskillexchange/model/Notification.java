
package com.mycompany.studentskillexchange.model;

import java.sql.Timestamp;

public class Notification {
    private int id;
    private int userId;
    private int actorId;
    private String actorName;
    private String type; // message, review, comment, profile_view
    private int referenceId;
    private String message;
    private boolean isRead;
    private Timestamp createdAt;
    
    // Constructors
    public Notification() {}
    
    public Notification(int userId, int actorId, String type, int referenceId, String message) {
        this.userId = userId;
        this.actorId = actorId;
        this.type = type;
        this.referenceId = referenceId;
        this.message = message;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public int getActorId() { return actorId; }
    public void setActorId(int actorId) { this.actorId = actorId; }
    
    public String getActorName() { return actorName; }
    public void setActorName(String actorName) { this.actorName = actorName; }
    
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    
    public int getReferenceId() { return referenceId; }
    public void setReferenceId(int referenceId) { this.referenceId = referenceId; }
    
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    
    public boolean isRead() { return isRead; }
    public void setRead(boolean read) { isRead = read; }
    
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
    
    // Helper method to get time ago string
    public String getTimeAgo() {
        long diff = System.currentTimeMillis() - createdAt.getTime();
        long seconds = diff / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        
        if (seconds < 60) return "Just now";
        if (minutes < 60) return minutes + "m ago";
        if (hours < 24) return hours + "h ago";
        if (days < 7) return days + "d ago";
        return new java.text.SimpleDateFormat("MMM d").format(createdAt);
    }
}