package com.mycompany.studentskillexchange.model;

public class User {
    private int id;
    private String name;
    private String email;
    private String password;
    private String role;
    private String initials;
    private String bio;
    private String profilePhoto;
    private String skills;
    private String portfolio;
    private String joinDate;
    
    public User() {}
    
    public User(String name, String email, String password, String role) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.initials = generateInitials(name);
        this.joinDate = new java.sql.Timestamp(System.currentTimeMillis()).toString();
    }
    
    // Generate initials from full name
    private String generateInitials(String fullName) {
        if (fullName == null || fullName.trim().isEmpty()) return "?";
        
        String[] parts = fullName.trim().split("\\s+");
        if (parts.length == 1) {
            return String.valueOf(Character.toUpperCase(parts[0].charAt(0)));
        } else {
            return "" + Character.toUpperCase(parts[0].charAt(0)) + 
                      Character.toUpperCase(parts[parts.length - 1].charAt(0));
        }
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { 
        this.name = name;
        this.initials = generateInitials(name);
    }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    
    public String getInitials() { return initials; }
    public void setInitials(String initials) { this.initials = initials; }
    
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    
    public String getProfilePhoto() { return profilePhoto; }
    public void setProfilePhoto(String profilePhoto) { this.profilePhoto = profilePhoto; }
    
    public String getSkills() { return skills; }
    public void setSkills(String skills) { this.skills = skills; }
    
    public String getPortfolio() { return portfolio; }
    public void setPortfolio(String portfolio) { this.portfolio = portfolio; }
    
    public String getJoinDate() { return joinDate; }
    public void setJoinDate(String joinDate) { this.joinDate = joinDate; }
}