package com.mycompany.studentskillexchange.servlet;

import com.mycompany.studentskillexchange.model.User;
import com.mycompany.studentskillexchange.utils.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/RatingServlet")
public class RatingServlet extends HttpServlet {

    // ── POST: submit a rating ──────────────────────────────────────────────
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"success\":false,\"message\":\"Not logged in\"}");
            return;
        }

        User currentUser = (User) session.getAttribute("user");

        String ratedUserParam = request.getParameter("ratedUserId");
        String ratingParam    = request.getParameter("rating");
        String comment        = request.getParameter("comment");

        if (ratedUserParam == null || ratingParam == null) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"success\":false,\"message\":\"Missing fields\"}");
            return;
        }

        int ratedUserId, rating;
        try {
            ratedUserId = Integer.parseInt(ratedUserParam);
            rating      = Integer.parseInt(ratingParam);
        } catch (NumberFormatException e) {
            out.print("{\"success\":false,\"message\":\"Invalid input\"}");
            return;
        }

        if (rating < 1 || rating > 5) {
            out.print("{\"success\":false,\"message\":\"Rating must be between 1 and 5\"}");
            return;
        }

        if (ratedUserId == currentUser.getId()) {
            out.print("{\"success\":false,\"message\":\"You cannot rate yourself\"}");
            return;
        }

        // INSERT or UPDATE if they already rated this person
        String sql = "INSERT INTO ratings (rated_user, rated_by, rating, comment) " +
                     "VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE rating = VALUES(rating), comment = VALUES(comment)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, ratedUserId);
            ps.setInt(2, currentUser.getId());
            ps.setInt(3, rating);
            ps.setString(4, comment != null ? comment.trim() : null);
            ps.executeUpdate();

            // Return updated average and count
            String avgSql = "SELECT ROUND(AVG(rating), 1) AS avg_rating, COUNT(*) AS total " +
                            "FROM ratings WHERE rated_user = ?";
            try (PreparedStatement ps2 = conn.prepareStatement(avgSql)) {
                ps2.setInt(1, ratedUserId);
                ResultSet rs = ps2.executeQuery();
                if (rs.next()) {
                    out.print("{\"success\":true,\"avg\":" + rs.getDouble("avg_rating") +
                              ",\"total\":" + rs.getInt("total") + "}");
                } else {
                    out.print("{\"success\":true,\"avg\":" + rating + ",\"total\":1}");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Database error\"}");
        }
    }

    // ── GET: fetch ratings for a user ──────────────────────────────────────
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String userIdParam = request.getParameter("userId");
        if (userIdParam == null) {
            out.print("{\"avg\":0,\"total\":0,\"reviews\":[]}");
            return;
        }

        int userId;
        try { userId = Integer.parseInt(userIdParam); }
        catch (NumberFormatException e) { out.print("{\"avg\":0,\"total\":0,\"reviews\":[]}"); return; }

        String sql =
            "SELECT r.rating, r.comment, r.created_at, u.name AS reviewer_name " +
            "FROM ratings r " +
            "JOIN users u ON u.id = r.rated_by " +
            "WHERE r.rated_user = ? " +
            "ORDER BY r.created_at DESC";

        StringBuilder reviews = new StringBuilder("[");
        boolean first = true;
        double total = 0; int count = 0;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                if (!first) reviews.append(",");
                first = false;

                int stars = rs.getInt("rating");
                total += stars; count++;

                String comment = rs.getString("comment");
                if (comment == null) comment = "";
                comment = comment.replace("\\", "\\\\").replace("\"", "\\\"")
                                 .replace("\n", "\\n").replace("\r", "");

                String reviewer = rs.getString("reviewer_name").replace("\"", "\\\"");
                String date = rs.getTimestamp("created_at").toString().substring(0, 10);

                reviews.append("{")
                    .append("\"stars\":").append(stars).append(",")
                    .append("\"comment\":\"").append(comment).append("\",")
                    .append("\"reviewer\":\"").append(reviewer).append("\",")
                    .append("\"date\":\"").append(date).append("\"")
                    .append("}");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{\"avg\":0,\"total\":0,\"reviews\":[]}");
            return;
        }

        reviews.append("]");
        double avg = count > 0 ? Math.round((total / count) * 10.0) / 10.0 : 0;
        out.print("{\"avg\":" + avg + ",\"total\":" + count + ",\"reviews\":" + reviews + "}");
    }
}