package com.mycompany.studentskillexchange.dao;

import com.mycompany.studentskillexchange.model.User;
import com.mycompany.studentskillexchange.utils.DBConnection;

import java.sql.*;

public class UserDAO {

    // REGISTER USER
    public boolean registerUser(User user) {
    String sql = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
        ps.setString(1, user.getName());
        ps.setString(2, user.getEmail());
        ps.setString(3, user.getPassword());
        ps.setString(4, user.getRole());
        int rows = ps.executeUpdate();
        if (rows > 0) {
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    int newId = rs.getInt(1);
                    user.setId(newId);

                    // ✅ NOW fetch created_at from DB using the new ID
                    String fetchSql = "SELECT created_at FROM users WHERE id = ?";
                    try (PreparedStatement ps2 = conn.prepareStatement(fetchSql)) {
                        ps2.setInt(1, newId);
                        ResultSet rs2 = ps2.executeQuery();
                        if (rs2.next() && rs2.getTimestamp("created_at") != null) {
                            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMMM yyyy");
                            user.setJoinDate(sdf.format(rs2.getTimestamp("created_at")));
                        }
                    }
                }
            }
            return true;
        }
    } catch (SQLException e) {
        System.out.println("❌ Error in registerUser:");
        e.printStackTrace();
    }
    return false;
}

    // LOGIN USER
    public User loginUser(String email, String password) {

        String sql = "SELECT * FROM users WHERE email = ? AND password = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                User user = new User();

                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));
                user.setBio(rs.getString("bio"));
               if (rs.getTimestamp("created_at") != null) {
                   java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMMM yyyy");
                   user.setJoinDate(sdf.format(rs.getTimestamp("created_at")));
                }
                return user;
            }

        } catch (SQLException e) {
            System.out.println("❌ Error in loginUser:");
            e.printStackTrace();
        }

        return null;
    }

    // CHECK IF EMAIL EXISTS (OPTIONAL BUT VERY USEFUL)
    public boolean emailExists(String email) {

        String sql = "SELECT id FROM users WHERE email = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);

            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}