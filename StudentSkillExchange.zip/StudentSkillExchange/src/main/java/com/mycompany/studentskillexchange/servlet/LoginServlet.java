package com.mycompany.studentskillexchange.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

import com.mycompany.studentskillexchange.dao.UserDAO;
import com.mycompany.studentskillexchange.model.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        String email = request.getParameter("email");
        String password = request.getParameter("password");

         // 2. Call DAO
        UserDAO dao = new UserDAO();
        User user = dao.loginUser(email, password);

        // 3. Validate user
        if (user != null) {

            // 4. Store FULL user object in session (IMPORTANT FIX)
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            // 5. Redirect to profile (same as register)
            response.sendRedirect("profile.jsp");

        } else {
            // login failed
            response.sendRedirect("login.jsp?error=invalid");
        }

    }
}