package com.mycompany.studentskillexchange.servlet;

import com.mycompany.studentskillexchange.model.User;
import com.mycompany.studentskillexchange.utils.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/DeactivateAccountServlet")
public class DeactivateAccountServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        System.out.println("=== DEACTIVATE SERVLET REACHED ===");

        // 1. Check session
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            System.out.println("❌ No session found");
            response.sendRedirect("login.jsp");
            return;
        }

        User user   = (User) session.getAttribute("user");
        int  userId = user.getId();
        System.out.println("✅ User ID: " + userId + " | Email: " + user.getEmail());

        // 2. ✅ Parameter name matches the form input name="confirmText"
        String confirmation = request.getParameter("confirmText");
        System.out.println("✅ Confirmation text received: [" + confirmation + "]");

        if (confirmation == null || !confirmation.trim().equals("CONFIRM")) {
            System.out.println("❌ Confirmation did not match");
            session.setAttribute("errorMessage", "Please type CONFIRM to deactivate your account.");
            response.sendRedirect("profile.jsp");
            return;
        }

        Connection conn = null;

        try {
            conn = DBConnection.getConnection(); // ✅ Use DBConnection — no hardcoded credentials
            conn.setAutoCommit(false);           // ✅ Transaction — all or nothing

            // 3. ✅ Delete skills first (child table before parent)
            try (PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM user_skills WHERE user_id = ?")) {
                ps.setInt(1, userId);
                int rows = ps.executeUpdate();
                System.out.println("✅ Skills deleted: " + rows + " row(s)");
            }

            // 4. ✅ Permanently delete user from database — no soft delete
            try (PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM users WHERE id = ?")) {
                ps.setInt(1, userId);
                int rows = ps.executeUpdate();
                System.out.println("✅ User deleted: " + rows + " row(s)");

                if (rows == 0) {
                    System.out.println("❌ WARNING: No rows deleted — user ID " + userId + " not found in DB");
                }
            }

            // 5. Commit — data is now permanently gone
            conn.commit();
            System.out.println("✅ Committed — account permanently deleted from database");

            // 6. Destroy the session completely
            session.invalidate();
            System.out.println("✅ Session invalidated");

            // 7. Redirect to index page with success message
            HttpSession newSession = request.getSession(true);
            newSession.setAttribute("successMessage", "Your account has been permanently deleted.");
            response.sendRedirect(request.getContextPath() + "/index.jsp");

        } catch (SQLException e) {
            // Rollback if anything went wrong
            try {
                if (conn != null) conn.rollback();
                System.out.println("❌ Rolled back — nothing deleted");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            System.out.println("❌ SQLException: " + e.getMessage());
            System.out.println("❌ SQL State: "    + e.getSQLState());
            e.printStackTrace();
            session.setAttribute("errorMessage", "Deactivation failed: " + e.getMessage());
            response.sendRedirect("profile.jsp");

        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}