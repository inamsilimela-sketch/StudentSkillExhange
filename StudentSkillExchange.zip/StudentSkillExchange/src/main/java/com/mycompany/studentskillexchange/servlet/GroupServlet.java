/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.studentskillexchange.servlet;

import com.mycompany.studentskillexchange.model.User;
import com.mycompany.studentskillexchange.utils.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;

@WebServlet("/GroupServlet")
public class GroupServlet extends HttpServlet {

    // ── GET: fetch groups the user belongs to, OR messages in a group ──────
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("[]");
            return;
        }

        User currentUser = (User) session.getAttribute("user");
        String groupIdParam = request.getParameter("groupId");

        if (groupIdParam == null) {
            // Return list of groups the user is in
            fetchUserGroups(currentUser.getId(), out);
        } else {
            // Return messages for a specific group
            int groupId;
            try { groupId = Integer.parseInt(groupIdParam); }
            catch (NumberFormatException e) { out.print("[]"); return; }

            // Security: make sure user is actually a member
            if (!isMember(currentUser.getId(), groupId)) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                out.print("[]");
                return;
            }
            fetchGroupMessages(currentUser.getId(), groupId, out);
        }
    }

    // ── POST: create a group OR send a group message ───────────────────────
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"success\":false,\"message\":\"Not logged in\"}");
            return;
        }

        User currentUser = (User) session.getAttribute("user");
        String action = request.getParameter("action");

        if ("create".equals(action)) {
            createGroup(request, response, currentUser, out);
        } else if ("send".equals(action)) {
            sendGroupMessage(request, response, currentUser, out);
        } else {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"success\":false,\"message\":\"Unknown action\"}");
        }
    }

    // ── Create a new group ─────────────────────────────────────────────────
    private void createGroup(HttpServletRequest request, HttpServletResponse response,
                             User currentUser, PrintWriter out) throws IOException {

        String groupName   = request.getParameter("groupName");
        String memberIds   = request.getParameter("memberIds"); // comma-separated user IDs

        if (groupName == null || groupName.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"success\":false,\"message\":\"Group name is required\"}");
            return;
        }

        groupName = groupName.trim();

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            // 1. Insert group
            int groupId;
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO groups_chat (name, created_by) VALUES (?, ?)",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, groupName);
                ps.setInt(2, currentUser.getId());
                ps.executeUpdate();
                ResultSet rs = ps.getGeneratedKeys();
                if (!rs.next()) { conn.rollback(); out.print("{\"success\":false,\"message\":\"Failed to create group\"}"); return; }
                groupId = rs.getInt(1);
            }

            // 2. Add creator as member
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO group_members (group_id, user_id) VALUES (?, ?)")) {
                ps.setInt(1, groupId);
                ps.setInt(2, currentUser.getId());
                ps.executeUpdate();
            }

            // 3. Add selected members
            if (memberIds != null && !memberIds.trim().isEmpty()) {
                String[] ids = memberIds.split(",");
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT IGNORE INTO group_members (group_id, user_id) VALUES (?, ?)")) {
                    for (String idStr : ids) {
                        try {
                            int memberId = Integer.parseInt(idStr.trim());
                            ps.setInt(1, groupId);
                            ps.setInt(2, memberId);
                            ps.addBatch();
                        } catch (NumberFormatException e) { /* skip invalid */ }
                    }
                    ps.executeBatch();
                }
            }

            conn.commit();
            out.print("{\"success\":true,\"groupId\":" + groupId + ",\"groupName\":\"" +
                      groupName.replace("\"", "\\\"") + "\"}");

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Database error\"}");
        }
    }

    // ── Send a message to a group ──────────────────────────────────────────
    private void sendGroupMessage(HttpServletRequest request, HttpServletResponse response,
                                  User currentUser, PrintWriter out) throws IOException {

        String groupIdParam  = request.getParameter("groupId");
        String messageText   = request.getParameter("message");

        if (groupIdParam == null || messageText == null || messageText.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"success\":false,\"message\":\"Missing fields\"}");
            return;
        }

        int groupId;
        try { groupId = Integer.parseInt(groupIdParam); }
        catch (NumberFormatException e) {
            out.print("{\"success\":false,\"message\":\"Invalid group\"}");
            return;
        }

        if (!isMember(currentUser.getId(), groupId)) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"success\":false,\"message\":\"Not a member of this group\"}");
            return;
        }

        String sql = "INSERT INTO messages (sender_id, receiver_id, group_id, message) VALUES (?, NULL, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, currentUser.getId());
            ps.setInt(2, groupId);
            ps.setString(3, messageText.trim());
            ps.executeUpdate();
            out.print("{\"success\":true}");
        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Database error\"}");
        }
    }

    // ── Fetch groups the user belongs to ──────────────────────────────────
    private void fetchUserGroups(int userId, PrintWriter out) {
        String sql =
            "SELECT g.id, g.name, " +
            "       MAX(m.sent_at) AS last_time, " +
            "       SUBSTRING_INDEX(GROUP_CONCAT(m.message ORDER BY m.sent_at DESC SEPARATOR '||'), '||', 1) AS last_message, " +
            "       SUM(CASE WHEN m.sender_id != ? AND m.is_read = FALSE AND m.group_id = g.id THEN 1 ELSE 0 END) AS unread_count " +
            "FROM groups_chat g " +
            "JOIN group_members gm ON gm.group_id = g.id AND gm.user_id = ? " +
            "LEFT JOIN messages m ON m.group_id = g.id " +
            "GROUP BY g.id, g.name " +
            "ORDER BY MAX(m.sent_at) DESC";

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        sdf.setTimeZone(java.util.TimeZone.getDefault());
        StringBuilder json = new StringBuilder("[");
        boolean first = true;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, userId);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                if (!first) json.append(",");
                first = false;

                String lastMsg = rs.getString("last_message");
                if (lastMsg == null) lastMsg = "No messages yet";
                lastMsg = lastMsg.replace("\\", "\\\\").replace("\"", "\\\"");
                if (lastMsg.length() > 60) lastMsg = lastMsg.substring(0, 60) + "...";

                java.sql.Timestamp ts = rs.getTimestamp("last_time");
                String time = ts != null ? sdf.format(ts) : "";
                String safeName = rs.getString("name").replace("\"", "\\\"");

                json.append("{")
                    .append("\"id\":").append(rs.getInt("id")).append(",")
                    .append("\"name\":\"").append(safeName).append("\",")
                    .append("\"isGroup\":true,")
                    .append("\"lastMsg\":\"").append(lastMsg).append("\",")
                    .append("\"time\":\"").append(time).append("\",")
                    .append("\"unread\":").append(rs.getInt("unread_count"))
                    .append("}");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
            return;
        }

        json.append("]");
        out.print(json.toString());
    }

    // ── Fetch messages for a group ─────────────────────────────────────────
    private void fetchGroupMessages(int currentUserId, int groupId, PrintWriter out) {
        String sql =
            "SELECT m.id, m.sender_id, u.name AS sender_name, m.message, m.sent_at " +
            "FROM messages m " +
            "JOIN users u ON u.id = m.sender_id " +
            "WHERE m.group_id = ? " +
            "ORDER BY m.sent_at ASC";

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        sdf.setTimeZone(java.util.TimeZone.getDefault());
        StringBuilder json = new StringBuilder("[");
        boolean first = true;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, groupId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                if (!first) json.append(",");
                first = false;

                boolean isSent = rs.getInt("sender_id") == currentUserId;
                java.sql.Timestamp ts = rs.getTimestamp("sent_at");
                String time = ts != null ? sdf.format(ts) : "00:00";
                String text = rs.getString("message")
                        .replace("\\", "\\\\")
                        .replace("\"", "\\\"")
                        .replace("\n", "\\n")
                        .replace("\r", "");
                String senderName = rs.getString("sender_name").replace("\"", "\\\"");

                json.append("{")
                    .append("\"id\":").append(rs.getInt("id")).append(",")
                    .append("\"from\":\"").append(isSent ? "me" : "them").append("\",")
                    .append("\"senderName\":\"").append(senderName).append("\",")
                    .append("\"text\":\"").append(text).append("\",")
                    .append("\"time\":\"").append(time).append("\"")
                    .append("}");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
            return;
        }

        json.append("]");
        out.print(json.toString());
    }

    // ── Check if user is a group member ───────────────────────────────────
    private boolean isMember(int userId, int groupId) {
        String sql = "SELECT 1 FROM group_members WHERE user_id = ? AND group_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, groupId);
            return ps.executeQuery().next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
