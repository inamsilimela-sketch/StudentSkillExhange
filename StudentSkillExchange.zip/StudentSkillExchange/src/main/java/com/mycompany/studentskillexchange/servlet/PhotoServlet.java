package com.mycompany.studentskillexchange.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

@WebServlet("/PhotoServlet")
public class PhotoServlet extends HttpServlet {

    private static final String UPLOAD_DIR = "portfolio_uploads";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String fileName = request.getParameter("file");

        // Security: no path traversal
        if (fileName == null || fileName.contains("..") ||
            fileName.contains("/") || fileName.contains("\\")) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }

        // Same path PortfolioServlet uses
        String uploadPath = "C:\\Users\\User\\sse_uploads";
        File file = new File(uploadPath + File.separator + fileName);

        if (!file.exists() || !file.isFile()) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        // Set content type based on extension
        String lower = fileName.toLowerCase();
        if      (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) response.setContentType("image/jpeg");
        else if (lower.endsWith(".png"))  response.setContentType("image/png");
        else if (lower.endsWith(".gif"))  response.setContentType("image/gif");
        else if (lower.endsWith(".webp")) response.setContentType("image/webp");
        else { response.sendError(HttpServletResponse.SC_FORBIDDEN); return; }

        response.setContentLengthLong(file.length());

        // Stream file to browser
        try (FileInputStream in = new FileInputStream(file);
             OutputStream out = response.getOutputStream()) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }
    }
}
