/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.studentskillexchange.servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.*;

import com.mycompany.studentskillexchange.model.User;
import com.mycompany.studentskillexchange.dao.UserDAO;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Get form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        String confirmPassword = request.getParameter("confirmPassword");

// Check password match
if (!password.equals(confirmPassword)) {
    response.sendRedirect("register.jsp?error=passwordMismatch");
    return;
}

// Check password strength
boolean hasUpper = password.matches(".*[A-Z].*");
boolean hasNumber = password.matches(".*[0-9].*");
boolean hasSpecial = password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?].*");

if (password.length() < 8 || !hasUpper || !hasNumber || !hasSpecial) {
    response.sendRedirect("register.jsp?error=weakPassword");
    return;
}

        // 2. (Optional) Validate
        if (name == null || email == null || password == null || role == null ||
            name.trim().isEmpty() || email.trim().isEmpty() || password.trim().isEmpty() || role.trim().isEmpty()) {
            response.sendRedirect("register.jsp?error=missing");
            return;
        }
        // 3. Validate role
        if (!role.equals("student") && !role.equals("tutor")) {
            response.sendRedirect("register.jsp?error=invalidRole");
            return;
        }
        // 4. Restrict users to UMP email only
        if (!email.endsWith("@ump.ac.za")) {
            response.sendRedirect("register.jsp?error=invalidEmail");
            return;
        }
        // 5. Full name check
        if (!name.trim().contains(" ")) {
            response.sendRedirect("register.jsp?error=fullname");
            return;
        }
        // 5. Create User object 
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);
        
       // Save to database
        UserDAO userDAO = new UserDAO();
        boolean success = userDAO.registerUser(user);

        if (success && user.getId() > 0) {  
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            response.sendRedirect("profile.jsp");
        } else {
            response.sendRedirect("register.jsp?error=failed");
        }
    
    }
}