/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.studentskillexchange.servlet;

import com.mycompany.studentskillexchange.model.User;
import com.mycompany.studentskillexchange.utils.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/BrowseServlet")
public class BrowseServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        User currentUser = (User) session.getAttribute("user");

        List<BrowseUser> users = new ArrayList<>();

        // Fetch all users except the logged-in user, with their skills
        String sql =
            "SELECT u.id, u.name, u.role, " +
            "       GROUP_CONCAT(s.skill_name ORDER BY s.created_at ASC SEPARATOR ',') AS skills " +
            "FROM users u " +
            "LEFT JOIN user_skills s ON s.user_id = u.id " +
            "WHERE u.id != ? " +
            "GROUP BY u.id, u.name, u.role " +
            "ORDER BY u.name ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, currentUser.getId());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                BrowseUser bu = new BrowseUser();
                bu.id       = rs.getInt("id");
                bu.name     = rs.getString("name");
                bu.role     = rs.getString("role");
                bu.skillsCsv = rs.getString("skills"); // may be null
                users.add(bu);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // If called with ?json=true, return JSON instead of forwarding to JSP
        String jsonMode = request.getParameter("json");
        if ("true".equals(jsonMode)) {
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            java.io.PrintWriter out = response.getWriter();
            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            for (BrowseUser bu : users) {
                if (!first) json.append(",");
                first = false;
                String safeName = bu.name.replace("\"", "\\\"");
                json.append("{\"id\":").append(bu.id)
                    .append(",\"name\":\"").append(safeName).append("\"}");
            }
            json.append("]");
            out.print(json.toString());
            return;
        }

        request.setAttribute("browseUsers", users);
        request.getRequestDispatcher("browse.jsp").forward(request, response);
    }

    // Simple inner class to hold browse data
    public static class BrowseUser {
        public int    id;
        public String name;
        public String role;
        public String skillsCsv; // comma-separated skills from GROUP_CONCAT
    }
}
