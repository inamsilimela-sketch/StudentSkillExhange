<%@page import="com.mycompany.studentskillexchange.model.User"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    User user = (User) session.getAttribute("user");
%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About — StudentSkillExchange</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&family=Fraunces:opsz,wght@9..144,300;9..144,400;9..144,600;9..144,700&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --brand:       #1a6b4a;
      --brand-light: #e8f5ee;
      --brand-mid:   #2d9e6f;
      --accent:      #f4a24a;
      --accent-light:#fff4e6;
      --bg:          #f7f6f2;
      --surface:     #ffffff;
      --surface2:    #f0ede8;
      --text:        #1c1c1a;
      --text2:       #5a5853;
      --text3:       #9a9792;
      --border:      rgba(0,0,0,0.08);
      --border2:     rgba(0,0,0,0.14);
      --radius:      12px;
      --font-display:'Fraunces', Georgia, serif;
      --font-body:   'DM Sans', system-ui, sans-serif;
      --nav-height:  62px;
    }

    html { scroll-behavior: smooth; }

    body {
      background: var(--bg);
      color: var(--text);
      font-family: var(--font-body);
      font-size: 16px;
      line-height: 1.6;
      overflow-x: hidden;
    }

    /* ── NAV (matches index.jsp) ── */
    :root {
      --nav-green:  #2d6a3f;
      --hero-top:   #357a48;
      --hero-bot:   #4cb86a;
      --btn-green:  #2d6a3f;
      --btn-hover:  #245535;
    }

    nav {
      position: fixed;
      top: 0; left: 0; right: 0;
      z-index: 100;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 48px;
      height: 68px;
      background: var(--nav-green);
      border-bottom: 1px solid rgba(61,184,106,0.15);
    }

    .nav-logo {
      font-weight: 800;
      font-size: 1.2rem;
      letter-spacing: -0.5px;
      color: #fff;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .nav-logo span.dot {
      width: 8px; height: 8px;
      background: #4cb86a;
      border-radius: 50%;
      display: inline-block;
      animation: pulse 2s infinite;
    }
    @keyframes pulse {
      0%,100% { opacity: 1; transform: scale(1); }
      50%      { opacity: 0.5; transform: scale(1.3); }
    }

    .nav-links {
      display: flex;
      align-items: center;
      gap: 8px;
      list-style: none;
    }

    .nav-links li { position: relative; }

    .nav-links a {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 16px;
      border-radius: 8px;
      font-size: 0.9rem;
      font-weight: 500;
      color: rgba(255,255,255,0.75);
      text-decoration: none;
      transition: color .2s, background .2s;
      white-space: nowrap;
    }
    .nav-links a:hover { color: #fff; background: rgba(255,255,255,0.07); }
    .nav-links a.active-link { background: rgba(255,255,255,0.15); color: #fff; }

    /* Dropdown */
    .dropdown {
      position: absolute;
      top: calc(100% + 12px);
      left: 50%;
      transform: translateX(-50%) translateY(-6px);
      min-width: 220px;
      background: var(--nav-green);
      border: 1px solid rgba(61,184,106,0.2);
      border-radius: 12px;
      padding: 8px;
      opacity: 0;
      pointer-events: none;
      transition: opacity .2s, transform .2s;
      box-shadow: 0 24px 48px rgba(0,0,0,.4);
    }
    .nav-links li:hover .dropdown {
      opacity: 1;
      pointer-events: all;
      transform: translateX(-50%) translateY(0);
    }
    .dropdown a {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      border-radius: 10px;
      color: rgba(255,255,255,0.8);
      font-size: 0.875rem;
      width: 100%;
    }
    .dropdown a:hover { background: rgba(61,184,106,0.12); color: #4cb86a; }
    .dropdown a .icon { font-size: 1rem; }
    .dropdown-label {
      font-size: 0.7rem;
      font-weight: 600;
      letter-spacing: .08em;
      text-transform: uppercase;
      color: rgba(255,255,255,0.4);
      padding: 6px 14px 4px;
    }

    /* ── HERO ── */
    .hero {
      padding-top: calc(68px + 80px);
      padding-bottom: 100px;
      padding-left: 2rem;
      padding-right: 2rem;
      position: relative;
      overflow: hidden;
      text-align: center;
    }

    .hero-bg {
      position: absolute;
      inset: 0;
      background:
        radial-gradient(ellipse 60% 50% at 50% 0%, rgba(45,158,111,0.12) 0%, transparent 70%),
        radial-gradient(ellipse 40% 40% at 80% 60%, rgba(244,162,74,0.08) 0%, transparent 60%);
      pointer-events: none;
    }

    .hero-eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: var(--brand-light);
      color: var(--brand);
      font-size: 12px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      padding: 5px 14px;
      border-radius: 20px;
      border: 1px solid rgba(26,107,74,0.2);
      margin-bottom: 1.5rem;
      animation: fadeUp 0.6s ease both;
    }

    .hero h1 {
      font-family: var(--font-display);
      font-size: clamp(42px, 7vw, 76px);
      font-weight: 600;
      color: var(--text);
      line-height: 1.1;
      letter-spacing: -1.5px;
      max-width: 800px;
      margin: 0 auto 1.5rem;
      animation: fadeUp 0.6s 0.1s ease both;
    }

    .hero h1 em {
      font-style: italic;
      color: var(--brand);
    }

    .hero-sub {
      font-size: 18px;
      color: var(--text2);
      max-width: 520px;
      margin: 0 auto 2.5rem;
      font-weight: 400;
      animation: fadeUp 0.6s 0.2s ease both;
    }

    .hero-actions {
      display: flex;
      gap: 12px;
      justify-content: center;
      flex-wrap: wrap;
      animation: fadeUp 0.6s 0.3s ease both;
    }

    .btn-primary {
      padding: 13px 28px;
      border-radius: 10px;
      background: var(--brand);
      color: #fff;
      font-size: 15px;
      font-weight: 500;
      text-decoration: none;
      font-family: var(--font-body);
      border: none;
      cursor: pointer;
      transition: background 0.15s, transform 0.15s;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    .btn-primary:hover { background: #155c3e; transform: translateY(-1px); }

    .btn-secondary {
      padding: 13px 28px;
      border-radius: 10px;
      background: var(--surface);
      color: var(--text);
      font-size: 15px;
      font-weight: 500;
      text-decoration: none;
      font-family: var(--font-body);
      border: 1px solid var(--border2);
      cursor: pointer;
      transition: background 0.15s, transform 0.15s;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    .btn-secondary:hover { background: var(--surface2); transform: translateY(-1px); }

    /* ── STATS STRIP ── */
    .stats-strip {
      background: var(--surface);
      border-top: 1px solid var(--border);
      border-bottom: 1px solid var(--border);
      padding: 2rem;
      display: flex;
      justify-content: center;
      gap: 0;
      flex-wrap: wrap;
    }

    .stat-item {
      text-align: center;
      padding: 1rem 3rem;
      border-right: 1px solid var(--border);
      animation: fadeUp 0.6s ease both;
    }
    .stat-item:last-child { border-right: none; }

    .stat-number {
      font-family: var(--font-display);
      font-size: 36px;
      font-weight: 600;
      color: var(--brand);
      line-height: 1;
      margin-bottom: 4px;
    }

    .stat-label {
      font-size: 13px;
      color: var(--text3);
      font-weight: 500;
    }

    /* ── SECTION WRAPPER ── */
    .section {
      padding: 90px 2rem;
      max-width: 1100px;
      margin: 0 auto;
    }

    .section-eyebrow {
      font-size: 12px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--brand);
      margin-bottom: 0.75rem;
    }

    .section-title {
      font-family: var(--font-display);
      font-size: clamp(28px, 4vw, 42px);
      font-weight: 600;
      color: var(--text);
      letter-spacing: -0.5px;
      line-height: 1.2;
      margin-bottom: 1rem;
    }

    .section-sub {
      font-size: 16px;
      color: var(--text2);
      max-width: 520px;
      margin-bottom: 3rem;
    }

    /* ── FEATURE CARDS ── */
    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1.25rem;
    }

    .feature-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 2rem;
      transition: box-shadow 0.2s, transform 0.2s, border-color 0.2s;
      position: relative;
      overflow: hidden;
    }

    .feature-card::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0;
      height: 3px;
      background: linear-gradient(90deg, var(--brand), var(--brand-mid));
      opacity: 0;
      transition: opacity 0.2s;
    }

    .feature-card:hover {
      box-shadow: 0 8px 30px rgba(0,0,0,0.08);
      transform: translateY(-3px);
      border-color: rgba(26,107,74,0.2);
    }
    .feature-card:hover::before { opacity: 1; }

    .feature-icon {
      width: 48px; height: 48px;
      border-radius: 12px;
      background: var(--brand-light);
      display: flex; align-items: center; justify-content: center;
      font-size: 22px;
      margin-bottom: 1.25rem;
    }

    .feature-title {
      font-family: var(--font-display);
      font-size: 18px;
      font-weight: 600;
      color: var(--text);
      margin-bottom: 0.5rem;
    }

    .feature-desc {
      font-size: 14px;
      color: var(--text2);
      line-height: 1.65;
    }

    /* ── HOW IT WORKS ── */
    .how-section {
      background: var(--surface);
      border-top: 1px solid var(--border);
      border-bottom: 1px solid var(--border);
      padding: 90px 2rem;
    }

    .how-inner {
      max-width: 1100px;
      margin: 0 auto;
    }

    .steps-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 0;
      position: relative;
      margin-top: 3rem;
    }

    .steps-grid::before {
      content: '';
      position: absolute;
      top: 28px;
      left: 10%;
      right: 10%;
      height: 1px;
      background: linear-gradient(90deg, transparent, var(--border2), transparent);
    }

    .step-item {
      text-align: center;
      padding: 0 1.5rem;
      position: relative;
    }

    .step-num {
      width: 56px; height: 56px;
      border-radius: 50%;
      background: var(--brand-light);
      border: 2px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-family: var(--font-display);
      font-size: 20px;
      font-weight: 600;
      color: var(--brand);
      margin: 0 auto 1.25rem;
      position: relative;
      z-index: 1;
      transition: background 0.2s, transform 0.2s;
    }

    .step-item:hover .step-num {
      background: var(--brand);
      color: #fff;
      transform: scale(1.1);
    }

    .step-title {
      font-size: 14px;
      font-weight: 600;
      color: var(--text);
      margin-bottom: 0.5rem;
    }

    .step-desc {
      font-size: 13px;
      color: var(--text3);
      line-height: 1.6;
    }

    /* ── MISSION SPLIT ── */
    .mission-split {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 4rem;
      align-items: center;
    }

    @media (max-width: 720px) {
      .mission-split { grid-template-columns: 1fr; gap: 2rem; }
      .steps-grid::before { display: none; }
      .stat-item { border-right: none; border-bottom: 1px solid var(--border); }
      .stat-item:last-child { border-bottom: none; }
      nav { padding: 0 1rem; }
      .nav-links { display: none; }
    }

    .mission-visual {
      background: var(--brand-light);
      border: 1px solid rgba(26,107,74,0.15);
      border-radius: 16px;
      padding: 2.5rem;
      position: relative;
      overflow: hidden;
    }

    .mission-visual::after {
      content: '';
      position: absolute;
      bottom: -20px; right: -20px;
      width: 150px; height: 150px;
      border-radius: 50%;
      background: rgba(26,107,74,0.08);
    }

    .mission-pill {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: var(--surface);
      border: 1px solid var(--border2);
      border-radius: 8px;
      padding: 10px 14px;
      font-size: 13px;
      font-weight: 500;
      color: var(--text);
      margin-bottom: 10px;
      width: 100%;
      transition: border-color 0.2s;
    }
    .mission-pill:hover { border-color: var(--brand-mid); }

    .mission-pill-icon {
      width: 28px; height: 28px;
      border-radius: 8px;
      background: var(--brand-light);
      display: flex; align-items: center; justify-content: center;
      font-size: 14px;
      flex-shrink: 0;
    }

    /* ── TESTIMONIAL ── */
    .testimonial-section {
      padding: 90px 2rem;
      max-width: 1100px;
      margin: 0 auto;
    }

    .testimonials-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 1.25rem;
      margin-top: 3rem;
    }

    .testimonial-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.75rem;
      transition: box-shadow 0.2s, transform 0.2s;
    }
    .testimonial-card:hover {
      box-shadow: 0 8px 30px rgba(0,0,0,0.07);
      transform: translateY(-2px);
    }

    .testimonial-quote {
      font-family: var(--font-display);
      font-size: 36px;
      color: var(--brand-light);
      line-height: 1;
      margin-bottom: 0.5rem;
    }

    .testimonial-text {
      font-size: 14px;
      color: var(--text2);
      line-height: 1.7;
      margin-bottom: 1.25rem;
      font-style: italic;
    }

    .testimonial-author {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .testimonial-avatar {
      width: 36px; height: 36px;
      border-radius: 50%;
      background: var(--brand-light);
      border: 2px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-size: 13px;
      font-weight: 600;
      color: var(--brand);
    }

    .testimonial-name {
      font-size: 13px;
      font-weight: 600;
      color: var(--text);
    }

    .testimonial-role {
      font-size: 12px;
      color: var(--text3);
    }

    /* ── CTA BANNER ── */
    .cta-banner {
      margin: 0 2rem 80px;
      background: var(--brand);
      border-radius: 16px;
      padding: 4rem 3rem;
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    .cta-banner::before {
      content: '';
      position: absolute;
      top: -60px; right: -60px;
      width: 250px; height: 250px;
      border-radius: 50%;
      background: rgba(255,255,255,0.05);
    }

    .cta-banner::after {
      content: '';
      position: absolute;
      bottom: -40px; left: -40px;
      width: 180px; height: 180px;
      border-radius: 50%;
      background: rgba(255,255,255,0.04);
    }

    .cta-banner h2 {
      font-family: var(--font-display);
      font-size: clamp(24px, 4vw, 38px);
      font-weight: 600;
      color: #fff;
      letter-spacing: -0.5px;
      margin-bottom: 0.75rem;
    }

    .cta-banner p {
      font-size: 16px;
      color: rgba(255,255,255,0.75);
      margin-bottom: 2rem;
      max-width: 460px;
      margin-left: auto;
      margin-right: auto;
    }

    .btn-white {
      padding: 13px 28px;
      border-radius: 10px;
      background: #fff;
      color: var(--brand);
      font-size: 15px;
      font-weight: 600;
      text-decoration: none;
      font-family: var(--font-body);
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: transform 0.15s, box-shadow 0.15s;
    }
    .btn-white:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.15); }

    /* ── FOOTER ── */
    footer {
      background: var(--surface);
      border-top: 1px solid var(--border);
      padding: 2rem;
      text-align: center;
      font-size: 13px;
      color: var(--text3);
    }

    footer a { color: var(--brand); text-decoration: none; }

    /* ── ANIMATIONS ── */
    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(20px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    .reveal {
      opacity: 0;
      transform: translateY(24px);
      transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .reveal.visible {
      opacity: 1;
      transform: translateY(0);
    }
  </style>
</head>
<body>

<!-- ── NAV (matches index.jsp) ── -->
<nav>
  <a class="nav-logo" href="index.jsp">
    <span class="dot"></span> StudentSkillExchange
  </a>
  <ul class="nav-links">

    <li>
      <a href="#">Explore &#9662;</a>
      <div class="dropdown">
        <div class="dropdown-label">Discover</div>
        <a href="#"><span class="icon">&#128269;</span> Browse All Skills</a>
        <a href="#"><span class="icon">&#128293;</span> Trending Skills</a>
        <a href="#"><span class="icon">&#128218;</span> Categories</a>
        <div class="dropdown-label" style="margin-top:8px">Popular</div>
        <a href="#"><span class="icon">&#128187;</span> Tech &amp; Coding</a>
        <a href="#"><span class="icon">&#127912;</span> Design &amp; Art</a>
        <a href="#"><span class="icon">&#127760;</span> Languages</a>
      </div>
    </li>

    <li>
      <a href="#">Community &#9662;</a>
      <div class="dropdown">
        <div class="dropdown-label">Connect</div>
        <a href="#"><span class="icon">&#128101;</span> Student Profiles</a>
        <a href="#"><span class="icon">&#128172;</span> Discussion Board</a>
        <a href="#"><span class="icon">&#129309;</span> Find a Study Buddy</a>
      </div>
    </li>

    <li>
      <a href="#">Account &#9662;</a>
      <div class="dropdown">
        <div class="dropdown-label">New here?</div>
        <a href="register.jsp">&#128221; Create Profile</a>
        <div class="dropdown-label" style="margin-top:6px">Returning</div>
        <a href="login.jsp">&#128273; Login</a>
      </div>
    </li>

    <li><a href="index.jsp">Home</a></li>

    <li><a href="register.jsp">Get Started &#8594;</a></li>
  </ul>
</nav>

<!-- ── HERO ── -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-eyebrow">&#127807; About Our Platform</div>
  <h1>Where Students <em>Teach</em><br>and Students <em>Learn</em></h1>
  <p class="hero-sub">StudentSkillExchange connects university students to share knowledge, grow together, and build real skills   </p>
  <div class="hero-actions">
    <a href="register.jsp" class="btn-primary">&#128640; Get Started </a>
    <a href="browse.jsp" class="btn-secondary">&#128269; Browse Skills</a>
  </div>
</section>

<!-- ── STATS ── -->
<div class="stats-strip">
  <div class="stat-item reveal">
    <div class="stat-number">2,400+</div>
    <div class="stat-label">Students Joined</div>
  </div>
  <div class="stat-item reveal">
    <div class="stat-number">180+</div>
    <div class="stat-label">Skills Shared</div>
  </div>
  <div class="stat-item reveal">
    <div class="stat-number">950+</div>
    <div class="stat-label">Exchanges Made</div>
  </div>
  <div class="stat-item reveal">
    <div class="stat-number">4.9★</div>
    <div class="stat-label">Avg. Rating</div>
  </div>
</div>

<!-- ── FEATURES ── -->
<section class="section">
  <p class="section-eyebrow reveal">&#9889; What We Offer</p>
  <h2 class="section-title reveal">Everything you need to<br>learn and teach</h2>
  <p class="section-sub reveal">A complete platform built around student needs — simple, effective, and community-driven.</p>

  <div class="features-grid">
    <div class="feature-card reveal">
      <div class="feature-icon">&#128221;</div>
      <div class="feature-title">Post Your Skills</div>
      <p class="feature-desc">List what you're good at — coding, design, maths, writing — and let others find you easily.</p>
    </div>
    <div class="feature-card reveal">
      <div class="feature-icon">&#128269;</div>
      <div class="feature-title">Find the Right Help</div>
      <p class="feature-desc">Browse student profiles by skill, subject, or availability and connect with the perfect match.</p>
    </div>
    <div class="feature-card reveal">
      <div class="feature-icon">&#128172;</div>
      <div class="feature-title">Real-Time Messaging</div>
      <p class="feature-desc">Chat directly with other students, plan sessions, and track message delivery with read receipts.</p>
    </div>
    <div class="feature-card reveal">
      <div class="feature-icon">&#128203;</div>
      <div class="feature-title">Skill Exchanges</div>
      <p class="feature-desc">Trade skills — you teach Java, they teach you design. No money needed, just knowledge.</p>
    </div>
    <div class="feature-card reveal">
      <div class="feature-icon">&#128274;</div>
      <div class="feature-title">Secure Accounts</div>
      <p class="feature-desc">Your data is safe. Secure login, session management, and privacy-first design throughout.</p>
    </div>
    <div class="feature-card reveal">
      <div class="feature-icon">&#11088;</div>
      <div class="feature-title">Ratings & Reviews</div>
      <p class="feature-desc">Build your reputation through honest peer reviews after every skill exchange session.</p>
    </div>
  </div>
</section>

<!-- ── HOW IT WORKS ── -->
<div class="how-section">
  <div class="how-inner">
    <p class="section-eyebrow reveal">&#128218; Step by Step</p>
    <h2 class="section-title reveal">How it works</h2>

    <div class="steps-grid">
      <div class="step-item reveal">
        <div class="step-num">1</div>
        <div class="step-title">Create Account</div>
        <p class="step-desc">Register in seconds with your student email.</p>
      </div>
      <div class="step-item reveal">
        <div class="step-num">2</div>
        <div class="step-title">Set Up Profile</div>
        <p class="step-desc">List your skills and what you want to learn.</p>
      </div>
      <div class="step-item reveal">
        <div class="step-num">3</div>
        <div class="step-title">Browse Students</div>
        <p class="step-desc">Explore profiles that match your needs.</p>
      </div>
      <div class="step-item reveal">
        <div class="step-num">4</div>
        <div class="step-title">Start Chatting</div>
        <p class="step-desc">Message them and agree on an exchange.</p>
      </div>
      <div class="step-item reveal">
        <div class="step-num">5</div>
        <div class="step-title">Learn &amp; Grow</div>
        <p class="step-desc">Exchange skills and leave a review after.</p>
      </div>
    </div>
  </div>
</div>

<!-- ── MISSION ── -->
<section class="section">
  <div class="mission-split">
    <div>
      <p class="section-eyebrow reveal">&#127775; Our Mission</p>
      <h2 class="section-title reveal">Built by students,<br>for students</h2>
      <p class="section-sub reveal" style="margin-bottom:1.5rem;">We believe every student has something valuable to teach. Our mission is to unlock that potential by making peer learning effortless and accessible to everyone.</p>
      <a href="register.jsp" class="btn-primary reveal">Join the Community &#8594;</a>
    </div>
    <div class="mission-visual reveal">
      <div class="mission-pill">
        <div class="mission-pill-icon">&#128187;</div>
        <span>Java &amp; Python Tutoring</span>
      </div>
      <div class="mission-pill">
        <div class="mission-pill-icon">&#127912;</div>
        <span>Photography,ART</span>
      </div>
      <div class="mission-pill">
        <div class="mission-pill-icon">&#128200;</div>
        <span>Braiding,Sports</span>
      </div>
      <div class="mission-pill">
        <div class="mission-pill-icon">&#9997;</div>
        <span>Essay Writing &amp; Editing</span>
      </div>
      <div class="mission-pill">
        <div class="mission-pill-icon">&#127925;</div>
        <span>Music</span>
      </div>
    </div>
  </div>
</section>

<!-- ── TESTIMONIALS ── -->
<section class="testimonial-section">
  <p class="section-eyebrow reveal">&#128483; Student Stories</p>
  <h2 class="section-title reveal">What students are saying</h2>

  <div class="testimonials-grid">
    <div class="testimonial-card reveal">
      <div class="testimonial-quote">"</div>
      <p class="testimonial-text">I was struggling with OOP for weeks. Found a student on here in 10 minutes who explained it better than any YouTube video.</p>
      <div class="testimonial-author">
        <div class="testimonial-avatar">TN</div>
        <div>
          <div class="testimonial-name">Thandi Nkosi</div>
          <div class="testimonial-role">Computer Science, Year 2</div>
        </div>
      </div>
    </div>
    <div class="testimonial-card reveal">
      <div class="testimonial-quote">"</div>
      <p class="testimonial-text">Traded my design skills for help with statistics. Best deal I ever made — we both got exactly what we needed.</p>
      <div class="testimonial-author">
        <div class="testimonial-avatar">KM</div>
        <div>
          <div class="testimonial-name">Kagiso Molefe</div>
          <div class="testimonial-role">Information Design, Year 3</div>
        </div>
      </div>
    </div>
    <div class="testimonial-card reveal">
      <div class="testimonial-quote">"</div>
      <p class="testimonial-text">The messaging feature makes coordinating so easy. Read receipts mean I always know if my study partner saw my message.</p>
      <div class="testimonial-author">
        <div class="testimonial-avatar">LV</div>
        <div>
          <div class="testimonial-name">Lindi Van Wyk</div>
          <div class="testimonial-role">Engineering, Year 1</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ── CTA BANNER ── -->
<div class="cta-banner reveal">
  <h2>Ready to start learning?</h2>
  <p>Join thousands of students already exchanging skills on the platform.</p>
  <a href="register.jsp" class="btn-white">&#128640; Create Account</a>
</div>

<!-- ── FOOTER ── -->
<footer>
  <p>&copy; 2026 StudentSkillExchange &nbsp;·&nbsp; <a href="AboutServlet">About</a> &nbsp;·&nbsp; <a href="contact.jsp">Contact</a> &nbsp;·&nbsp; <a href="register.jsp">Register</a></p>
</footer>

<script>
  // Scroll reveal
  var reveals = document.querySelectorAll('.reveal');

  function checkReveal() {
    reveals.forEach(function(el) {
      var top = el.getBoundingClientRect().top;
      if (top < window.innerHeight - 60) {
        el.classList.add('visible');
      }
    });
  }

  window.addEventListener('scroll', checkReveal);
  checkReveal();

  // Animate stat numbers
  function animateCount(el, target, suffix) {
    var start = 0;
    var duration = 1800;
    var step = target / (duration / 16);
    var interval = setInterval(function() {
      start += step;
      if (start >= target) {
        start = target;
        clearInterval(interval);
      }
      el.textContent = Math.floor(start).toLocaleString() + suffix;
    }, 16);
  }

  var statObserver = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        var nums = entry.target.querySelectorAll('.stat-number');
        nums[0] && animateCount(nums[0], 2400, '+');
        nums[1] && animateCount(nums[1], 180, '+');
        nums[2] && animateCount(nums[2], 950, '+');
        statObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  var strip = document.querySelector('.stats-strip');
  if (strip) statObserver.observe(strip);
</script>

</body>
</html>