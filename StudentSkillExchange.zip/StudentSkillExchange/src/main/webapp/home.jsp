<%@ page import="java.sql.*" %>
<%
String username = (String) session.getAttribute("username");

String initials = "IS"; 

if(username != null && username.length() > 0){
    initials = username.substring(0,1).toUpperCase();
}
%>

<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>

    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        body {
    font-family: 'Segoe UI';
    background: #f6f7f9;
    margin: 0;
}

/* NAVBAR */
.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 30px;
    background: white;
    border-bottom: 1px solid #ddd;
}

.logo {
    color: #1f7a5c;
}

.nav-links a {
    margin: 0 10px;
    text-decoration: none;
    color: #555;
}

.nav-right {
    display: flex;
    align-items: center;
    gap: 10px;
}

.avatar {
    background: #1f7a5c;
    color: white;
    width: 35px;
    height: 35px;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
}

.logout {
    border: 1px solid #ff6b6b;
    padding: 5px 10px;
    border-radius: 5px;
    color: #ff6b6b;
}

/* PROFILE HEADER */
.profile-header {
    background: white;
    margin: 20px;
    padding: 20px;
    border-radius: 10px;
    display: flex;
}

.big-avatar {
    width: 80px;
    height: 80px;
    background: #e6f4ef;
    border: 3px solid #1f7a5c;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 30px;
    color: #1f7a5c;
}

.profile-info {
    margin-left: 20px;
}

.profile-info span {
    color: #1f7a5c;
}

.sub {
    color: #888;
}

/* TAGS */
.skills {
    margin: 10px 0;
}

.tag {
    background: #e6f4ef;
    color: #1f7a5c;
    padding: 5px 10px;
    border-radius: 20px;
    margin-right: 5px;
}

/* FORM */
.skill-form {
    margin-top: 10px;
}

.skill-form input {
    padding: 8px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

.skill-form button {
    background: #1f7a5c;
    color: white;
    border: none;
    padding: 8px 12px;
    margin-left: 5px;
    border-radius: 5px;
}

/* GRID */
.grid {
    display: flex;
    gap: 20px;
    margin: 20px;
}

/* CARDS */
.card {
    background: white;
    padding: 20px;
    border-radius: 10px;
    flex: 1;
}

/* TEXTAREA */
textarea {
    width: 100%;
    height: 120px;
    border-radius: 5px;
    padding: 10px;
}

/* PORTFOLIO */
.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.upload-btn {
    background: #f0f0f0;
    padding: 5px 10px;
    border-radius: 5px;
    cursor: pointer;
}

.portfolio {
    display: flex;
    gap: 10px;
    margin-top: 10px;
}

.box {
    width: 100px;
    height: 100px;
    border: 2px dashed #ccc;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 30px;
    color: #aaa;
}

.hint {
    color: #999;
    font-size: 12px;
    margin-top: 10px;
}
    </style>
</head>

<body>

<div class="navbar">
    <h2 class="logo">StudentSkillExchange</h2>

    <div class="nav-links">
        <a href="profile.jsp">&#128221; My Profile</a>
        <a href="browse.jsp">&#128269; Browse</a>
        <a href="#">&#128488; Notifications</a>
        <a href="messages.jsp">&#128172; Messages</a>
    </div>
    <div class="nav-right">
        <div class="avatar"><%= initials %></div>
        <a href="LogoutServlet" class="logout">Log out</a>
    </div>
</div>    

<!-- HERO -->
<div class="profile-header">
    <div class="big-avatar"><%= initials %></div>

    <div class="profile-info">
        <h1>Welcome back, <span><%= username %></span> ?</h1>
        <p>University of Pretoria ? Joined March 2025</p>

    <div class="skills">
            <span class="tag">Web Design ?</span>
            <span class="tag">Graphic Design ?</span>
            <span class="tag">Photography ?</span>
        </div>

        <form action="ProfileServlet" method="post" class="skill-form">
            <input type="text" name="skill" placeholder="Add a skill...">
            <button name="action" value="addSkill">+ Add Skill</button>
        </form>
    </div>
</div>
<!-- MAIN CONTENT -->
<div class="grid">

    <!-- ABOUT -->
    <div class="card">
        <h3>About Me & My Skills</h3>

        <form action="ProfileServlet" method="post">
            <textarea name="description">Describe your skills...</textarea>
            <button name="action" value="saveDescription">Save Description</button>
        </form>
    </div>
    
     <!-- PORTFOLIO -->
    <div class="card">
        <div class="card-header">
            <h3>Work Portfolio</h3>

            <form action="ProfileServlet" method="post" enctype="multipart/form-data">
                <label class="upload-btn">
                    + Upload Photo
                    <input type="file" name="images" hidden>
                </label>
            </form>
        </div>

        <div class="portfolio">
            <div class="box">+</div>
            <div class="box">+</div>
            <div class="box">+</div>
        </div>

        <p class="hint">
            Click any slot or use the button to upload photos of your work
        </p>
    </div>

</div>

</body>
</html>
