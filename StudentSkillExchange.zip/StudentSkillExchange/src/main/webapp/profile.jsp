<%@page import="com.mycompany.studentskillexchange.model.User"%>
<%@page import="java.util.List"%>
<%@page import="java.util.ArrayList"%>
<%@page import="java.util.Arrays"%>
<%@page import="java.sql.*"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="com.mycompany.studentskillexchange.utils.DBConnection"%>
<%
    User user = (User) session.getAttribute("user");

    String name = "User";
    String initials = "?";
    List<String> userSkills = new ArrayList<>();

    if (user != null && user.getName() != null) {
        name = user.getName();
        String[] parts = name.trim().split(" ");
        if (parts.length >= 2) {
            initials = "" + parts[0].charAt(0) + parts[parts.length - 1].charAt(0);
        }
        // Load skills from DB
try (Connection conn = DBConnection.getConnection();
     PreparedStatement ps = conn.prepareStatement(
         "SELECT skill_name FROM user_skills WHERE user_id = ? ORDER BY created_at ASC")) {
    ps.setInt(1, user.getId());
    ResultSet rs = ps.executeQuery();
    while (rs.next()) {
        userSkills.add(rs.getString("skill_name"));
    }
} catch (Exception e) {
    e.printStackTrace();
}
    }
List<String> portfolioPhotos = new java.util.ArrayList<>();
if (user != null) {
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(
             "SELECT portfolio_photos FROM users WHERE id = ?")) {
        ps.setInt(1, user.getId());
        ResultSet rs = ps.executeQuery();
        if (rs.next() && rs.getString("portfolio_photos") != null) {
            String csv = rs.getString("portfolio_photos").trim();
            if (!csv.isEmpty()) {
                portfolioPhotos = new java.util.ArrayList<>(Arrays.asList(csv.split(",")));
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

// Load real stats
int totalMessages = 0;
int profileViews  = 0;
int skillCount    = userSkills.size();
double avgRating  = 0;
int ratingCount   = 0;

if (user != null) {
    try (Connection conn2 = DBConnection.getConnection()) {

        // Message count
        // Unread message count
        try (PreparedStatement ps2 = conn2.prepareStatement(
            "SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = FALSE")) {
             ps2.setInt(1, user.getId());
             ResultSet rs2 = ps2.executeQuery();
             if (rs2.next()) totalMessages = rs2.getInt(1);
        }

        // Profile views
        try (PreparedStatement ps3 = conn2.prepareStatement(
            "SELECT profile_views FROM users WHERE id = ?")) {
            ps3.setInt(1, user.getId());
            ResultSet rs3 = ps3.executeQuery();
            if (rs3.next()) profileViews = rs3.getInt(1);
        }

        // Average rating
        try (PreparedStatement ps4 = conn2.prepareStatement(
            "SELECT ROUND(AVG(rating),1), COUNT(*) FROM ratings WHERE rated_user = ?")) {
            ps4.setInt(1, user.getId());
            ResultSet rs4 = ps4.executeQuery();
            if (rs4.next()) {
                avgRating   = rs4.getDouble(1);
                ratingCount = rs4.getInt(2);
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
}
%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>StudentSkillExchange &#8212; My Profile</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&family=Fraunces:opsz,wght@9..144,400;9..144,600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --brand:       #1a6b4a;
      --brand-light: #e8f5ee;
      --brand-mid:   #2d9e6f;
      --accent:      #f4a24a;
      --accent-light:#fff4e6;
      --bg:          #f7f6f2;
      --surface:     #ffffff;
      --surface2:    #f0ede8;
      --text:        #1c1c1a;
      --text2:       #5a5853;
      --text3:       #9a9792;
      --border:      rgba(0,0,0,0.08);
      --border2:     rgba(0,0,0,0.14);
      --radius:      12px;
      --font-display:'Fraunces', Georgia, serif;
      --font-body:   'DM Sans', system-ui, sans-serif;
      --danger:      #e74c3c;
      --danger-light:#fdf0ef;
    }

    html, body {
      min-height: 100vh;
      background: var(--bg);
      color: var(--text);
      font-family: var(--font-body);
      font-size: 16px;
      line-height: 1.6;
    }

    /* ?? NAV ??????????????????????????????????????? */
    nav {
      position: sticky;
      top: 0;
      z-index: 100;
      background: var(--surface);
      border-bottom: 1px solid var(--border);
      height: 62px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
    }

    .nav-logo {
      font-family: var(--font-display);
      font-size: 22px;
      font-weight: 600;
      color: var(--brand);
      letter-spacing: -0.3px;
      text-decoration: none;
    }

    .nav-links {
      display: flex;
      align-items: center;
      gap: 2px;
    }

    .nav-link {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 7px 14px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      color: var(--text2);
      text-decoration: none;
      border: none;
      background: none;
      cursor: pointer;
      font-family: var(--font-body);
      transition: background 0.15s, color 0.15s;
      position: relative;
    }

    .nav-link:hover { background: var(--surface2); color: var(--text); }
    .nav-link.active { background: var(--brand-light); color: var(--brand); }

    .notif-dot::after {
      content: '';
      position: absolute;
      top: 8px; right: 10px;
      width: 7px; height: 7px;
      border-radius: 50%;
      background: #e05555;
    }

    .nav-right { display: flex; align-items: center; gap: 10px; }

    .nav-avatar {
      width: 36px; height: 36px;
      border-radius: 50%;
      background: var(--brand-light);
      border: 2px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-size: 13px; font-weight: 600; color: var(--brand);
      cursor: pointer;
      overflow: hidden;
    }

    .nav-avatar img { width: 100%; height: 100%; object-fit: cover; }

    .logout-btn {
      padding: 7px 16px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 500;
      color: #c0392b;
      border: 1px solid rgba(192,57,43,0.25);
      background: none;
      cursor: pointer;
      font-family: var(--font-body);
      transition: background 0.15s;
    }
    .logout-btn:hover { background: #fdf0ef; }
    
    .deactivate-btn {
  padding: 7px 16px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  color: #c0392b;
  border: 1px solid rgba(192,57,43,0.25);
  background: none;
  cursor: pointer;
  font-family: var(--font-body);
  transition: background 0.15s;
}
.deactivate-btn:hover { background: #fdf0ef; }

    /* ?? PAGE WRAPPER ?????????????????????????????? */
    .page {
      max-width: 1080px;
      margin: 0 auto;
      padding: 2rem 1.5rem 4rem;
    }

    /* ?? PROFILE HEADER CARD ??????????????????????? */
    .profile-header {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 2rem 2rem 1.75rem;
      display: flex;
      gap: 2rem;
      align-items: flex-start;
      margin-bottom: 1.5rem;
      animation: fadeUp 0.4s ease both;
    }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(12px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    .avatar-wrap { position: relative; flex-shrink: 0; }

    .avatar-lg {
      width: 104px; height: 104px;
      border-radius: 50%;
      background: var(--brand-light);
      border: 3px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-size: 34px; font-weight: 600; color: var(--brand);
      overflow: hidden;
      cursor: pointer;
      transition: opacity 0.15s;
    }
    .avatar-lg:hover { opacity: 0.88; }
    .avatar-lg img { width: 100%; height: 100%; object-fit: cover; }

    .avatar-edit {
      position: absolute;
      bottom: 4px; right: 2px;
      width: 28px; height: 28px;
      border-radius: 50%;
      background: var(--accent);
      border: 2px solid var(--surface);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      font-size: 13px;
      color: white;
      user-select: none;
    }

    .profile-info { flex: 1; min-width: 0; }

    .welcome-text {
      font-family: var(--font-display);
      font-size: 28px;
      font-weight: 600;
      color: var(--text);
      margin-bottom: 4px;
      line-height: 1.2;
    }
    .welcome-text span { color: var(--brand); }

    .profile-meta {
      font-size: 13px;
      color: var(--text3);
      margin-bottom: 14px;
    }

    /* Skills Tags */
    .skills-section { margin-bottom: 14px; }
    .skills-label {
      font-size: 12px;
      font-weight: 600;
      color: var(--text3);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 8px;
    }

    .skill-tags {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 10px;
    }

    .skill-tag {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 4px 12px;
      border-radius: 20px;
      background: var(--brand-light);
      color: var(--brand);
      font-size: 12px;
      font-weight: 500;
      border: 1px solid rgba(26,107,74,0.2);
    }

    .tag-remove {
      cursor: pointer;
      font-size: 10px;
      opacity: 0.55;
      line-height: 1;
      transition: opacity 0.12s;
    }
    .tag-remove:hover { opacity: 1; }

    .add-skill-row {
      display: flex;
      gap: 8px;
      align-items: center;
    }

    .input-sm {
      padding: 8px 13px;
      border-radius: 8px;
      border: 1px solid var(--border2);
      background: var(--bg);
      font-size: 13px;
      font-family: var(--font-body);
      color: var(--text);
      outline: none;
      width: 200px;
      transition: border-color 0.15s;
    }
    .input-sm:focus { border-color: var(--brand); }

    /* ?? BUTTONS ??????????????????????????????????? */
    .btn {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 9px 18px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 500;
      font-family: var(--font-body);
      cursor: pointer;
      border: none;
      transition: background 0.15s, transform 0.1s;
    }
    .btn:active { transform: scale(0.97); }
    .btn-primary { background: var(--brand); color: #fff; }
    .btn-primary:hover { background: #155c3e; }
    .btn-outline { background: none; border: 1px solid var(--border2); color: var(--text2); }
    .btn-outline:hover { background: var(--surface2); color: var(--text); }

    /* ?? GRID SECTIONS ????????????????????????????? */
    .two-col {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1.25rem;
      margin-bottom: 1.25rem;
      animation: fadeUp 0.4s 0.1s ease both;
    }

    @media (max-width: 720px) {
      .two-col { grid-template-columns: 1fr; }
      .profile-header { flex-direction: column; align-items: center; text-align: center; }
      .add-skill-row { justify-content: center; }
      .skill-tags { justify-content: center; }
      nav { padding: 0 1rem; }
      .nav-links { display: none; }
      .page { padding: 1.25rem 1rem 3rem; }
    }

    /* ?? CARD ?????????????????????????????????????? */
    .card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.5rem;
    }

    .card-title {
      font-size: 14px;
      font-weight: 600;
      color: var(--text);
      margin-bottom: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    textarea.bio-area {
      width: 100%;
      padding: 11px 14px;
      border-radius: 8px;
      border: 1px solid var(--border2);
      background: var(--bg);
      font-size: 13px;
      font-family: var(--font-body);
      color: var(--text);
      resize: vertical;
      min-height: 110px;
      outline: none;
      line-height: 1.6;
      transition: border-color 0.15s;
    }
    textarea.bio-area:focus { border-color: var(--brand); }

    .save-row {
      display: flex;
      justify-content: flex-end;
      margin-top: 10px;
    }

    /* ?? PORTFOLIO PHOTOS ?????????????????????????? */
    .photos-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
      margin-bottom: 10px;
    }

    .photo-slot {
      aspect-ratio: 1;
      border-radius: 8px;
      border: 1.5px dashed var(--border2);
      background: var(--bg);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      overflow: hidden;
      position: relative;
      transition: border-color 0.15s, background 0.15s;
    }
    .photo-slot:hover { border-color: var(--brand); background: var(--brand-light); }
    .photo-slot img { width: 100%; height: 100%; object-fit: cover; display: block; }

    .photo-add-icon {
      font-size: 26px;
      color: var(--text3);
      line-height: 1;
      pointer-events: none;
    }

    .photo-remove {
      position: absolute;
      top: 5px; right: 5px;
      width: 22px; height: 22px;
      border-radius: 50%;
      background: rgba(0,0,0,0.55);
      color: white;
      display: flex; align-items: center; justify-content: center;
      font-size: 10px;
      cursor: pointer;
      opacity: 0;
      transition: opacity 0.15s;
    }
    .photo-slot:hover .photo-remove { opacity: 1; }
    .photo-slot.filled .photo-remove { opacity: 1; }

    /* ?? STATS ????????????????????????????????????? */
    .stats-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.5rem;
      margin-bottom: 1.25rem;
      animation: fadeUp 0.4s 0.2s ease both;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 12px;
    }

    @media (max-width: 580px) {
      .stats-grid { grid-template-columns: repeat(2, 1fr); }
    }

    .stat-box {
      background: var(--bg);
      border-radius: 10px;
      padding: 16px 12px;
      text-align: center;
    }

    .stat-num {
      font-family: var(--font-display);
      font-size: 26px;
      font-weight: 600;
      color: var(--brand);
      line-height: 1;
      margin-bottom: 4px;
    }

    .stat-num.accent { color: var(--accent); }

    .stat-label {
      font-size: 12px;
      color: var(--text3);
    }

    /* ?? TOAST ????????????????????????????????????? */
    #toast {
      position: fixed;
      bottom: 28px;
      left: 50%;
      transform: translateX(-50%) translateY(10px);
      background: #1c1c1a;
      color: #fff;
      padding: 11px 22px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 500;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.25s, transform 0.25s;
      white-space: nowrap;
      z-index: 9999;
    }
    #toast.show {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
    /* DEACTIVATE MODAL */
    #deactivateOverlay {
      display: none; position: fixed; inset: 0; z-index: 9998;
      background: rgba(0,0,0,0.55);
      align-items: center; justify-content: center;
    }
    #deactivateOverlay.open { display: flex; }

    .modal-box {
      background: var(--surface); border-radius: 16px;
      padding: 2.5rem 2rem; max-width: 430px; width: 92%;
      text-align: center;
      box-shadow: 0 24px 64px rgba(0,0,0,0.25);
      animation: fadeUp 0.25s ease both;
    }
    .modal-icon  { font-size: 50px; margin-bottom: 16px; }
    .modal-title {
      font-family: var(--font-display); font-size: 24px;
      color: var(--text); margin-bottom: 12px;
    }
    .modal-body {
      font-size: 13px; color: var(--text2);
      line-height: 1.75; margin-bottom: 16px;
    }
    .modal-body strong { color: var(--danger); }
    .modal-hint {
      font-size: 12px; color: var(--text3); margin-bottom: 12px;
    }
    .modal-hint span {
      color: var(--danger); font-weight: 700; letter-spacing: 2px;
    }
    .confirm-input {
      width: 100%; padding: 12px 14px; border-radius: 8px;
      border: 1.5px solid var(--border2); background: var(--bg);
      font-size: 15px; font-family: var(--font-body); color: var(--text);
      outline: none; text-align: center;
      letter-spacing: 4px; font-weight: 700;
      margin-bottom: 20px; transition: border-color 0.2s, background 0.2s;
    }
    .confirm-input:focus  { border-color: var(--border2); }
    .confirm-input.valid  {
      border-color: var(--danger);
      background: var(--danger-light);
      color: var(--danger);
    }
    .modal-actions { display: flex; gap: 10px; justify-content: center; }
    .btn-cancel {
      padding: 11px 28px; border-radius: 8px;
      font-size: 13px; font-weight: 500;
      border: 1px solid var(--border2); background: none;
      color: var(--text2); cursor: pointer; font-family: var(--font-body);
      transition: background 0.15s;
    }
    .btn-cancel:hover { background: var(--surface2); }
    .btn-danger {
      padding: 11px 28px; border-radius: 8px;
      font-size: 13px; font-weight: 600;
      border: none; background: var(--danger); color: #fff;
      cursor: pointer; font-family: var(--font-body);
      transition: background 0.15s, opacity 0.2s;
    }
    .btn-danger:hover:not(:disabled) { background: #a93226; }
    .btn-danger:disabled { opacity: 0.35; cursor: not-allowed; }

    /* RESPONSIVE */
    @media (max-width: 720px) {
      .two-col { grid-template-columns: 1fr; }
      .profile-header { flex-direction: column; align-items: center; text-align: center; }
      .add-skill-row  { justify-content: center; }
      .skill-tags     { justify-content: center; }
      nav             { padding: 0 1rem; }
      .nav-links      { display: none; }
      .page           { padding: 1.25rem 1rem 3rem; }
    }
    @media (max-width: 580px) {
      .stats-grid { grid-template-columns: repeat(2, 1fr); }
    }

    /* ?? HIDDEN INPUTS ????????????????????????????? */
    #avatarInput, #photoInput { display: none; }
  </style>
</head>
<body>

<!-- ?? TOAST ????????????????????? -->
<div id="toast"></div>

<!-- ??????????????????????????????????????????????????
     DEACTIVATE CONFIRMATION MODAL
     ?????????????????????????????????????????????????? -->
<div id="deactivateOverlay">
  <div class="modal-box">
    <div class="modal-icon">&#9888;?</div>
    <h2 class="modal-title">Deactivate Account?</h2>
    <p class="modal-body">
      This will <strong>permanently delete</strong> your account
      and <strong>all your data</strong> from our system.<br><br>
      Your profile, skills, and history will be
      <strong>gone forever and cannot be recovered.</strong>
    </p>
    <p class="modal-hint">Type <span>CONFIRM</span> below to proceed:</p>

    <form action="<%=request.getContextPath()%>/DeactivateAccountServlet"
          method="post"
          onsubmit="return validateConfirm()">

      <input
        type="text"
        name="confirmText"
        id="confirmInput"
        class="confirm-input"
        placeholder="CONFIRM"
        autocomplete="off"
        oninput="handleConfirmInput(this)"
      >

      <div class="modal-actions">
        <button type="button" class="btn-cancel" onclick="closeModal()">
          Cancel
        </button>
        <button type="submit" class="btn-danger" id="deleteBtn" disabled>
          &#10060;? Delete My Account
        </button>
      </div>
    </form>
  </div>
</div>

<!-- ?? HIDDEN FILE INPUTS ???????? -->
<input type="file" id="avatarInput" accept="image/*">
<input type="file" id="photoInput" accept="image/*" onchange="handlePhotoSelect(this)">

<!-- ?? NAV ???????????????????????????????????????? -->
<nav>
  <a class="nav-logo" href="#">StudentSkillExchange</a>

  <div class="nav-links">
    <a class="nav-link" href="profile.jsp">&#128221; My Profile</a>
    <a class="nav-link" href="BrowseServlet">&#128269; Browse</a>
    <div style="position:relative;display:inline-flex;">
  <a class="nav-link" href="notifications.jsp" id="notifNavBtn">
    &#128276; Notifications
  </a>
  <span id="navNotifBadge" style="
    display:none;
    position:absolute;
    top:4px; right:6px;
    background:#e05555;
    color:white;
    font-size:10px;
    font-weight:700;
    min-width:17px; height:17px;
    border-radius:10px;
    align-items:center;
    justify-content:center;
    padding:0 4px;
    pointer-events:none;
  ">0</span>
</div>

    <a class="nav-link" href="messages.jsp">&#128172; Messages</a>
  </div>

  <div class="nav-right">
    <div class="nav-avatar" id="navAvatar" title="My Profile"><%= initials.toUpperCase() %></div>
    <button class="deactivate-btn" onclick="openModal()">
      Deactivate account
    </button>
    <a href="LogoutServlet" class="logout-btn">Log out</a>
  </div>
</nav>

<!-- ?? MAIN ??????????????????????????????????????? -->
<main class="page">

  <!-- Profile Header -->
  <div class="profile-header">
    <div class="avatar-wrap">
      <div class="avatar-lg" id="profileAvatar" onclick="document.getElementById('avatarInput').click()" title="Change profile photo">
        <%= initials.toUpperCase() %>
      </div>
      <div class="avatar-edit" onclick="document.getElementById('avatarInput').click()" title="Upload photo">&#9998;</div>
    </div>

    <div class="profile-info">
      <h1 class="welcome-text">Welcome, <%= name %>! &#128075;</h1>
     <%
    String joinedText = "Unknown";
    if (user != null && user.getJoinDate() != null) {
        try {
            // Parse the raw timestamp string e.g. "2026-03-15 09:32:00.0"
            SimpleDateFormat parser  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
            SimpleDateFormat display = new SimpleDateFormat("MMMM yyyy");
            Date parsedDate = parser.parse(user.getJoinDate());
            joinedText = display.format(parsedDate);
        } catch (Exception e) {
            joinedText = user.getJoinDate(); // fallback: show raw value
        }
    }
%>
<p class="profile-meta" id="profileMeta">
    University of Mpumalanga &bull; Joined <%= joinedText %>
</p> 
      <p class="profile-meta" style="margin-top:2px;">
         <%= user != null && user.getRole() != null ? user.getRole().substring(0,1).toUpperCase() + user.getRole().substring(1).toLowerCase() : "" %>
      </p>
      
      <div class="skills-section">
        <div class="skills-label">My Skills</div>
        <div class="skill-tags" id="skillTags">
            <% for (String skill : userSkills) { %>
               <span class="skill-tag">
                  <%= skill %>
                  <span class="tag-remove" onclick="removeSkill(this, '<%= skill.replace("'", "\\'") %>')">&#10005;</span>
                </span>
            <% } %>
        </div>

        <div class="add-skill-row">
          <input
            class="input-sm"
            id="skillInput"
            placeholder="Add a skill..."
            onkeydown="if(event.key==='Enter') addSkill()"
          >
          <button class="btn btn-primary" onclick="addSkill()">+ Add Skill</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Bio + Portfolio -->
  <div class="two-col">

    <!-- Bio Card -->
    <div class="card">
      <div class="card-title">
        About Me &amp; My Skills
        <button class="btn btn-outline" id="editBioBtn" onclick="enableBioEdit()"
                style="font-size:12px;padding:5px 12px;">&#9998; Edit</button>
      </div>
      <textarea
         class="bio-area"
         id="bioText"
         placeholder="Describe what you can offer, your experience, style and availability..."
         disabled
      ><%= user != null && user.getBio() != null ? user.getBio() : "" %></textarea>
      <div class="save-row" id="saveBioRow" style="display:none;">
        <button class="btn btn-outline" onclick="cancelBioEdit()" style="margin-right:8px;">Cancel</button>
        <button class="btn btn-primary" onclick="saveBio()">Save Description</button>
      </div>
    </div>

    <!-- Portfolio Card -->
<div class="card">
  <div class="card-title">
    Work Portfolio
    <label for="photoInput" class="btn btn-outline"
           style="font-size:12px;padding:5px 12px;cursor:pointer;">+ Upload Photo</label>
  </div>

  <div class="photos-grid" id="photosGrid">
    <%-- Render saved photos first --%>
    <% for (String photoUrl : portfolioPhotos) { %>
       <div class="photo-slot filled">
         <img src="<%= request.getContextPath() + "/" + photoUrl %>" alt="Work photo" style="width:100%;height:100%;object-fit:cover;">
        <div class="photo-remove" onclick="removePhoto(this, '<%= photoUrl %>')" title="Remove">&#10005;</div>
      </div>
    <% } %>

    <%-- Render empty slots for remaining space (max 6) --%>
    <% for (int i = portfolioPhotos.size(); i < 6; i++) { %>
      <div class="photo-slot empty" onclick="triggerPhoto(this)">
        <div class="photo-add-icon">+</div>
      </div>
    <% } %>
  </div>

  <p style="font-size:12px;color:var(--text3);">
    Click any slot or use the button to upload. Max 6 photos, 5MB each.
  </p>
</div>

  <!-- Stats -->
<div class="stats-card">
  <div class="card-title" style="margin-bottom:1rem;">Quick Stats</div>
  <div class="stats-grid">
    <div class="stat-box">
      <div class="stat-num"><%= profileViews %></div>
      <div class="stat-label">Profile Views</div>
    </div>
    <div class="stat-box">
      <div class="stat-num"><%= totalMessages %></div>
      <div class="stat-label">Unread Messages</div>
    </div>
    <div class="stat-box">
      <div class="stat-num"><%= skillCount %></div>
      <div class="stat-label">Skills Added</div>
    </div>
    <div class="stat-box">
      <div class="stat-num accent">
        <%
          if (ratingCount > 0) {
            out.print("&#9733; " + avgRating);
          } else {
            out.print("&#9733; &mdash;");
          }
        %>
      </div>
      <div class="stat-label">
        <%= ratingCount > 0 ? ratingCount + " review" + (ratingCount != 1 ? "s" : "") : "No ratings yet" %>
      </div>
    </div>
  </div>
</div>

</main>

<script>
  /* ?? TOAST ???????????????????????????????????? */
  function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove('show'), 2600);
  }
  
  /* DEACTIVATE MODAL */
  function openModal() {
    document.getElementById('deactivateOverlay').classList.add('open');
    setTimeout(() => document.getElementById('confirmInput').focus(), 200);
  }

  function closeModal() {
    document.getElementById('deactivateOverlay').classList.remove('open');
    // Always reset input and button on close
    const input = document.getElementById('confirmInput');
    const btn   = document.getElementById('deleteBtn');
    input.value = '';
    input.classList.remove('valid');
    btn.disabled = true;
  }

  function handleConfirmInput(input) {
    const btn = document.getElementById('deleteBtn');
    if (input.value.trim() === 'CONFIRM') {
      input.classList.add('valid');
      btn.disabled = false;
    } else {
      input.classList.remove('valid');
      btn.disabled = true;
    }
  }

  function validateConfirm() {
    if (document.getElementById('confirmInput').value.trim() !== 'CONFIRM') {
      showToast('Please type CONFIRM to proceed');
      return false;
    }
    return true;
  }

  // Click outside modal to close
  document.getElementById('deactivateOverlay').addEventListener('click', function (e) {
    if (e.target === this) closeModal();
  });

  // Escape key closes modal
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeModal();
  });

  /* ?? LOGOUT ??????????????????????????????????? */
  function handleLogout() {
    showToast('Logged out successfully');
    setTimeout(() => {
      window.location.href = 'login.jsp'; // adjust to your login route
    }, 1000);
  }

  /* ?? AVATAR UPLOAD ???????????????????????????? */
  document.getElementById('avatarInput').addEventListener('change', function () {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (e) {
      const src = e.target.result;
      // Big avatar
      document.getElementById('profileAvatar').innerHTML =
        `<img src="${src}" alt="Profile photo">`;
      // Nav avatar
      document.getElementById('navAvatar').innerHTML =
        `<img src="${src}" alt="Profile photo">`;
      showToast('Profile photo updated!');
    };
    reader.readAsDataURL(file);
  });

  /* ?? SKILLS ??????????????????????????????????? */
function addSkill() {
    const input = document.getElementById('skillInput');
    const val = input.value.trim();
    if (!val) return;

    // Client-side duplicate check
    const existing = [...document.querySelectorAll('#skillTags .skill-tag')]
        .map(t => t.firstChild.textContent.trim().toLowerCase());
    if (existing.includes(val.toLowerCase())) {
        showToast('You already have that skill!');
        return;
    }

    // POST to servlet
    const formData = new FormData();
    formData.append('skill', val);

    fetch('AddSkillServlet', {
       method: 'POST',
       headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
       body: 'skill=' + encodeURIComponent(val)
    })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                // Add tag to DOM
                const tag = document.createElement('span');
                tag.className = 'skill-tag';
                tag.innerHTML = escapeHtml(val) +
                    ' <span class="tag-remove" onclick="removeSkill(this, \'' +
                    escapeJs(val) + '\')">&#10005;</span>';
                document.getElementById('skillTags').appendChild(tag);
                input.value = '';
                input.focus();
                showToast('"' + val + '" added to your skills!');
            } else {
                showToast(data.message || 'Could not add skill');
            }
        })
        .catch(() => showToast('Network error ? please try again'));
}

function removeSkill(el, skillName) {
    const tag = el.closest('.skill-tag');

    const formData = new FormData();
    formData.append('skill', skillName);

    fetch('RemoveSkillServlet', {
       method: 'POST',
       headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
       body: 'skill=' + encodeURIComponent(skillName)
       })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                tag.remove();
                showToast('"' + skillName + '" removed');
            } else {
                showToast(data.message || 'Could not remove skill');
            }
        })
        .catch(() => showToast('Network error ? please try again'));
}

function escapeHtml(str) {
    return str.replace(/[&<>"']/g, c =>
        ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function escapeJs(str) {
    return str.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}

  /* ?? BIO ??????????????????????????????????????? */
  var originalBio = '';

function enableBioEdit() {
  var textarea = document.getElementById('bioText');
  originalBio  = textarea.value;
  textarea.disabled = false;
  textarea.focus();
  document.getElementById('editBioBtn').style.display = 'none';
  document.getElementById('saveBioRow').style.display = 'flex';
}

function cancelBioEdit() {
  var textarea = document.getElementById('bioText');
  textarea.value    = originalBio;
  textarea.disabled = true;
  document.getElementById('editBioBtn').style.display = '';
  document.getElementById('saveBioRow').style.display = 'none';
}

function saveBio() {
  var bio = document.getElementById('bioText').value.trim();

  fetch('SaveBioServlet', {
    method:  'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body:    'bio=' + encodeURIComponent(bio)
  })
  .then(function(r) { return r.json(); })
  .then(function(res) {
    if (res.success) {
      document.getElementById('bioText').disabled = true;
      document.getElementById('editBioBtn').style.display = '';
      document.getElementById('saveBioRow').style.display = 'none';
      showToast('Description saved!');
    } else {
      showToast(res.message || 'Could not save description');
    }
  })
  .catch(function() { showToast('Network error'); });
}

  /* ?? PORTFOLIO PHOTOS ?????????????????????????? */
  var targetSlot = null;

function triggerPhoto(slot) {
  targetSlot = slot;
  document.getElementById('photoInput').click();
}

function handlePhotoSelect(input) {
  var file = input.files[0];
  if (!file) return;

  var formData = new FormData();
  formData.append('photo', file);

  fetch('PortfolioServlet', { method: 'POST', body: formData })
    .then(function(r) { return r.json(); })
    .then(function(res) {
      if (res.success) {
        // Find the slot to fill
        var slot = targetSlot || document.querySelector('.photo-slot.empty');
        if (!slot) { showToast('No empty slots left'); return; }

        // Replace empty slot with filled slot
        slot.className = 'photo-slot filled';
        slot.onclick   = null;
        slot.innerHTML =
  '<img src="' + window.location.pathname.replace('/profile.jsp','') + '/' + res.url + '" alt="Work photo" style="width:100%;height:100%;object-fit:cover;">' +
  '<div class="photo-remove" onclick="removePhoto(this, \'' + res.url + '\')" title="Remove">&#10005;</div>';

        targetSlot = null;
        showToast('Photo uploaded!');
      } else {
        showToast(res.message || 'Upload failed');
      }
    })
    .catch(function() { showToast('Upload failed ? try again'); });

  input.value = ''; // reset so same file can be re-selected
}

function removePhoto(el, photoUrl) {
  if (!confirm('Remove this photo?')) return;

  fetch('PortfolioServlet', {
    method:  'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body:    'action=remove&url=' + encodeURIComponent(photoUrl)
  })
  .then(function(r) { return r.json(); })
  .then(function(res) {
    if (res.success) {
      var slot = el.closest('.photo-slot');
      // Replace filled slot with empty slot
      slot.className = 'photo-slot empty';
      slot.innerHTML = '<div class="photo-add-icon">+</div>';
      slot.onclick   = function() { triggerPhoto(slot); };
      showToast('Photo removed');
    } else {
      showToast(res.message || 'Could not remove photo');
    }
  })
  .catch(function() { showToast('Network error'); });
}

function refreshNotifBadge() {
  fetch('NotificationServlet?action=count')
    .then(r => r.json())
    .then(data => {
      const badge = document.getElementById('navNotifBadge');
      if (data.unread > 0) {
        badge.textContent = data.unread > 99 ? '99+' : data.unread;
        badge.style.display = 'flex';
      } else {
        badge.style.display = 'none';
      }
    })
    .catch(() => {});
}
refreshNotifBadge();
setInterval(refreshNotifBadge, 30000);


</script>

</body>
</html>