<%@page import="com.mycompany.studentskillexchange.model.User"%>
<%@page import="java.util.List"%>
<%@page import="java.util.ArrayList"%>
<%@page import="java.util.Arrays"%>
<%
    // Current logged-in user (for nav)
    User currentUser = (User) session.getAttribute("user");
    String currentInitials = "?";
    if (currentUser != null && currentUser.getName() != null) {
        String[] cp = currentUser.getName().trim().split("\\s+");
        currentInitials = cp.length >= 2
            ? "" + cp[0].charAt(0) + cp[cp.length-1].charAt(0)
            : "" + cp[0].charAt(0);
    }

    // Profile being viewed
    User profileUser = (User) request.getAttribute("profileUser");
    List<String> profileSkills = (List<String>) request.getAttribute("profileSkills");
    if (profileSkills == null) profileSkills = new ArrayList<>();

    String pName     = profileUser != null ? profileUser.getName()    : "Unknown";
    String pRole     = profileUser != null && profileUser.getRole() != null ? profileUser.getRole() : "";
    String pBio      = profileUser != null && profileUser.getBio()  != null ? profileUser.getBio()  : "";
    String pJoin     = profileUser != null && profileUser.getJoinDate() != null ? profileUser.getJoinDate() : "";
    String pPortfolio= profileUser != null && profileUser.getPortfolio() != null ? profileUser.getPortfolio() : "";
    int    pId       = profileUser != null ? profileUser.getId() : 0;

    // Build initials
    String[] pParts = pName.trim().split("\\s+");
    String pInitials = pParts.length >= 2
        ? "" + pParts[0].charAt(0) + pParts[pParts.length-1].charAt(0)
        : "" + pParts[0].charAt(0);
    pInitials = pInitials.toUpperCase();

    // Role display
    String pRoleDisplay = pRole.isEmpty() ? "" :
        pRole.substring(0,1).toUpperCase() + pRole.substring(1).toLowerCase();

    // Portfolio photos
    List<String> portfolioPhotos = new ArrayList<>();
    if (!pPortfolio.isEmpty()) {
        portfolioPhotos = Arrays.asList(pPortfolio.split(","));
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><%= pName %> ? StudentSkillExchange</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,400&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --brand:        #1a6b4a;
      --brand-light:  #e8f5ee;
      --brand-mid:    #2d9e6f;
      --brand-dark:   #114530;
      --accent:       #f4a24a;
      --accent-light: #fff4e6;
      --bg:           #f7f6f2;
      --surface:      #ffffff;
      --surface2:     #f0ede8;
      --text:         #1c1c1a;
      --text2:        #5a5853;
      --text3:        #9a9792;
      --border:       rgba(0,0,0,0.08);
      --border2:      rgba(0,0,0,0.14);
      --radius:       12px;
      --font-display: 'Fraunces', Georgia, serif;
      --font-body:    'DM Sans', system-ui, sans-serif;
    }

    html, body {
      min-height: 100vh;
      background: var(--bg);
      color: var(--text);
      font-family: var(--font-body);
      font-size: 16px;
      line-height: 1.6;
    }

    /* NAV */
    nav {
      position: sticky; top: 0; z-index: 100;
      background: var(--surface);
      border-bottom: 1px solid var(--border);
      height: 62px;
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 2rem;
    }
    .nav-logo {
      font-family: var(--font-display);
      font-size: 22px; font-weight: 600;
      color: var(--brand); letter-spacing: -0.3px; text-decoration: none;
    }
    .nav-links { display: flex; align-items: center; gap: 2px; }
    .nav-link {
      display: flex; align-items: center; gap: 6px;
      padding: 7px 14px; border-radius: 8px;
      font-size: 14px; font-weight: 500; color: var(--text2);
      text-decoration: none; border: none; background: none;
      cursor: pointer; font-family: var(--font-body);
      transition: background 0.15s, color 0.15s; position: relative;
    }
    .nav-link:hover { background: var(--surface2); color: var(--text); }
    .nav-link.active { background: var(--brand-light); color: var(--brand); }
    .notif-dot::after {
      content: ''; position: absolute; top: 8px; right: 10px;
      width: 7px; height: 7px; border-radius: 50%; background: #e05555;
    }
    .nav-right { display: flex; align-items: center; gap: 10px; }
    .nav-avatar {
      width: 36px; height: 36px; border-radius: 50%;
      background: var(--brand-light); border: 2px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-size: 13px; font-weight: 600; color: var(--brand); cursor: pointer;
    }
    .logout-btn {
      padding: 7px 16px; border-radius: 8px; font-size: 13px; font-weight: 500;
      color: #c0392b; border: 1px solid rgba(192,57,43,0.25);
      background: none; cursor: pointer; font-family: var(--font-body);
      transition: background 0.15s; text-decoration: none;
    }
    .logout-btn:hover { background: #fdf0ef; }

    /* PAGE */
    .page {
      max-width: 900px;
      margin: 0 auto;
      padding: 2.5rem 1.5rem 5rem;
    }

    /* BACK BUTTON */
    .back-btn {
      display: inline-flex; align-items: center; gap: 7px;
      padding: 8px 16px; border-radius: 8px;
      border: 1px solid var(--border2); background: var(--surface);
      font-size: 13px; font-weight: 500; color: var(--text2);
      text-decoration: none; cursor: pointer;
      transition: background 0.15s, color 0.15s;
      margin-bottom: 1.75rem;
      font-family: var(--font-body);
    }
    .back-btn:hover { background: var(--brand-light); color: var(--brand); border-color: var(--brand-mid); }

    /* HERO CARD */
    .hero-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 20px;
      overflow: hidden;
      margin-bottom: 1.5rem;
      animation: fadeUp 0.5s ease both;
    }

    .hero-banner {
      height: 120px;
      background: linear-gradient(135deg, var(--brand-dark) 0%, var(--brand) 50%, var(--brand-mid) 100%);
      position: relative;
      overflow: hidden;
    }

    .hero-banner::before {
      content: '';
      position: absolute; inset: 0;
      background-image: radial-gradient(circle at 20% 50%, rgba(255,255,255,0.08) 0%, transparent 60%),
                        radial-gradient(circle at 80% 20%, rgba(255,255,255,0.06) 0%, transparent 50%);
    }

    .hero-banner::after {
      content: '';
      position: absolute; bottom: -1px; left: 0; right: 0;
      height: 40px;
      background: var(--surface);
      clip-path: ellipse(55% 100% at 50% 100%);
    }

    .hero-body {
      padding: 0 2rem 2rem;
      position: relative;
    }

    .hero-avatar-wrap {
      position: relative;
      display: inline-block;
      margin-top: -52px;
      margin-bottom: 1rem;
    }

    .hero-avatar {
      width: 104px; height: 104px;
      border-radius: 50%;
      background: var(--brand-light);
      border: 4px solid var(--surface);
      box-shadow: 0 4px 20px rgba(26,107,74,0.2);
      display: flex; align-items: center; justify-content: center;
      font-family: var(--font-display);
      font-size: 36px; font-weight: 600; color: var(--brand);
    }

    .role-badge {
      position: absolute;
      bottom: 4px; right: -4px;
      background: var(--accent);
      color: white;
      font-size: 10px; font-weight: 600;
      padding: 3px 9px; border-radius: 10px;
      border: 2px solid var(--surface);
      text-transform: uppercase; letter-spacing: 0.05em;
      white-space: nowrap;
    }

    .hero-name {
      font-family: var(--font-display);
      font-size: 32px; font-weight: 600;
      color: var(--text); line-height: 1.1;
      margin-bottom: 6px;
    }

    .hero-meta {
      font-size: 13px; color: var(--text3);
      margin-bottom: 1.25rem;
      display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
    }

    .hero-meta-dot {
      width: 4px; height: 4px; border-radius: 50%;
      background: var(--text3); display: inline-block;
    }

    .hero-actions {
      display: flex; gap: 10px; flex-wrap: wrap;
    }

    .btn {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 10px 20px; border-radius: 10px;
      font-size: 14px; font-weight: 500;
      font-family: var(--font-body); cursor: pointer; border: none;
      transition: background 0.15s, transform 0.1s;
      text-decoration: none;
    }
    .btn:active { transform: scale(0.97); }
    .btn-primary { background: var(--brand); color: #fff; }
    .btn-primary:hover { background: #155c3e; }
    .btn-outline {
      background: none; border: 1.5px solid var(--border2);
      color: var(--text2);
    }
    .btn-outline:hover { background: var(--surface2); color: var(--text); }

    /* GRID */
    .profile-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1.25rem;
      animation: fadeUp 0.5s 0.1s ease both;
    }

    @media (max-width: 680px) {
      .profile-grid { grid-template-columns: 1fr; }
      .hero-body { padding: 0 1.25rem 1.5rem; }
      .hero-name { font-size: 26px; }
      nav { padding: 0 1rem; }
      .nav-links { display: none; }
    }

    /* CARDS */
    .card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.5rem;
    }

    .card-full {
      grid-column: 1 / -1;
    }

    .card-label {
      font-size: 11px; font-weight: 600;
      color: var(--text3); text-transform: uppercase;
      letter-spacing: 0.07em; margin-bottom: 1rem;
      display: flex; align-items: center; gap: 7px;
    }
    .card-label::after {
      content: ''; flex: 1; height: 1px; background: var(--border);
    }

    /* SKILLS */
    .skill-tags {
      display: flex; flex-wrap: wrap; gap: 8px;
    }

    .skill-tag {
      padding: 6px 14px; border-radius: 20px;
      background: var(--brand-light); color: var(--brand);
      font-size: 13px; font-weight: 500;
      border: 1px solid rgba(26,107,74,0.2);
      transition: transform 0.15s, box-shadow 0.15s;
    }
    .skill-tag:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(26,107,74,0.15);
    }

    .no-skills {
      font-size: 13px; color: var(--text3); font-style: italic;
    }

    /* BIO */
    .bio-text {
      font-size: 14px; color: var(--text2);
      line-height: 1.7; white-space: pre-wrap;
    }

    .no-bio {
      font-size: 13px; color: var(--text3); font-style: italic;
    }

    /* PORTFOLIO */
    .photos-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
    }

    .photo-slot {
      aspect-ratio: 1;
      border-radius: 10px;
      overflow: hidden;
      background: var(--bg);
      border: 1.5px solid var(--border2);
      position: relative;
    }

    .photo-slot img {
      width: 100%; height: 100%;
      object-fit: cover; display: block;
      transition: transform 0.3s;
    }

    .photo-slot:hover img { transform: scale(1.05); }

    .photo-slot.empty {
      display: flex; align-items: center; justify-content: center;
    }

    .photo-empty-icon {
      font-size: 22px; color: var(--border2);
    }

    /* STATS ROW */
    .stats-row {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 10px;
      animation: fadeUp 0.5s 0.2s ease both;
      margin-bottom: 1.25rem;
    }

    .stat-box {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.25rem;
      text-align: center;
    }

    .stat-num {
      font-family: var(--font-display);
      font-size: 28px; font-weight: 600;
      color: var(--brand); line-height: 1;
      margin-bottom: 4px;
    }

    .stat-label {
      font-size: 12px; color: var(--text3);
    }

    /* ANIMATIONS */
    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(16px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    /* TOAST */
    #toast {
      position: fixed; bottom: 28px; left: 50%;
      transform: translateX(-50%) translateY(10px);
      background: #1c1c1a; color: #fff;
      padding: 11px 22px; border-radius: 8px;
      font-size: 13px; font-weight: 500;
      opacity: 0; pointer-events: none;
      transition: opacity 0.25s, transform 0.25s;
      white-space: nowrap; z-index: 9999;
    }
    #toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }
  </style>
</head>
<body>

<div id="toast"></div>

<!-- NAV -->
<nav>
  <a class="nav-logo" href="#">StudentSkillExchange</a>
  <div class="nav-links">
    <a class="nav-link" href="profile.jsp">&#128221; My Profile</a>
    <a class="nav-link active" href="BrowseServlet">&#128269; Browse</a>
    <button class="nav-link notif-dot" onclick="alert('Notifications coming soon!')">&#128276; Notifications</button>
    <a class="nav-link" href="messages.jsp">&#128172; Messages</a>
  </div>
  <div class="nav-right">
    <div class="nav-avatar"><%= currentInitials.toUpperCase() %></div>
    <a href="LogoutServlet" class="logout-btn">Log out</a>
  </div>
</nav>

<!-- PAGE -->
<main class="page">

  <!-- Back button -->
  <a href="javascript:history.back()" class="back-btn">&#8592; Back to Browse</a>

  <!-- HERO CARD -->
  <div class="hero-card">
    <div class="hero-banner"></div>
    <div class="hero-body">
      <div class="hero-avatar-wrap">
        <div class="hero-avatar"><%= pInitials %></div>
        <% if (!pRoleDisplay.isEmpty()) { %>
          <div class="role-badge"><%= pRoleDisplay %></div>
        <% } %>
      </div>

      <h1 class="hero-name"><%= pName %></h1>
      <div class="hero-meta">
        <span>University of Mpumalanga</span>
        <% if (!pJoin.isEmpty()) { %>
          <span class="hero-meta-dot"></span>
          <span>Joined <%= pJoin %></span>
        <% } %>
        <% if (!profileSkills.isEmpty()) { %>
          <span class="hero-meta-dot"></span>
          <span><%= profileSkills.size() %> skill<%= profileSkills.size() != 1 ? "s" : "" %></span>
        <% } %>
      </div>

      <div class="hero-actions">
        <a href="messages.jsp?startChat=<%= pId %>&name=<%= java.net.URLEncoder.encode(pName, "UTF-8") %>"
           class="btn btn-primary">&#128172; Send Message</a>
        <button class="btn btn-outline" onclick="openRating()">
          &#11088; Rate <%= pName.split(" ")[0] %>
        </button>
      </div>
    </div>
  </div>

  <!-- STATS -->
  <div class="stats-row">
    <div class="stat-box">
      <div class="stat-num"><%= profileSkills.size() %></div>
      <div class="stat-label">Skills</div>
    </div>
    <div class="stat-box">
      <div class="stat-num"><%= portfolioPhotos.size() %></div>
      <div class="stat-label">Portfolio Photos</div>
    </div>
    <div class="stat-box">
      <div class="stat-num" style="color:var(--accent);" id="avgRating">&#9733; ?</div>
      <div class="stat-label" id="ratingCount">Rating</div>
    </div>
  </div>

  <!-- MAIN GRID -->
  <div class="profile-grid">

    <!-- Skills -->
    <div class="card">
      <div class="card-label">&#127775; Skills</div>
      <% if (!profileSkills.isEmpty()) { %>
        <div class="skill-tags">
          <% for (String skill : profileSkills) { %>
            <span class="skill-tag"><%= skill %></span>
          <% } %>
        </div>
      <% } else { %>
        <p class="no-skills">No skills listed yet.</p>
      <% } %>
    </div>

    <!-- About -->
    <div class="card">
      <div class="card-label">&#128100; About</div>
      <% if (!pBio.isEmpty()) { %>
        <p class="bio-text"><%= pBio %></p>
      <% } else { %>
        <p class="no-bio">This user hasn't written a bio yet.</p>
      <% } %>
    </div>

    <!-- Portfolio -->
    <div class="card card-full">
      <div class="card-label">&#128247; Work Portfolio</div>
      <% if (!portfolioPhotos.isEmpty()) { %>
        <div class="photos-grid">
          <% for (String photoUrl : portfolioPhotos) { %>
            <div class="photo-slot">
              <img src="<%= request.getContextPath() + "/" + photoUrl %>"
                   alt="Work photo"
                   onclick="openPhoto('<%= request.getContextPath() + "/" + photoUrl %>')"
                   style="cursor:zoom-in;">
            </div>
          <% } %>
          <%-- Fill remaining slots --%>
          <% for (int i = portfolioPhotos.size(); i < 6; i++) { %>
            <div class="photo-slot empty">
              <div class="photo-empty-icon">&#128247;</div>
            </div>
          <% } %>
        </div>
      <% } else { %>
        <p style="font-size:13px;color:var(--text3);font-style:italic;">
          No portfolio photos uploaded yet.
        </p>
      <% } %>
    </div>
    
        <div class="card card-full" id="reviewsCard" style="display:none;">
          <div class="card-label">&#11088; Reviews</div>
          <div id="reviewsList" style="display:flex;flex-direction:column;gap:12px;"></div>
        </div>

  </div>
</main>

<!-- LIGHTBOX -->
<div id="lightbox" onclick="closeLightbox()"
     style="display:none;position:fixed;inset:0;z-index:500;
            background:rgba(0,0,0,0.85);align-items:center;justify-content:center;cursor:zoom-out;">
  <img id="lightboxImg" src="" alt="Portfolio photo"
       style="max-width:90vw;max-height:88vh;border-radius:10px;
              box-shadow:0 20px 60px rgba(0,0,0,0.5);">
</div>

<script>
function showToast(msg) {
  var t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(function() { t.classList.remove('show'); }, 2800);
}

function openPhoto(url) {
  var lb = document.getElementById('lightbox');
  document.getElementById('lightboxImg').src = url;
  lb.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function closeLightbox() {
  document.getElementById('lightbox').style.display = 'none';
  document.body.style.overflow = '';
}

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') closeLightbox();
});
</script>

<!-- RATING MODAL -->
<div id="ratingModal" onclick="closeRating(event)"
     style="display:none;position:fixed;inset:0;z-index:500;
            background:rgba(0,0,0,0.45);align-items:center;justify-content:center;">
  <div onclick="event.stopPropagation()"
       style="background:var(--surface);border-radius:16px;padding:2rem;
              width:380px;max-width:90vw;box-shadow:0 16px 48px rgba(0,0,0,0.18);
              text-align:center;">
    <h2 style="font-family:var(--font-display);font-size:20px;margin-bottom:6px;">
      Rate <%= pName.split(" ")[0] %>
    </h2>
    <p style="font-size:13px;color:var(--text3);margin-bottom:1.5rem;">
      How was your skill exchange experience?
    </p>
    <div id="starRow" style="display:flex;justify-content:center;gap:10px;margin-bottom:1.5rem;">
      <span class="star" data-val="1" onclick="setRating(1)">&#9733;</span>
      <span class="star" data-val="2" onclick="setRating(2)">&#9733;</span>
      <span class="star" data-val="3" onclick="setRating(3)">&#9733;</span>
      <span class="star" data-val="4" onclick="setRating(4)">&#9733;</span>
      <span class="star" data-val="5" onclick="setRating(5)">&#9733;</span>
    </div>
    <textarea id="ratingComment" placeholder="Leave a comment (optional)..."
              style="width:100%;padding:10px 13px;border-radius:8px;
                     border:1px solid var(--border2);background:var(--bg);
                     font-size:13px;font-family:var(--font-body);color:var(--text);
                     resize:none;min-height:80px;outline:none;margin-bottom:1.25rem;"></textarea>
    <div style="display:flex;gap:10px;justify-content:flex-end;">
      <button onclick="closeRating()"
              style="padding:9px 18px;border-radius:8px;border:1px solid var(--border2);
                     background:none;font-size:13px;font-family:var(--font-body);
                     color:var(--text2);cursor:pointer;">Cancel</button>
      <button onclick="submitRating()"
              style="padding:9px 18px;border-radius:8px;border:none;
                     background:var(--brand);color:#fff;font-size:13px;
                     font-weight:500;font-family:var(--font-body);cursor:pointer;">
                     Submit Rating</button>
    </div>
  </div>
</div>

<style>
.star {
  font-size: 36px; color: var(--border2); cursor: pointer;
  transition: color 0.15s, transform 0.1s;
}
.star.active { color: var(--accent); }
.star:hover { color: var(--accent); transform: scale(1.2); }
</style>

<script>
// RATINGS
var selectedRating = 0;
var profileUserId = <%= pId %>;

function loadRatings() {
  fetch('RatingServlet?userId=' + profileUserId)
    .then(function(r) { return r.json(); })
    .then(function(data) {
      // Update stat box
      var avgEl   = document.getElementById('avgRating');
      var countEl = document.getElementById('ratingCount');
      if (data.total > 0) {
        avgEl.innerHTML   = '&#9733; ' + data.avg;
        countEl.textContent = data.total + ' review' + (data.total !== 1 ? 's' : '');
      } else {
        avgEl.innerHTML   = '&#9733; ?';
        countEl.textContent = 'No ratings yet';
      }

      // Render reviews
      var list = document.getElementById('reviewsList');
      var card = document.getElementById('reviewsCard');
      if (data.reviews.length > 0) {
        card.style.display = '';
        list.innerHTML = data.reviews.map(function(r) {
          var stars = '';
          for (var i = 1; i <= 5; i++) {
            stars += '<span style="color:' + (i <= r.stars ? 'var(--accent)' : 'var(--border2)') +
                     ';font-size:16px;">&#9733;</span>';
          }
          return '<div style="padding:12px 0;border-bottom:1px solid var(--border);">' +
            '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">' +
              '<div style="display:flex;align-items:center;gap:10px;">' +
                '<div style="width:32px;height:32px;border-radius:50%;background:var(--brand-light);' +
                     'border:1.5px solid var(--brand-mid);display:flex;align-items:center;' +
                     'justify-content:center;font-size:12px;font-weight:600;color:var(--brand);">' +
                  r.reviewer.charAt(0).toUpperCase() +
                '</div>' +
                '<span style="font-size:13px;font-weight:600;color:var(--text);">' + r.reviewer + '</span>' +
              '</div>' +
              '<span style="font-size:11px;color:var(--text3);">' + r.date + '</span>' +
            '</div>' +
            '<div style="margin-bottom:4px;">' + stars + '</div>' +
            (r.comment ? '<p style="font-size:13px;color:var(--text2);">' + r.comment + '</p>' : '') +
          '</div>';
        }).join('');
      } else {
        card.style.display = 'none';
      }
    })
    .catch(function(e) { console.error('Load ratings error', e); });
}

function openRating() {
  selectedRating = 0;
  document.querySelectorAll('.star').forEach(function(s) { s.classList.remove('active'); });
  document.getElementById('ratingComment').value = '';
  document.getElementById('ratingModal').style.display = 'flex';
}

function closeRating(e) {
  if (!e || e.target === document.getElementById('ratingModal')) {
    document.getElementById('ratingModal').style.display = 'none';
  }
}

function setRating(val) {
  selectedRating = val;
  document.querySelectorAll('.star').forEach(function(s) {
    s.classList.toggle('active', parseInt(s.getAttribute('data-val')) <= val);
  });
}

function submitRating() {
  if (selectedRating === 0) {
    showToast('Please select a star rating first');
    return;
  }

  var comment = document.getElementById('ratingComment').value.trim();

  fetch('RatingServlet', {
    method:  'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body:    'ratedUserId=' + profileUserId +
             '&rating='     + selectedRating +
             '&comment='    + encodeURIComponent(comment)
  })
  .then(function(r) { return r.json(); })
  .then(function(res) {
    if (res.success) {
      document.getElementById('ratingModal').style.display = 'none';
      showToast('Rating submitted!');
      loadRatings(); // refresh the display
    } else {
      showToast(res.message || 'Could not submit rating');
    }
  })
  .catch(function() { showToast('Network error'); });
}

// Load ratings on page load
document.addEventListener('DOMContentLoaded', loadRatings);
</script>

</body>
</html>
