<%@page import="com.mycompany.studentskillexchange.model.User"%>

<%
    User user = (User) session.getAttribute("user");
%>
<html>
<head>
    <title>Student Skills Exchange</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
      *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
 
    :root {
      --nav-green:  #2d6a3f;
      --hero-top:   #357a48;
      --hero-bot:   #4cb86a;
      --btn-green:  #2d6a3f;
      --btn-hover:  #245535;
      --body-bg:    #f0f0f0;
      --card-bg:    #ffffff;
      --text-dark:  #1a3d26;
      --text-muted: #555;
    }   
        body {
            font-family: Arial, sans-serif;
            background: var(--body-bg);
            margin: 0;
        }

    nav {
      position: fixed;
      top: 0; left: 0; right: 0;
      z-index: 100;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 48px;
      height: 68px;
      background: asin;
      backdrop-filter: blur(18px);
      -webkit-backdrop-filter: blur(18px);
      border-bottom: 1px solid rgba(61, 184, 106, 0.15);
    }
 
    .nav-logo {
      font-family: 'Syne', sans-serif;
      font-weight: 800;
      font-size: 1.2rem;
      letter-spacing: -0.5px;
      color: var(--green-glow);
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .nav-logo span.dot {
      width: 8px; height: 8px;
      background: var(--green-glow);
      border-radius: 50%;
      display: inline-block;
      animation: pulse 2s infinite;
    }
    .nav-links {
      display: flex;
      align-items: center;
      gap: 8px;
      list-style: none;
    }
    .nav-links li { position: relative; }
 
    .nav-links a {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 16px;
      border-radius: 8px;
      font-size: 0.9rem;
      font-weight: 500;
      color: rgba(255,255,255,0.75);
      text-decoration: none;
      transition: color .2s, background .2s;
      white-space: nowrap;
    }
    .nav-links a:hover { color: var(--white); background: rgba(255,255,255,0.07); }
    .nav-links a .chevron {
      font-size: 0.65rem;
      transition: transform .25s;
      opacity: .6;
    }
    .nav-links li:hover .chevron { transform: rotate(180deg); }
    /* Dropdown */
    .dropdown {
      position: absolute;
      top: calc(100% + 12px);
      left: 50%;
      transform: translateX(-50%) translateY(-6px);
      min-width: 220px;
      background: rgba(30, 60, 50, 0.30);
      border: 1px solid rgba(61,184,106,0.2);
      border-radius: var(--radius);
      padding: 8px;
      opacity: 0;
      pointer-events: none;
      transition: opacity .5s, transform .5s;
      box-shadow: 0 24px 48px rgba(0,0,0,.5);
    }
    .nav-links li:hover .dropdown {
      opacity: 1;
      pointer-events: all;
      transform: translateX(-50%) translateY(0);
    }
    .dropdown a {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      border-radius: 10px;
      color: white;
      font-size: 0.875rem;
      width: 100%;
    }
    .dropdown a:hover { background: rgba(61,184,106,0.12); color: cadetblue; }
    .dropdown a .icon { font-size: 1rem; }
    .dropdown-label {
      font-size: 0.7rem;
      font-weight: 600;
      letter-spacing: .08em;
      text-transform: uppercase;
      color: black;
      padding: 6px 14px 4px;
    }
 
    .nav-cta {
      background:cadetblue !important;
      color: black;
      font-weight: 600 !important;
      padding: 8px 20px !important;
      border-radius: 999px !important;
      transition: background .5s, transform .15s !important;
    }
    .nav-cta:hover { background: cadetblue !important; transform: translateY(-1px) !important; }

        /* HERO */
        .hero {
      background: linear-gradient(160deg, var(--hero-top) 0%, var(--hero-bot) 100%);
      padding: 70px 25px 60px;
      text-align: center; color: #fff;
      position: relative; overflow: hidden;
      width: 100%; height: 100%;
    }
    .hero-blob { position: absolute; border-radius: 50%; background: rgba(255,255,255,0.06); pointer-events: none; }
    .hero-blob-1 { width: 420px; height: 420px; top: -140px; left: -80px;  animation: blobFloat 10s ease-in-out infinite; }
    .hero-blob-2 { width: 300px; height: 300px; bottom: -80px; right: -60px; animation: blobFloat 13s ease-in-out infinite reverse; }
    .hero-blob-3 { width: 180px; height: 180px; top: 30%; left: 60%;        animation: blobFloat 8s ease-in-out infinite 2s; }
    @keyframes blobFloat { 0%,100%{transform:translate(0,0) scale(1)} 50%{transform:translate(20px,25px) scale(1.05)} }
 
    .hero h1 { font-size: clamp(1.9rem,4.5vw,3rem); font-weight: 800; letter-spacing: -0.5px; position: relative; text-shadow: 0 2px 12px rgba(0,0,0,.15); }
    .hero p   { margin-top: 14px; font-size: 1.05rem; opacity: .88; position: relative; }
    .hero-btn {
      display: inline-block; margin-top: 32px; padding: 13px 40px;
      background: transparent; color: #fff; border: 2px solid #fff; border-radius: 8px;
      font-family: 'Poppins',sans-serif; font-size: .95rem; font-weight: 600;
      text-decoration: none; position: relative;
      transition: background .2s, color .2s, transform .15s, box-shadow .2s;
    }
    .hero-btn:hover { background:#fff; color:var(--nav-green); transform:translateY(-2px); box-shadow:0 8px 24px rgba(0,0,0,.18); }
   
    .features-grid {
      display: grid; 
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 1rem; 
      padding: 2rem 48px;
      margin-top: 2rem;
      width: 100%;
    }
    .feature-card {
      background: rgba(30, 60, 50, 0.30); border: 1px solid var(--border); border-radius: 16px;
      padding: 40px 20px 30px; position: relative; overflow: hidden;
      transition: transform 0.3s, border-color 0.3s, box-shadow 0.3s; cursor: pointer;
    }
    .feature-card::before {
      content: ''; position: absolute; inset: 0; opacity: 0;
      transition: opacity 0.4s; border-radius: inherit;
    }
    .feature-card:hover { transform: translateY(-6px); }
 
    .card-academic::before  { background: radial-gradient(circle at top left, rgba(244,114,182,0.1), transparent 60%); }
    .card-academic:hover    { border-color: rgba(244,114,182,0.35); box-shadow: 0 20px 60px rgba(244,114,182,0.1); }
    .card-academic:hover::before { opacity:1; }
 
    .card-financial::before { background: radial-gradient(circle at top left, rgba(232,160,192,0.1), transparent 60%); }
    .card-financial:hover   { border-color: rgba(232,160,192,0.35); box-shadow: 0 20px 60px rgba(232,160,192,0.1); }
    .card-financial:hover::before { opacity:1; }
 
    .card-support::before   { background: radial-gradient(circle at top left, rgba(192,132,252,0.1), transparent 60%); }
    .card-support:hover     { border-color: rgba(192,132,252,0.35); box-shadow: 0 20px 60px rgba(192,132,252,0.1); }
    .card-support:hover::before { opacity:1; }
 
    .card-burnout::before   { background: radial-gradient(circle at top left, rgba(216,180,254,0.1), transparent 60%); }
    .card-burnout:hover     { border-color: rgba(216,180,254,0.35); box-shadow: 0 20px 60px rgba(216,180,254,0.1); }
    .card-burnout:hover::before { opacity:1; }
 
    .card-icon {
      width: 48px; height: 48px; border-radius: 12px;
      display: grid; place-items: center; font-size: 1.4rem; margin-bottom: 1.4rem;
    }
    .icon-academic  { background: rgba(244,114,182,0.12); }
    .icon-financial { background: rgba(232,160,192,0.12); }
    .icon-support   { background: rgba(192,132,252,0.12); }
    .icon-burnout   { background: rgba(216,180,254,0.12); }
 
    .card-title { font-family: 'Syne', sans-serif; font-size: 1.15rem; font-weight: 700; margin-bottom: 0.6rem; }
    .card-desc  { color: var(--muted); font-size: 0.9rem; line-height: 1.65; }
    .card-tag {
      display: inline-block; margin-top: 1.2rem; padding: 0.25rem 0.7rem; border-radius: 4px;
      font-size: 0.72rem; font-weight: 600; letter-spacing: 0.5px;
    }
        /* CARDS */
        .cards {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 40px;
        }
        .card {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
            width: 220px;
            transition: 0.3s;
        }
        .card:hover {
            transform: translateY(-6px);
        }
        .card h3 { color: #2e7d32; margin-bottom: 10px; }
        .card a {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 12px;
            background: #2e7d32;
            color: #fff;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }
        .card a:hover { background: #66bb6a; }
        /* HOW IT WORKS */
        .how {
            text-align: center;
            padding: 40px;
            background: #ffffff;
        }
        .steps {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }
        .steps div {
            width: 30%;
        }
        /* FOOTER */
        .footer {
            background:cadetblue;
            color: currentColor;
            text-align: center;
            padding:30px;
        }
        
        /* SKILLS SLIDESHOW */
.slideshow-section {
  padding: 10px 24px 0;
  text-align: center;
}
.slideshow-label {
  font-size: 0.85rem;
  font-weight: 600;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: rgba(255,255,255,0.7);
  margin-bottom: 16px;
}
.slideshow-track {
  display: flex;
  gap: 16px;
  overflow: hidden;
  position: relative;
}
.slideshow-inner {
  display: flex;
  gap: 16px;
  animation: slidescroll 28s linear infinite;
}
.slideshow-inner:hover { animation-play-state: paused; }
.skill-slide {
  flex-shrink: 0;
  width: 160px;
  background: rgba(255,255,255,0.12);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 14px;
  padding: 18px 12px;
  text-align: center;
  backdrop-filter: blur(8px);
  transition: background 0.2s, transform 0.2s;
  cursor: default;
}
.skill-slide:hover {
  background: rgba(255,255,255,0.22);
  transform: translateY(-4px);
}
.skill-emoji { font-size: 2rem; display: block; margin-bottom: 8px; } .skill-name {
  font-size: 0.82rem;
  font-weight: 600;
  color: #fff;
  line-height: 1.3;
}
@keyframes slidescroll {
  0%   { transform: translateX(0); }
  100% { transform: translateX(-50%); }
}
/* HERO BACKGROUND SLIDESHOW */
.hero-slides {
  position: absolute;
  inset: 0;
  z-index: 0;
}
.hero-slide-img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0;
  transition: opacity 1.5s ease;
}
.hero-slide-img.active { opacity: 1; }
.hero-overlay {
  position: absolute;
  inset: 0;
  background: rgba(30, 90, 50, 0.35);
  z-index: 1;
}
.hero > *:not(.hero-slides):not(.hero-overlay) {
  position: relative;
  z-index: 2;
}
    </style>
</head>

<body>

<!-- Navbar -->
<nav>
  <a class="nav-logo" href="#">
    <span class="dot"></span> StudentSkillExchange
  </a>
  <ul class="nav-links">
 
    <li>
      <a href="#">Explore &#9662;</a>
      <div class="dropdown">
        <div class="dropdown-label">Discover</div>
        <a href="#"><span class="icon">&#128269;</span> Browse All Skills</a>
        <a href="#"><span class="icon">&#128293;</span> Trending Skills</a>
        <a href="#"><span class="icon">&#128218;</span> Categories</a>
        <div class="dropdown-label" style="margin-top:8px">Popular</div>
        <a href="#"><span class="icon">&#128187;</span> Tech &amp; Coding</a>
        <a href="#"><span class="icon">&#127912;</span> Design &amp; Art</a>
        <a href="#"><span class="icon">&#127760;</span> Languages</a>
      </div>
    </li>
 
    <li>
      <a href="#">Community &#9662;</a>
      <div class="dropdown">
        <div class="dropdown-label">Connect</div>
        <a href="#"><span class="icon">&#128101;</span> Student Profiles</a>
        <a href="#"><span class="icon">&#128172;</span> Discussion Board</a>
        <a href="#"><span class="icon">&#129309;</span> Find a Study Buddy</a>
      </div>
    </li>
    
    <li>
      <a href="#">Account &#9662;</a>
      <div class="dropdown">
        <div class="dropdown-label">New here?</div>
        <a href="register.jsp">&#128221; Create Profile</a>
        <div class="dropdown-label" style="margin-top:6px">Returning</div>
        <a href="login.jsp">&#128273; Login</a>
      </div>
    </li>
 
    <li><a href="About.jsp">About</a></li>
 
    <li>
      <a href="register.jsp">Get Started &#8594;</a>
    </li>
  </ul>
</nav>
 
<!-- Hero Section -->
<section class="hero" style="background: center">
    <h1>Welcome to Student Skill Exchange</h1>

    <% if (user != null) { %>
    <p>Hello, <%= user.getName() %>!</p>
    <a href="home.jsp" class="hero-btn">Go to Dashboard</a>
<% } else { %>
    <p>A platform to share, learn, and grow together.</p>
    <a href="register.jsp" class="hero-btn">Get Started</a>
    <a href="login.jsp" class="hero-btn">Login</a>
<% } %>
    
    <div class="features-grid">
 
    <div class="feature-card card-academic reveal">
      <div class="card-icon icon-academic">&#128202;</div>
      <div class="card-title">Skill Marketplace</div>
      <p class="card-desc">Browse and explore skills shared by students. Find opportunities to learn or offer your own expertise in areas like coding, design, language and more.</p>
      <span class="card-tag tag-academic">Explore skills</span>
    </div>
 
    <div class="feature-card card-financial reveal">
      <div class="card-icon icon-financial">&#128200;</div>
      <div class="card-title">Skill Matching</div>
      <p class="card-desc">Connect with students who want to exchange skills. Get matched based on your interests and what you can offer or learn.</p>
      <span class="card-tag tag-financial">Smart Matching</span>
    </div>
 
    <div class="feature-card card-support reveal">
      <div class="card-icon icon-support">&#129309;</div>
      <div class="card-title">Messaging & Collaboration</div>
      <p class="card-desc">Communicate with other students, plan sessions, and collaborate easily through built-in messaging tools.</p>
      <span class="card-tag tag-support">Real-Time Chat</span>
    </div>
 
    <div class="feature-card card-burnout reveal">
      <div class="card-icon icon-burnout">&#128293;</div>
      <div class="card-title">Personal Dashboard</div>
      <p class="card-desc">Track your skill exchanges, manage requests, and monitor your learning progress all in one place.</p>
      <span class="card-tag tag-burnout">User Control</span>
    </div>
 
  </div>
</section>
    <!-- Background slideshow images -->
<div class="hero-slides">
  <img class="hero-slide-img active"
    src=https://images.pexels.com/photos/1769553/pexels-photo-1769553.jpeg?cs=srgb&dl=pexels-zachary-debottis-1769553.jpg&fm=jpg
    alt="Students collaborating">
  <img class="hero-slide-img"
    src=https://travelbeautyblog.com/wp-content/uploads/2023/04/Box-Braids-Hairstyles-jpg.webp
    alt="Tutoring">
  <img class="hero-slide-img"
    src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1400&auto=format&fit=crop"
    alt="Coding">
  <img class="hero-slide-img"
    src="https://images.unsplash.com/photo-1547153760-18fc86324498?w=1400&auto=format&fit=crop"
    alt="Dancing">
  <img class="hero-slide-img"
    src=https://wallpaperaccess.com/full/4711166.jpg
    alt="Tennis">
  <img class="hero-slide-img"
    src=https://tse3.mm.bing.net/th/id/OIP.nRRnjzUxCAAN9Kz4XnLugQHaFj?rs=1&pid=ImgDetMain&o=7&rm=3
    alt="Photography">
   <img class="hero-slide-img"
    src=https://th.bing.com/th/id/OIP.WS4Uy7ouJI-YEPFHzx5oogHaEK?o=7rm=3&rs=1&pid=ImgDetMain&o=7&rm=3
    alt="Crocheting">
  
</div>
<div class="hero-overlay"></div>

 <div class="hero-blob hero-blob-1"></div>
  <div class="hero-blob hero-blob-2"></div>
  <div class="hero-blob hero-blob-3"></div>
  
    

<!-- Footer -->
<div class="footer">
    <p>&copy; 2026 Student Skills Exchange</p>
</div>
<script>
  // Hero background slideshow
  const slides = document.querySelectorAll('.hero-slide-img');
  let current = 0;
  setInterval(() => {
    slides[current].classList.remove('active');
    current = (current + 1) % slides.length;
    slides[current].classList.add('active');
  }, 4000);
</script>
</body>
</html>