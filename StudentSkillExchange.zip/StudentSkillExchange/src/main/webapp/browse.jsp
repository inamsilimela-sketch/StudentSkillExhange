<%@page import="com.mycompany.studentskillexchange.model.User"%>
<%@page import="com.mycompany.studentskillexchange.servlet.BrowseServlet.BrowseUser"%>
<%@page import="java.util.List"%>
<%
    User user = (User) session.getAttribute("user");

    String name = "User";
    String initials = "?";

    if (user != null && user.getName() != null) {
        name = user.getName();
        String[] parts = name.trim().split(" ");
        if (parts.length >= 2) {
            initials = "" + parts[0].charAt(0) + parts[parts.length - 1].charAt(0);
        } else if (parts.length == 1 && parts[0].length() > 0) {
            initials = "" + parts[0].charAt(0);
        }
    }
     List<BrowseUser> browseUsers =
        (List<BrowseUser>) request.getAttribute("browseUsers");
    if (browseUsers == null) browseUsers = new java.util.ArrayList<>();
%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Browse Skills</title>

<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --brand:       #1a6b4a;
      --brand-light: #e8f5ee;
      --brand-mid:   #2d9e6f;
      --accent:      #f4a24a;
      --accent-light:#fff4e6;
      --bg:          #f7f6f2;
      --surface:     #ffffff;
      --surface2:    #f0ede8;
      --text:        #1c1c1a;
      --text2:       #5a5853;
      --text3:       #9a9792;
      --border:      rgba(0,0,0,0.08);
      --border2:     rgba(0,0,0,0.14);
      --radius:      12px;
      --font-display:'Fraunces', Georgia, serif;
      --font-body:   'DM Sans', system-ui, sans-serif;
      --shadow-sm:    0 2px 8px rgba(0,0,0,0.07);
      --shadow-md:    0 6px 24px rgba(0,0,0,0.10);
      --shadow-lg:    0 16px 48px rgba(0,0,0,0.13);
    }    
html, body {
      min-height: 100vh;
      background: var(--bg);
      color: var(--text);
      font-family: var(--font-body);
      font-size: 16px;
      line-height: 1.6;
    }

 /* ?? NAV ??????????????????????????????????????? */
    nav {
      position: sticky;
      top: 0;
      z-index: 100;
      background: var(--surface);
      border-bottom: 1px solid var(--border);
      height: 62px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
    }

    .nav-logo {
      font-family: var(--font-display);
      font-size: 22px;
      font-weight: 600;
      color: var(--brand);
      letter-spacing: -0.3px;
      text-decoration: none;
    }

    .nav-links {
      display: flex;
      align-items: center;
      gap: 2px;
    }

    .nav-link {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 7px 14px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      color: var(--text2);
      text-decoration: none;
      border: none;
      background: none;
      cursor: pointer;
      font-family: var(--font-body);
      transition: background 0.15s, color 0.15s;
      position: relative;
    }

    .nav-link:hover { background: var(--surface2); color: var(--text); }
    .nav-link.active { background: var(--brand-light); color: var(--brand); }

    .notif-dot::after {
      content: '';
      position: absolute;
      top: 8px; right: 10px;
      width: 7px; height: 7px;
      border-radius: 50%;
      background: #e05555;
    }

    .nav-right { display: flex; align-items: center; gap: 10px; }

    .nav-avatar {
      width: 36px; height: 36px;
      border-radius: 50%;
      background: var(--brand-light);
      border: 2px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-size: 13px; font-weight: 600; color: var(--brand);
      cursor: pointer;
      overflow: hidden;
    }

    .nav-avatar img { width: 100%; height: 100%; object-fit: cover; }

    .logout-btn {
      padding: 7px 16px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 500;
      color: #c0392b;
      border: 1px solid rgba(192,57,43,0.25);
      background: none;
      cursor: pointer;
      font-family: var(--font-body);
      transition: background 0.15s;
    }
    .logout-btn:hover { background: #fdf0ef; }


/* CONTAINER */
.container {
    padding: 19px;
}

/* SEARCH */
.search-section {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.5rem;
      margin-bottom: 1.75rem;
      animation: fadeUp 0.4s 0.05s ease both;
    }

.search-row {
     display: flex;
     gap: 10px;
     align-items: center;
     margin-bottom: 1rem;
}
.search-input-wrap {
      flex: 1;
      position: relative;
      min-width: 0;
}
.search-input-wrap i {
     position: absolute;
     left: 14px; top: 50%;
     transform: translateY(-50%);
     color: var(--text3);
     font-size: 14px;
     pointer-events: none;
}
.search-input {
      width: 100%;
      padding: 11px 14px 11px 40px;
      border-radius: 10px;
      border: 1px solid var(--border2);
      background: var(--bg);
      font-size: 14px;
      font-family: var(--font-body);
      color: var(--text);
      outline: none;
      transition: border-color 0.15s, box-shadow 0.15s;
}
.search-input:focus {
      border-color: var(--brand);
      box-shadow: 0 0 0 3px rgba(26,107,74,0.1);
}
.sort-select {
      padding: 11px 14px;
      border-radius: 10px;
      border: 1px solid var(--border2);
      background: var(--bg);
      font-size: 13px;
      font-family: var(--font-body);
      color: var(--text2);
      outline: none;
      cursor: pointer;
      min-width: 160px;
      transition: border-color 0.15s;
}
.sort-select:focus { border-color: var(--brand); }
.filter-row {
      display: flex;
      flex-wrap: wrap;
      gap: 7px;
      align-items: center;
}
.filter-label {
      font-size: 12px;
      font-weight: 600;
      color: var(--text3);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-right: 4px;
}
.filter-pill {
      padding: 6px 15px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 500;
      border: 1px solid var(--border2);
      background: var(--surface);
      color: var(--text2);
      cursor: pointer;
      transition: all 0.15s;
      user-select: none;
      display: inline-flex;
      align-items: center;
      gap: 5px;
}
.filter-pill:hover { background: var(--surface2); border-color: var(--brand-mid); color: var(--text); }
    .filter-pill.active {
      background: var(--brand-light);
      color: var(--brand);
      border-color: rgba(26,107,74,0.3);
      font-weight: 600;
}


/* CARDS */
.cards {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    margin-top: 20px;
}

.card {
    width: 250px;
    background: white;
    border-radius: 10px;
    padding: 15px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

/* TAGS */
.tag {
    display: inline-block;
    padding: 5px 10px;
    margin: 3px;
    background: #e6f4ea;
    border-radius: 15px;
    font-size: 12px;
}

/* BUTTONS */
.btn {
    padding: 8px 12px;
    border-radius: 6px;
    border: none;
    cursor: pointer;
}

.message {
    background: #1f7a5a;
    color: white;
}

.profile {
    background: #eee;
}
</style>
</head>

<body>

<!-- ?? NAV ???????????????????????????????????????? -->
<nav>
  <a class="nav-logo" href="#">StudentSkillExchange</a>

  <div class="nav-links">
    <a class="nav-link" href="profile.jsp">&#128221; My Profile</a>
    <a class="nav-link" href="BrowseServlet">&#128269; Browse</a>
    <div style="position:relative;display:inline-flex;">
  <a class="nav-link" href="notifications.jsp" id="notifNavBtn">
    &#128276; Notifications
  </a>
  <span id="navNotifBadge" style="
    display:none;
    position:absolute;
    top:4px; right:6px;
    background:#e05555;
    color:white;
    font-size:10px;
    font-weight:700;
    min-width:17px; height:17px;
    border-radius:10px;
    align-items:center;
    justify-content:center;
    padding:0 4px;
    pointer-events:none;
  ">0</span>
</div>

    <a class="nav-link" href="messages.jsp">&#128172; Messages</a>
  </div>

  <div class="nav-right">
    <div class="nav-avatar" id="navAvatar" title="My Profile"><%= initials.toUpperCase() %></div>
    <a href="LogoutServlet" class="logout-btn">Log out</a>
  </div>
</nav>

<!-- CONTENT -->
<div class="container">
    <h1>Browse Skills</h1>
    <div class="search-section">
    <div class="search-row">
      <div class="search-input-wrap">
        <i class="fa fa-search"></i>
        <input
          class="search-input"
          id="searchInput"
          type="text"
          placeholder="Search by name, skill, ranking..."
          oninput="filterStudents()"
          autocomplete="off"
        >
      </div>
      <select class="sort-select" id="sortSelect" onchange="filterStudents()">
        <option value="name">Sort: Name A&#8211;Z</option>
        <option value="rating">Sort: Top Rated</option>
        <option value="newest">Sort: Newest</option>
        <option value="exchanges">Sort: Most Exchanges</option>
      </select>
    </div>
      <div class="filter-row">
      <span class="filter-label">Category:</span>
      <span class="filter-pill active" data-filter="All"         onclick="setFilter(this)"><i class="fa fa-th-large"></i> All</span>
      <span class="filter-pill"        data-filter="Design"      onclick="setFilter(this)"><i class="fa fa-paint-brush"></i> Design</span>
      <span class="filter-pill"        data-filter="Coding"      onclick="setFilter(this)"><i class="fa fa-code"></i> Coding</span>
      <span class="filter-pill"        data-filter="Music"       onclick="setFilter(this)"><i class="fa fa-music"></i> Music</span>
      <span class="filter-pill"        data-filter="Writing"     onclick="setFilter(this)"><i class="fa fa-pen"></i> Writing</span>
      <span class="filter-pill" data-filter="tutor" data-type="role" onclick="setFilter(this)"><i class="fa fa-graduation-cap"></i> Tutoring</span>
      <span class="filter-pill"        data-filter="Languages"   onclick="setFilter(this)"><i class="fa fa-globe"></i> Languages</span>
      <span class="filter-pill"        data-filter="Business"    onclick="setFilter(this)"><i class="fa fa-briefcase"></i> Business</span>
      <span class="filter-pill"        data-filter="Photography" onclick="setFilter(this)"><i class="fa fa-camera"></i> Photography</span>
    </div>
  </div>  
    
    

    <div class="cards">

        <!-- CARD -->
        <div class="cards" id="cardsContainer">
        <%
             if (browseUsers.isEmpty()) {
        %>
             <p style="color:var(--text3);font-size:14px;padding:1rem 0;">
                 No other students found yet. Check back later!
            </p>
        <%
            } else {
                for (BrowseUser bu : browseUsers) {
                    // Build initials
                    String[] nameParts = bu.name.trim().split("\\s+");
                    String cardInitials = nameParts.length >= 2
                        ? "" + nameParts[0].charAt(0) + nameParts[nameParts.length-1].charAt(0)
                        : "" + nameParts[0].charAt(0);
                    cardInitials = cardInitials.toUpperCase();

                    // Build skill tags HTML
                    StringBuilder skillTags = new StringBuilder();
                    if (bu.skillsCsv != null && !bu.skillsCsv.isEmpty()) {
                        for (String skill : bu.skillsCsv.split(",")) {
                            skillTags.append("<span class=\"tag\">")
                                     .append(skill.trim())
                                     .append("</span>");
                        }
                    } else {
                        skillTags.append("<span style=\"font-size:12px;color:var(--text3);\">No skills listed yet</span>");
                    }
        %>
            <div class="card"
                 data-name="<%= bu.name.toLowerCase() %>"
                 data-role="<%= bu.role != null ? bu.role.toLowerCase() : "" %>"
                 data-skills="<%= bu.skillsCsv != null ? bu.skillsCsv.toLowerCase() : "" %>">
                
                 

                 <%-- Avatar circle with initials --%>
                 <div style="width:52px;height:52px;border-radius:50%;background:var(--brand-light);
                             border:2px solid var(--brand-mid);display:flex;align-items:center;
                             justify-content:center;font-size:17px;font-weight:600;color:var(--brand);
                             margin-bottom:10px;">
                      <%= cardInitials %>
                 </div>

                <h4 style="font-size:15px;margin-bottom:2px;"><%= bu.name %></h4>
                <p style="font-size:12px;color:var(--text3);margin-bottom:6px;">
                   UMP &bull; <%= bu.role %>
                </p>

                <div style="margin-bottom:12px;">
                     <%= skillTags.toString() %>
                </div>

                <div style="display:flex;gap:8px;">
                     <a href="messages.jsp?startChat=<%= bu.id %>&name=<%= java.net.URLEncoder.encode(bu.name, "UTF-8") %>"
                        class="btn message">&#128172; Message</a>
                     <button class="btn profile"
                             onclick="viewProfile(<%= bu.id %>)">View Profile</button>
                </div>
            </div>
        <%
               } // end for
             } // end else
        %>
        </div>


    </div>
</div>

<script>
var activeFilter     = 'All';
var activeFilterType = 'skill';

function applyFilters() {
    var query = document.getElementById('searchInput').value.toLowerCase();

    document.querySelectorAll('.card').forEach(function(card) {
        var name   = card.getAttribute('data-name')   || '';
        var skills = card.getAttribute('data-skills') || '';
        var role   = card.getAttribute('data-role')   || '';

        // Check search match
        var matchesSearch = !query ||
            name.indexOf(query) !== -1 ||
            skills.indexOf(query) !== -1;

        // Check filter match
        var matchesFilter = true;
        if (activeFilter !== 'All') {
            if (activeFilterType === 'role') {
                matchesFilter = role === activeFilter;
            } else {
                matchesFilter = skills.indexOf(activeFilter.toLowerCase()) !== -1;
            }
        }

        card.style.display = (matchesSearch && matchesFilter) ? '' : 'none';
    });
}

function filterStudents() {
    var query   = document.getElementById('searchInput').value.toLowerCase();
    var cards   = document.querySelectorAll('.card');
    cards.forEach(function(card) {
        var name   = card.getAttribute('data-name') || '';
        var skills = card.getAttribute('data-skills') || '';
        var role = card.getAttribute('data-role') || '';
        var match  = name.indexOf(query) !== -1 || skills.indexOf(query) !== -1 || role.indexOf(query) !== -1;
        card.style.display = match ? '' : 'none';
    });
}


function setFilter(el) {
    document.querySelectorAll('.filter-pill').forEach(function(p) {
        p.classList.remove('active');
    });
    el.classList.add('active');
    activeFilter     = el.getAttribute('data-filter');
    activeFilterType = el.getAttribute('data-type') || 'skill';
    applyFilters();
}

function viewProfile(userId) {
    window.location.href = "ViewProfileServlet?userId=" + userId;
}
</script>

</body>
</html>