<%@page import="com.mycompany.studentskillexchange.model.User"%>
<%@page import="com.mycompany.studentskillexchange.utils.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page import="java.util.*"%>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    String name     = user.getName();
    String initials = "?";
    String[] parts  = name.trim().split("\\s+");
    if (parts.length >= 2)
        initials = "" + parts[0].charAt(0) + parts[parts.length-1].charAt(0);
    else if (parts.length == 1)
        initials = String.valueOf(parts[0].charAt(0));

    // Load notifications from DB
    List<Map<String,String>> notifications = new ArrayList<>();
    int unreadCount = 0;

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(
             "SELECT id, type, message, is_read, link, created_at " +
             "FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50")) {
        ps.setInt(1, user.getId());
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Map<String,String> n = new LinkedHashMap<>();
            n.put("id",      String.valueOf(rs.getInt("id")));
            n.put("type",    rs.getString("type"));
            n.put("message", rs.getString("message"));
            n.put("is_read", String.valueOf(rs.getBoolean("is_read")));
            n.put("link",    rs.getString("link") != null ? rs.getString("link") : "#");

            // Time ago
            Timestamp ts = rs.getTimestamp("created_at");
            String timeAgo = "just now";
            if (ts != null) {
                long diff  = System.currentTimeMillis() - ts.getTime();
                long mins  = diff / 60000;
                long hours = mins / 60;
                long days  = hours / 24;
                if      (mins  < 1)  timeAgo = "just now";
                else if (mins  < 60) timeAgo = mins + "m ago";
                else if (hours < 24) timeAgo = hours + "h ago";
                else if (days  < 7)  timeAgo = days + "d ago";
                else                 timeAgo = ts.toString().substring(0, 10);
            }
            n.put("time", timeAgo);

            if (!rs.getBoolean("is_read")) unreadCount++;
            notifications.add(n);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    // Mark all as read when page is opened
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(
             "UPDATE notifications SET is_read = TRUE WHERE user_id = ?")) {
        ps.setInt(1, user.getId());
        ps.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Notifications ? StudentSkillExchange</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&family=Fraunces:opsz,wght@9..144,400;9..144,600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --brand:       #1a6b4a;
      --brand-light: #e8f5ee;
      --brand-mid:   #2d9e6f;
      --accent:      #f4a24a;
      --bg:          #f7f6f2;
      --surface:     #ffffff;
      --surface2:    #f0ede8;
      --text:        #1c1c1a;
      --text2:       #5a5853;
      --text3:       #9a9792;
      --border:      rgba(0,0,0,0.08);
      --border2:     rgba(0,0,0,0.14);
      --danger:      #e74c3c;
      --danger-light:#fdf0ef;
      --radius:      12px;
      --font-display:'Fraunces', Georgia, serif;
      --font-body:   'DM Sans', system-ui, sans-serif;
    }

    body {
      font-family: var(--font-body);
      background: var(--bg);
      color: var(--text);
      min-height: 100vh;
    }

    /* ?? NAV ?? */
    nav {
      position: sticky; top: 0; z-index: 100;
      background: var(--surface);
      border-bottom: 1px solid var(--border);
      height: 62px;
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 2rem;
    }
    .nav-logo {
      font-family: var(--font-display); font-size: 22px;
      font-weight: 600; color: var(--brand);
      text-decoration: none; letter-spacing: -0.3px;
    }
    .nav-links { display: flex; align-items: center; gap: 2px; }
    .nav-link {
      display: flex; align-items: center; gap: 6px;
      padding: 7px 14px; border-radius: 8px;
      font-size: 14px; font-weight: 500; color: var(--text2);
      text-decoration: none; border: none; background: none;
      cursor: pointer; font-family: var(--font-body);
      transition: background 0.15s, color 0.15s;
    }
    .nav-link:hover  { background: var(--surface2); color: var(--text); }
    .nav-link.active { background: var(--brand-light); color: var(--brand); }
    .nav-right { display: flex; align-items: center; gap: 10px; }
    .nav-avatar {
      width: 36px; height: 36px; border-radius: 50%;
      background: var(--brand-light); border: 2px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-size: 13px; font-weight: 600; color: var(--brand); cursor: pointer;
    }
    .logout-btn {
      padding: 7px 16px; border-radius: 8px; font-size: 13px;
      font-weight: 500; color: #c0392b;
      border: 1px solid rgba(192,57,43,0.25); background: none;
      cursor: pointer; font-family: var(--font-body); transition: background 0.15s;
      text-decoration: none;
    }
    .logout-btn:hover { background: var(--danger-light); }

    /* Bell badge in nav */
    .nav-notif-wrap { position: relative; }
    .nav-badge {
      position: absolute; top: 2px; right: 8px;
      background: #e05555; color: white;
      font-size: 10px; font-weight: 700;
      min-width: 17px; height: 17px;
      border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      padding: 0 4px; pointer-events: none;
    }

    /* ?? PAGE ?? */
    .page {
      max-width: 680px;
      margin: 0 auto;
      padding: 2.5rem 1.5rem 4rem;
    }

    /* ?? PAGE HEADER ?? */
    .page-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 1.75rem;
      animation: fadeUp 0.3s ease both;
    }

    .page-title {
      font-family: var(--font-display);
      font-size: 32px;
      font-weight: 600;
      color: var(--text);
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .unread-pill {
      display: inline-flex;
      align-items: center;
      padding: 3px 10px;
      background: var(--brand);
      color: white;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 600;
      font-family: var(--font-body);
    }

    .mark-all-btn {
      padding: 9px 18px;
      border-radius: 8px;
      border: 1px solid var(--border2);
      background: var(--surface);
      font-size: 13px;
      font-weight: 500;
      color: var(--brand);
      cursor: pointer;
      font-family: var(--font-body);
      transition: background 0.15s;
    }
    .mark-all-btn:hover { background: var(--brand-light); }

    /* ?? FILTER TABS ?? */
    .filter-tabs {
      display: flex;
      gap: 8px;
      margin-bottom: 1.5rem;
      animation: fadeUp 0.3s 0.05s ease both;
    }

    .tab-btn {
      padding: 7px 16px;
      border-radius: 20px;
      border: 1.5px solid var(--border2);
      background: var(--surface);
      font-size: 13px;
      font-weight: 500;
      color: var(--text2);
      cursor: pointer;
      font-family: var(--font-body);
      transition: all 0.15s;
    }
    .tab-btn:hover  { border-color: var(--brand); color: var(--brand); }
    .tab-btn.active {
      background: var(--brand);
      border-color: var(--brand);
      color: white;
    }

    /* ?? NOTIFICATION LIST ?? */
    .notif-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
      animation: fadeUp 0.3s 0.1s ease both;
    }

    .notif-item {
      display: flex;
      align-items: flex-start;
      gap: 14px;
      padding: 16px 18px;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      text-decoration: none;
      color: var(--text);
      transition: transform 0.15s, box-shadow 0.15s, background 0.15s;
      position: relative;
      cursor: pointer;
    }
    .notif-item:hover {
      transform: translateY(-1px);
      box-shadow: 0 4px 16px rgba(0,0,0,0.08);
    }
    .notif-item.unread {
      background: var(--brand-light);
      border-color: rgba(26,107,74,0.2);
    }
    .notif-item.unread::before {
      content: '';
      position: absolute;
      left: 0; top: 50%;
      transform: translateY(-50%);
      width: 4px; height: 60%;
      background: var(--brand);
      border-radius: 0 4px 4px 0;
    }

    /* Icon bubble */
    .notif-icon-wrap {
      width: 46px; height: 46px;
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 20px;
      flex-shrink: 0;
    }
    .icon-message      { background: #e8f4fd; }
    .icon-review       { background: #fff8e1; }
    .icon-profile_view { background: #f3e5f5; }
    .icon-comment      { background: #e8f5e9; }
    .icon-default      { background: var(--surface2); }

    .notif-body { flex: 1; min-width: 0; }

    .notif-msg {
      font-size: 14px;
      font-weight: 500;
      line-height: 1.5;
      margin-bottom: 4px;
      color: var(--text);
    }
    .notif-item.unread .notif-msg { font-weight: 600; }

    .notif-meta {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      color: var(--text3);
    }

    .notif-type-badge {
      padding: 2px 8px;
      border-radius: 10px;
      font-size: 11px;
      font-weight: 600;
      text-transform: capitalize;
    }
    .badge-message      { background: #e8f4fd; color: #1565c0; }
    .badge-review       { background: #fff8e1; color: #e65100; }
    .badge-profile_view { background: #f3e5f5; color: #7b1fa2; }
    .badge-comment      { background: #e8f5e9; color: #2e7d32; }
    .badge-default      { background: var(--surface2); color: var(--text2); }

    /* Arrow */
    .notif-arrow {
      color: var(--text3);
      font-size: 18px;
      flex-shrink: 0;
      align-self: center;
    }

    /* ?? EMPTY STATE ?? */
    .empty-state {
      text-align: center;
      padding: 80px 20px;
      animation: fadeUp 0.3s ease both;
    }
    .empty-icon { font-size: 64px; margin-bottom: 16px; }
    .empty-title {
      font-family: var(--font-display);
      font-size: 24px;
      color: var(--text);
      margin-bottom: 8px;
    }
    .empty-sub { font-size: 14px; color: var(--text3); }

    /* ?? SECTION DIVIDERS (Today / Earlier) ?? */
    .section-label {
      font-size: 12px;
      font-weight: 600;
      color: var(--text3);
      text-transform: uppercase;
      letter-spacing: 0.06em;
      margin: 20px 0 8px;
    }
    .section-label:first-child { margin-top: 0; }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(10px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 600px) {
      nav { padding: 0 1rem; }
      .nav-links { display: none; }
      .page { padding: 1.5rem 1rem 3rem; }
      .page-title { font-size: 26px; }
    }
  </style>
</head>
<body>

<!-- NAV -->
<nav>
  <a class="nav-logo" href="#">StudentSkillExchange</a>
  <div class="nav-links">
    <a class="nav-link" href="profile.jsp">&#128221; My Profile</a>
    <a class="nav-link" href="BrowseServlet">&#128269; Browse</a>
    <div class="nav-notif-wrap">
      <a class="nav-link active" href="notifications.jsp">&#128276; Notifications</a>
    </div>
    <a class="nav-link" href="messages.jsp">&#128172; Messages</a>
  </div>
  <div class="nav-right">
    <div class="nav-avatar"><%= initials.toUpperCase() %></div>
    <a href="LogoutServlet" class="logout-btn">Log out</a>
  </div>
</nav>

<!-- PAGE -->
<main class="page">

  <!-- Header -->
  <div class="page-header">
    <div class="page-title">
      Notifications
      <% if (unreadCount > 0) { %>
        <span class="unread-pill"><%= unreadCount %> new</span>
      <% } %>
    </div>
    <% if (!notifications.isEmpty()) { %>
      <button class="mark-all-btn" onclick="markAllRead()">&#10003; Mark all read</button>
    <% } %>
  </div>

  <!-- Filter Tabs -->
  <div class="filter-tabs">
    <button class="tab-btn active" onclick="filterNotifs('all', this)">All</button>
    <button class="tab-btn" onclick="filterNotifs('message', this)">&#128172; Messages</button>
    <button class="tab-btn" onclick="filterNotifs('review', this)">&#11088; Reviews</button>
    <button class="tab-btn" onclick="filterNotifs('profile_view', this)">&#128065;&#65039; Profile Views</button>
  </div>

  <!-- Notification List -->
  <% if (notifications.isEmpty()) { %>
    <div class="empty-state">
      <div class="empty-icon">&#128276;</div>
      <div class="empty-title">All caught up!</div>
      <div class="empty-sub">When someone messages you, leaves a review, or views your profile ? it'll show up here.</div>
    </div>
  <% } else { %>
    <div class="notif-list" id="notifList">
      <%
        String lastSection = "";
        for (Map<String,String> n : notifications) {
            String type    = n.get("type");
            String time    = n.get("time");
            boolean isRead = "true".equals(n.get("is_read"));
            String link    = n.get("link");
            String msg     = n.get("message");

            // Section divider
            String section = (time.contains("just now") || time.contains("m ago") || time.contains("h ago"))
                             ? "Today" : "Earlier";
            if (!section.equals(lastSection)) {
                lastSection = section;
      %>
          <div class="section-label"><%= section %></div>
      <%  } %>

      <a class="notif-item <%= isRead ? "" : "unread" %>"
         href="<%= link %>"
         data-type="<%= type %>"
         data-id="<%= n.get("id") %>">

        <div class="notif-icon-wrap icon-<%= type %>">
          <%
            String icon;
            switch(type) {
              case "message":      icon = "&#128172;"; break;
              case "review":       icon = "&#11088;"; break;
              case "profile_view": icon = "&#128065;?"; break;
              case "comment":      icon = "&#128173;"; break;
              default:             icon = "&#128276;"; break;
            }
          %>
          <%= icon %>
        </div>

        <div class="notif-body">
          <div class="notif-msg"><%= msg %></div>
          <div class="notif-meta">
            <span class="notif-type-badge badge-<%= type %>"><%= type.replace("_", " ") %></span>
            <span><%= time %></span>
          </div>
        </div>

        <div class="notif-arrow">?</div>
      </a>
      <% } %>
    </div>
  <% } %>

</main>

<script>
  // ?? Filter by type ?????????????????????????????????????????????????????????
  function filterNotifs(type, btn) {
    // Update active tab
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    // Show/hide items
    document.querySelectorAll('.notif-item').forEach(item => {
      if (type === 'all' || item.dataset.type === type) {
        item.style.display = 'flex';
      } else {
        item.style.display = 'none';
      }
    });

    // Hide section labels if no visible items follow
    document.querySelectorAll('.section-label').forEach(label => {
      let next = label.nextElementSibling;
      let hasVisible = false;
      while (next && !next.classList.contains('section-label')) {
        if (next.style.display !== 'none') { hasVisible = true; break; }
        next = next.nextElementSibling;
      }
      label.style.display = hasVisible ? '' : 'none';
    });
  }

  // ?? Mark all read ??????????????????????????????????????????????????????????
  function markAllRead() {
    fetch('NotificationServlet?action=markRead')
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          document.querySelectorAll('.notif-item.unread')
                  .forEach(el => el.classList.remove('unread'));
          document.querySelector('.unread-pill') &&
            document.querySelector('.unread-pill').remove();
        }
      });
  }

  // ?? Animate items in on load ???????????????????????????????????????????????
  document.querySelectorAll('.notif-item').forEach((el, i) => {
    el.style.animationDelay = (i * 0.04) + 's';
    el.style.animation = 'fadeUp 0.3s ease both';

    // Mark as seen when clicked
    el.addEventListener('click', function(e) {
        const notifId = this.dataset.id;
        const href    = this.getAttribute('href');

        if (this.classList.contains('unread') && notifId) {
            e.preventDefault(); // wait for fetch before navigating
            fetch('NotificationServlet?action=markSeen&id=' + notifId)
                .finally(() => {
                    this.classList.remove('unread');
                    // Navigate after marking
                    if (href && href !== '#') window.location.href = href;
                });
        }
    });
});
</script>

</body>
</html>
