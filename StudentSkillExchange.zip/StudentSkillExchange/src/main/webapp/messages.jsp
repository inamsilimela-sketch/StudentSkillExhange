<%@page import="com.mycompany.studentskillexchange.model.User"%>
<%
    User user = (User) session.getAttribute("user");

    String name = "User";
    String initials = "?";

    if (user != null && user.getName() != null) {
        name = user.getName();
        String[] parts = name.trim().split(" ");
        if (parts.length >= 2) {
            initials = "" + parts[0].charAt(0) + parts[parts.length - 1].charAt(0);
        } else if (parts.length == 1 && parts[0].length() > 0) {
            initials = "" + parts[0].charAt(0);
        }
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>StudentSkillExchange &#8212; Messages</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&family=Fraunces:opsz,wght@9..144,400;9..144,600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --brand:       #1a6b4a;
      --brand-light: #e8f5ee;
      --brand-mid:   #2d9e6f;
      --accent:      #f4a24a;
      --accent-light:#fff4e6;
      --bg:          #f7f6f2;
      --surface:     #ffffff;
      --surface2:    #f0ede8;
      --text:        #1c1c1a;
      --text2:       #5a5853;
      --text3:       #9a9792;
      --border:      rgba(0,0,0,0.08);
      --border2:     rgba(0,0,0,0.14);
      --radius:      12px;
      --font-display:'Fraunces', Georgia, serif;
      --font-body:   'DM Sans', system-ui, sans-serif;
      --nav-height:  62px;
    }

    html, body {
      height: 100%;
      background: var(--bg);
      color: var(--text);
      font-family: var(--font-body);
      font-size: 16px;
      line-height: 1.6;
      overflow: hidden;
    }

    /* ?? NAV ?? */
    nav {
      position: fixed;
      top: 0; left: 0; right: 0;
      z-index: 100;
      background: var(--surface);
      border-bottom: 1px solid var(--border);
      height: var(--nav-height);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
    }

    .nav-logo {
      font-family: var(--font-display);
      font-size: 22px;
      font-weight: 600;
      color: var(--brand);
      letter-spacing: -0.3px;
      text-decoration: none;
    }

    .nav-links {
      display: flex;
      align-items: center;
      gap: 2px;
    }

    .nav-link {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 7px 14px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      color: var(--text2);
      text-decoration: none;
      border: none;
      background: none;
      cursor: pointer;
      font-family: var(--font-body);
      transition: background 0.15s, color 0.15s;
      position: relative;
    }

    .nav-link:hover { background: var(--surface2); color: var(--text); }
    .nav-link.active { background: var(--brand-light); color: var(--brand); }

    .notif-dot::after {
      content: '';
      position: absolute;
      top: 8px; right: 10px;
      width: 7px; height: 7px;
      border-radius: 50%;
      background: #e05555;
    }

    .nav-right { display: flex; align-items: center; gap: 10px; }

    .nav-avatar {
      width: 36px; height: 36px;
      border-radius: 50%;
      background: var(--brand-light);
      border: 2px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-size: 13px; font-weight: 600; color: var(--brand);
      cursor: pointer;
      overflow: hidden;
    }

    .nav-avatar img { width: 100%; height: 100%; object-fit: cover; }

    .logout-btn {
      padding: 7px 16px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 500;
      color: #c0392b;
      border: 1px solid rgba(192,57,43,0.25);
      background: none;
      cursor: pointer;
      font-family: var(--font-body);
      transition: background 0.15s;
    }
    .logout-btn:hover { background: #fdf0ef; }

    /* ?? LAYOUT ?? */
    .chat-layout {
      display: flex;
      height: 100vh;
      padding-top: var(--nav-height);
    }

    /* ?? SIDEBAR ?? */
    .sidebar {
      width: 340px;
      flex-shrink: 0;
      background: var(--surface);
      border-right: 1px solid var(--border);
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow: hidden;
    }

    .sidebar-header {
      padding: 1.1rem 1.25rem 0.9rem;
      border-bottom: 1px solid var(--border);
      flex-shrink: 0;
    }

    .sidebar-title {
      font-family: var(--font-display);
      font-size: 20px;
      font-weight: 600;
      color: var(--text);
      margin-bottom: 0.75rem;
    }

    .search-box {
      position: relative;
    }

    .search-box input {
      width: 100%;
      padding: 8px 12px 8px 36px;
      border-radius: 8px;
      border: 1px solid var(--border2);
      background: var(--bg);
      font-size: 13px;
      font-family: var(--font-body);
      color: var(--text);
      outline: none;
      transition: border-color 0.15s;
    }
    .search-box input:focus { border-color: var(--brand); }
    .search-box input::placeholder { color: var(--text3); }

    .search-icon {
      position: absolute;
      left: 11px; top: 50%;
      transform: translateY(-50%);
      font-size: 14px;
      color: var(--text3);
      pointer-events: none;
    }

    .conversations {
      flex: 1;
      overflow-y: auto;
      padding: 0.5rem 0;
    }

    .conversations::-webkit-scrollbar { width: 4px; }
    .conversations::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 4px; }

    .convo-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 10px 1.25rem;
      cursor: pointer;
      transition: background 0.13s;
      position: relative;
    }
    .convo-item:hover { background: var(--bg); }
    .convo-item.active { background: var(--brand-light); }
    .convo-item.active .convo-name { color: var(--brand); }

    .convo-avatar {
      width: 46px; height: 46px;
      border-radius: 50%;
      background: var(--brand-light);
      border: 2px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-size: 15px; font-weight: 600; color: var(--brand);
      flex-shrink: 0;
      overflow: hidden;
    }
    .convo-avatar img { width: 100%; height: 100%; object-fit: cover; }

    .convo-body { flex: 1; min-width: 0; }

    .convo-top {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      margin-bottom: 2px;
    }

    .convo-name {
      font-size: 14px;
      font-weight: 600;
      color: var(--text);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .convo-time {
      font-size: 11px;
      color: var(--text3);
      flex-shrink: 0;
    }

    .convo-preview {
      font-size: 13px;
      color: var(--text3);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .unread-badge {
      position: absolute;
      right: 1.25rem;
      bottom: 13px;
      background: var(--brand);
      color: #fff;
      font-size: 10px;
      font-weight: 600;
      padding: 2px 6px;
      border-radius: 10px;
      min-width: 18px;
      text-align: center;
    }

    .convo-skill-pill {
      display: inline-block;
      font-size: 10px;
      padding: 1px 7px;
      border-radius: 10px;
      background: var(--accent-light);
      color: #b36a1a;
      border: 1px solid rgba(244,162,74,0.3);
      margin-top: 2px;
    }

    /* ?? EMPTY STATE ?? */
    .empty-state {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: var(--text3);
      gap: 12px;
      text-align: center;
      padding: 2rem;
    }

    .empty-icon {
      font-size: 48px;
      line-height: 1;
    }

    .empty-title {
      font-family: var(--font-display);
      font-size: 20px;
      color: var(--text2);
    }

    .empty-sub {
      font-size: 13px;
      color: var(--text3);
      max-width: 260px;
    }

    /* ?? CHAT AREA ?? */
    .chat-area {
      flex: 1;
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow: hidden;
      background: var(--bg);
    }

    /* Chat header */
    .chat-header {
      background: var(--surface);
      border-bottom: 1px solid var(--border);
      padding: 0 1.5rem;
      height: 64px;
      display: flex;
      align-items: center;
      gap: 12px;
      flex-shrink: 0;
    }

    .chat-header-avatar {
      width: 40px; height: 40px;
      border-radius: 50%;
      background: var(--brand-light);
      border: 2px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-size: 14px; font-weight: 600; color: var(--brand);
      flex-shrink: 0;
      overflow: hidden;
    }
    .chat-header-avatar img { width: 100%; height: 100%; object-fit: cover; }

    .chat-header-info { flex: 1; min-width: 0; }

    .chat-header-name {
      font-size: 15px;
      font-weight: 600;
      color: var(--text);
    }

    .chat-header-status {
      font-size: 12px;
      color: var(--brand);
      display: flex;
      align-items: center;
      gap: 5px;
    }

    .status-dot {
      width: 7px; height: 7px;
      border-radius: 50%;
      background: var(--brand);
      display: inline-block;
    }

    .chat-header-actions {
      display: flex;
      gap: 6px;
    }

    .icon-btn {
      width: 36px; height: 36px;
      border-radius: 8px;
      border: 1px solid var(--border2);
      background: none;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      font-size: 16px;
      color: var(--text2);
      transition: background 0.13s;
    }
    .icon-btn:hover { background: var(--surface2); color: var(--text); }

    /* Messages */
    .messages-area {
      flex: 1;
      overflow-y: auto;
      padding: 1.25rem 1.5rem;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .messages-area::-webkit-scrollbar { width: 4px; }
    .messages-area::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 4px; }

    .date-divider {
      text-align: center;
      font-size: 11px;
      color: var(--text3);
      margin: 12px 0 6px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .date-divider::before,
    .date-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: var(--border);
    }

    .msg-row {
      display: flex;
      align-items: flex-end;
      gap: 8px;
      margin-bottom: 2px;
    }

    .msg-row.sent { flex-direction: row-reverse; }

    .msg-avatar {
      width: 28px; height: 28px;
      border-radius: 50%;
      background: var(--brand-light);
      border: 1.5px solid var(--brand-mid);
      display: flex; align-items: center; justify-content: center;
      font-size: 10px; font-weight: 600; color: var(--brand);
      flex-shrink: 0;
      overflow: hidden;
    }
    .msg-avatar img { width: 100%; height: 100%; object-fit: cover; }

    .msg-row.sent .msg-avatar {
      background: var(--accent-light);
      border-color: var(--accent);
      color: #b36a1a;
    }

    .bubble {
      max-width: 68%;
      padding: 9px 13px;
      border-radius: 14px;
      font-size: 14px;
      line-height: 1.55;
      color: var(--text);
      background: var(--surface);
      border: 1px solid var(--border);
      border-bottom-left-radius: 4px;
      position: relative;
    }

    .msg-row.sent .bubble {
      background: var(--brand);
      color: #fff;
      border: none;
      border-bottom-left-radius: 14px;
      border-bottom-right-radius: 4px;
    }

    .bubble-time {
      font-size: 10px;
      color: var(--text3);
      margin-top: 3px;
      text-align: right;
    }

    .msg-row.sent .bubble-time { color: rgba(255,255,255,0.65); }

    .read-tick {
      color: var(--accent);
      font-size: 11px;
    }

    /* Typing indicator */
    .typing-indicator .bubble {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 10px 14px;
    }

    .typing-dot {
      width: 7px; height: 7px;
      border-radius: 50%;
      background: var(--text3);
      animation: bounce 1.2s infinite ease-in-out;
    }
    .typing-dot:nth-child(2) { animation-delay: 0.2s; }
    .typing-dot:nth-child(3) { animation-delay: 0.4s; }

    @keyframes bounce {
      0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
      40%            { transform: translateY(-5px); opacity: 1; }
    }

    /* Skill exchange badge in chat */
    .skill-exchange-msg {
      align-self: center;
      background: var(--accent-light);
      border: 1px solid rgba(244,162,74,0.35);
      border-radius: 10px;
      padding: 10px 16px;
      font-size: 13px;
      color: #7d4c10;
      text-align: center;
      margin: 10px 0;
      max-width: 80%;
    }

    /* Input bar */
    .input-bar {
      background: var(--surface);
      border-top: 1px solid var(--border);
      padding: 0.9rem 1.5rem;
      display: flex;
      align-items: flex-end;
      gap: 10px;
      flex-shrink: 0;
    }

    .input-bar textarea {
      flex: 1;
      padding: 10px 14px;
      border-radius: 22px;
      border: 1px solid var(--border2);
      background: var(--bg);
      font-size: 14px;
      font-family: var(--font-body);
      color: var(--text);
      resize: none;
      outline: none;
      max-height: 120px;
      min-height: 42px;
      overflow-y: auto;
      line-height: 1.5;
      transition: border-color 0.15s;
    }
    .input-bar textarea:focus { border-color: var(--brand); }
    .input-bar textarea::placeholder { color: var(--text3); }

    .send-btn {
      width: 42px; height: 42px;
      border-radius: 50%;
      background: var(--brand);
      border: none;
      color: #fff;
      font-size: 18px;
      cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
      transition: background 0.15s, transform 0.1s;
    }
    .send-btn:hover { background: #155c3e; }
    .send-btn:active { transform: scale(0.94); }

    .attach-btn {
      width: 42px; height: 42px;
      border-radius: 50%;
      background: var(--surface2);
      border: 1px solid var(--border2);
      color: var(--text2);
      font-size: 18px;
      cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
      transition: background 0.13s;
    }
    .attach-btn:hover { background: var(--brand-light); color: var(--brand); }

    /* ?? NO CHAT SELECTED ?? */
    .no-chat {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 14px;
      color: var(--text3);
      text-align: center;
      padding: 2rem;
      background: var(--bg);
    }

    .no-chat-icon { font-size: 56px; line-height: 1; }

    .no-chat-title {
      font-family: var(--font-display);
      font-size: 22px;
      color: var(--text2);
    }

    .no-chat-sub {
      font-size: 14px;
      color: var(--text3);
      max-width: 300px;
    }

    /* ?? TOAST ?? */
    #toast {
      position: fixed;
      bottom: 28px; left: 50%;
      transform: translateX(-50%) translateY(10px);
      background: #1c1c1a;
      color: #fff;
      padding: 11px 22px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 500;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.25s, transform 0.25s;
      white-space: nowrap;
      z-index: 9999;
    }
    #toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }

    /* ?? RESPONSIVE ?? */
    @media (max-width: 720px) {
      nav { padding: 0 1rem; }
      .nav-links { display: none; }
      .sidebar { width: 100%; position: fixed; bottom: 0; left: 0; right: 0; top: var(--nav-height); z-index: 50; }
      .sidebar.hidden-mobile { display: none; }
      .chat-area { width: 100%; }
      .chat-area.hidden-mobile { display: none; }
    }

    /* Fade-in for new messages */
    @keyframes msgIn {
      from { opacity: 0; transform: translateY(6px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .msg-row { animation: msgIn 0.2s ease both; }
  </style>
</head>
<body>

<div id="toast"></div>

<!-- ?? NAV ?? -->
<nav>
  <a class="nav-logo" href="#">StudentSkillExchange</a>

  <div class="nav-links">
    <a class="nav-link" href="profile.jsp">&#128221; My Profile</a>
    <a class="nav-link" href="BrowseServlet">&#128269; Browse</a>
    <div style="position:relative;display:inline-flex;">
  <a class="nav-link" href="notifications.jsp" id="notifNavBtn">
    &#128276; Notifications
  </a>
  <span id="navNotifBadge" style="
    display:none;
    position:absolute;
    top:4px; right:6px;
    background:#e05555;
    color:white;
    font-size:10px;
    font-weight:700;
    min-width:17px; height:17px;
    border-radius:10px;
    align-items:center;
    justify-content:center;
    padding:0 4px;
    pointer-events:none;
  ">0</span>
</div>

    <a class="nav-link active" href="messages.jsp">&#128172; Messages</a>
  </div>

  <div class="nav-right">
    <div class="nav-avatar" title="My Profile"><%= initials.toUpperCase() %></div>
    <a href="LogoutServlet" class="logout-btn">Log out</a>
  </div>
</nav>

<!-- ?? MAIN LAYOUT ?? -->
<div class="chat-layout">

  <!-- ?? SIDEBAR ?? -->
  <div class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.75rem;">
        <div class="sidebar-title" style="margin-bottom:0;">Messages</div>
        <button onclick="openGroupModal()"
                style="display:flex;align-items:center;gap:5px;padding:6px 12px;
                       border-radius:8px;border:1px solid var(--border2);background:none;
                       font-size:12px;font-weight:500;color:var(--brand);cursor:pointer;
                       font-family:var(--font-body);transition:background .15s;"
                onmouseover="this.style.background='var(--brand-light)'"
                onmouseout="this.style.background='none'">
          &#128101; New Group
        </button>
      </div>
    </div>
    <div class="conversations" id="convosContainer">
      <!-- Populated by JS -->
    </div>
  </div>
  <!-- CHAT AREA -->
  <div class="chat-area" id="chatArea">
    <!-- No-chat placeholder (shown by default) -->
    <div class="no-chat" id="noChatPlaceholder">
      <div class="no-chat-icon">&#128172;</div>
      <div class="no-chat-title">Your Messages</div>
      <div class="no-chat-sub">Select a conversation to start chatting, or find someone on Browse to exchange skills with.</div>
    </div>

    <!-- Active chat (hidden until a convo is selected) -->
    <div id="activeChat" style="display:none; flex-direction:column; height:100%; overflow:hidden; flex:1;">

      <!-- Chat header -->
      <div class="chat-header" id="chatHeader">
        <div class="chat-header-avatar" id="chatHeaderAvatar">?</div>
        <div class="chat-header-info">
          <div class="chat-header-name" id="chatHeaderName">Name</div>
          <div class="chat-header-status" id="chatHeaderStatus">
            <span class="status-dot"></span> Online
          </div>
        </div>
        <div class="chat-header-actions">
          <button class="icon-btn" title="View profile" onclick="viewProfile()">&#128100;</button>
          <button class="icon-btn" title="Skill exchange info" onclick="showExchangeInfo()">&#128203;</button>
        </div>
      </div>

      <!-- Messages scroll area -->
      <div class="messages-area" id="messagesArea"></div>

      <!-- Input bar -->
      <div class="input-bar">
        <button class="attach-btn" title="Attach file" onclick="showToast('File attachments coming soon!')">&#128206;</button>
        <textarea
          id="msgInput"
          placeholder="Type a message..."
          rows="1"
          onkeydown="handleEnter(event)"
          oninput="autoResize(this)"
        ></textarea>
        <button class="send-btn" onclick="sendMessage()" title="Send">&#10148;</button>
      </div>
    </div>

  </div><!-- end chat-area -->
</div>

<script>
    var lastRenderedHTML = "";
const CURRENT_USER = {
  name:     '<%= name.replace("'", "\\'") %>',
  initials: '<%= initials.toUpperCase() %>',
  id:       <%= user != null ? user.getId() : 0 %>
};

var activeChatId   = null;   // user ID (DM) or group ID (group)
var activeConvo    = null;   // { id, name, initials, isGroup }
var pollInterval   = null;
var conversations  = [];     // DMs
var groups         = [];     // groups
var allUsers       = [];     // for member picker in create-group modal

function escHtml(str) {
  if (!str) return "";
  return String(str).replace(/[&<>"']/g, function(c) {
    return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];
  });
}

// ?? LOAD EVERYTHING ???????????????????????????????????????????????????????
function loadAll() {
  loadConversations();
  loadGroups();
}

function loadConversations() {
  fetch("MessageServlet")
    .then(function(r) { return r.json(); })
    .then(function(data) { conversations = data; renderSidebar(); })
    .catch(function(e) { console.error("Load DMs error", e); });
}

function loadGroups() {
  fetch("GroupServlet")
    .then(function(r) { return r.json(); })
    .then(function(data) { groups = data; renderSidebar(); })
    .catch(function(e) { console.error("Load groups error", e); });
}

// ?? RENDER SIDEBAR ????????????????????????????????????????????????????????
function renderSidebar(filter) {
  filter = (filter || "").toLowerCase();
  var container = document.getElementById("convosContainer");
  if (!container) return;

  // Merge DMs and groups, sort by time
  var all = conversations.map(function(c) {
    return { id: c.id, name: c.name, initials: c.initials,
             lastMsg: c.lastMsg, time: c.time, unread: c.unread, isGroup: false };
  }).concat(groups.map(function(g) {
    var initials = g.name.trim().split(/\s+/).map(function(w) {
      return w.charAt(0);
    }).join("").substring(0, 2).toUpperCase();
    return { id: g.id, name: g.name, initials: initials,
             lastMsg: g.lastMsg, time: g.time, unread: g.unread, isGroup: true };
  }));

  var filtered = filter
    ? all.filter(function(c) { return c.name.toLowerCase().indexOf(filter) !== -1; })
    : all;

  if (filtered.length === 0) {
    container.innerHTML =
      '<div class="empty-state">' +
        '<div class="empty-icon">&#128172;</div>' +
        '<div class="empty-title">No conversations yet</div>' +
        '<div class="empty-sub">Browse students and send a message to get started.</div>' +
      '</div>';
    return;
  }

  container.innerHTML = filtered.map(function(c) {
    var isActive    = !c.isGroup && c.id === activeChatId && activeConvo && !activeConvo.isGroup;
    var isActiveGrp = c.isGroup  && c.id === activeChatId && activeConvo && activeConvo.isGroup;
    var activeClass = (isActive || isActiveGrp) ? "active" : "";
    var unreadBadge = c.unread > 0
      ? '<div class="unread-badge">' + c.unread + '</div>' : "";
    var groupIcon   = c.isGroup
      ? '<span style="font-size:10px;background:var(--accent-light);color:#b36a1a;' +
        'padding:1px 6px;border-radius:8px;margin-left:4px;">group</span>' : "";
    var clickFn     = c.isGroup
      ? 'openGroupChat(' + c.id + ', \'' + c.name.replace(/'/g, "\\'") + '\')'
      : 'openChat(' + c.id + ', \'' + c.name.replace(/'/g, "\\'") + '\', \'' + c.initials + '\')';

    return '<div class="convo-item ' + activeClass + '" onclick="' + clickFn + '">' +
             '<div class="convo-avatar">' + escHtml(c.initials) + '</div>' +
             '<div class="convo-body">' +
               '<div class="convo-top">' +
                 '<span class="convo-name">' + escHtml(c.name) + groupIcon + '</span>' +
                 '<span class="convo-time">' + escHtml(c.time) + '</span>' +
               '</div>' +
               '<div class="convo-preview">' + escHtml(c.lastMsg) + '</div>' +
             '</div>' +
             unreadBadge +
           '</div>';
  }).join("");
}

// ?? OPEN DM CHAT ??????????????????????????????????????????????????????????
function openChat(otherId, otherName, otherInitials) {
  activeChatId = otherId;
  activeConvo  = { id: otherId, name: otherName, initials: otherInitials, isGroup: false };
  lastRenderedHTML = "";

  conversations.forEach(function(c) { if (c.id === otherId) c.unread = 0; });
  renderSidebar();
  showChatArea(otherName, otherInitials);
  loadMessages();

  if (pollInterval) clearInterval(pollInterval);
  pollInterval = setInterval(loadMessages, 3000);
}

// ?? OPEN GROUP CHAT ???????????????????????????????????????????????????????
function openGroupChat(groupId, groupName) {
  var initials = groupName.trim().split(/\s+/).map(function(w) {
    return w.charAt(0);
  }).join("").substring(0, 2).toUpperCase();

  activeChatId = groupId;
  activeConvo  = { id: groupId, name: groupName, initials: initials, isGroup: true };
  lastRenderedHTML = "";

  groups.forEach(function(g) { if (g.id === groupId) g.unread = 0; });
  renderSidebar();
  showChatArea(groupName, initials, true);
  loadMessages();

  if (pollInterval) clearInterval(pollInterval);
  pollInterval = setInterval(loadMessages, 3000);
}

function showChatArea(name, initials, isGroup) {
  document.getElementById("noChatPlaceholder").style.display  = "none";
  document.getElementById("activeChat").style.display         = "flex";
  document.getElementById("chatHeaderAvatar").textContent     = initials;
  document.getElementById("chatHeaderName").textContent       = name;
  var statusEl = document.getElementById("chatHeaderStatus");
  if (statusEl) statusEl.innerHTML = isGroup
    ? '<span style="font-size:12px;color:var(--text3);">Group conversation</span>'
    : '';
}

// ?? LOAD MESSAGES (DM or Group) ???????????????????????????????????????????
function loadMessages() {
  if (!activeChatId || !activeConvo) return;

  var url = activeConvo.isGroup
    ? "GroupServlet?groupId=" + activeChatId
    : "MessageServlet?otherId=" + activeChatId;

  fetch(url)
    .then(function(r) { return r.json(); })
    .then(function(msgs) { renderMessages(msgs); })
    .catch(function(e) { console.error("Load messages error", e); });
}

function formatDateLabel(dateStr) {
  if (!dateStr) return "Today";
  var d = new Date(dateStr);
  var today = new Date();
  var yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === yesterday.toDateString()) return "Yesterday";
  return d.toLocaleDateString(undefined,
    { weekday:'long', month:'short', day:'numeric' });
}

// ?? RENDER MESSAGES ???????????????????????????????????????????????????????
function renderMessages(msgs) {
  var area = document.getElementById("messagesArea");
  if (!area || !activeConvo) return;

  if (msgs.length === 0) {
    area.innerHTML =
      '<div style="text-align:center;color:var(--text3);font-size:13px;margin-top:2rem;">' +
        'No messages yet ? say hello!' +
      '</div>';
    return;
  }

  var html = "";
  var lastDate = null;
  msgs.forEach(function(msg) {
    var msgDate = msg.date
      ? new Date(msg.date).toDateString()
      : new Date().toDateString();
    if (msgDate !== lastDate) {
      html += '<div class="date-divider">'
            + formatDateLabel(msg.date)
            + '</div>';
      lastDate = msgDate;
    }
    var isSent   = msg.from === "me";
    var av       = isSent ? CURRENT_USER.initials : escHtml(activeConvo.initials);
    var rowClass = isSent ? "msg-row sent" : "msg-row";
    var ticks    = (!activeConvo.isGroup && isSent)
      ? (msg.read
          ? '<span style="color:#4fc3f7;font-size:12px;">&#10003;&#10003;</span>'
          : '<span style="color:#aaa;font-size:12px;">&#10003;</span>')
      : "";
    // Show sender name in group chats for received messages
    var senderLabel = (activeConvo.isGroup && !isSent && msg.senderName)
      ? '<div style="font-size:11px;color:var(--brand);font-weight:600;margin-bottom:2px;">' +
        escHtml(msg.senderName) + '</div>'
      : "";

    html += '<div class="' + rowClass + '">' +
              '<div class="msg-avatar">' + av + '</div>' +
              '<div>' +
                senderLabel +
                '<div class="bubble">' + escHtml(msg.text) + '</div>' +
                '<div class="bubble-time">' + escHtml(msg.time) + ' ' + ticks + '</div>' +
              '</div>' +
            '</div>';
  });

  var wasAtBottom = area.scrollHeight - area.scrollTop - area.clientHeight < 80;
  if (html !== lastRenderedHTML) {
    area.innerHTML = html;
    lastRenderedHTML = html;
}
  if (wasAtBottom) area.scrollTop = area.scrollHeight;
}

// ?? SEND MESSAGE (DM or Group) ????????????????????????????????????????????
function sendMessage() {
  var input = document.getElementById("msgInput");
  var text  = input.value.trim();
  if (!text || activeChatId === null || !activeConvo) return;

  input.value = "";
  input.style.height = "auto";

  var url, body;
  if (activeConvo.isGroup) {
    url  = "GroupServlet";
    body = "action=send&groupId=" + activeChatId + "&message=" + encodeURIComponent(text);
  } else {
    url  = "MessageServlet";
    body = "receiverId=" + activeChatId + "&message=" + encodeURIComponent(text);
  }

  fetch(url, {
    method:  "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body:    body
  })
  .then(function(r) { return r.json(); })
  .then(function(res) {
    if (res.success) {
      loadMessages();
      loadAll();
    } else {
      showToast(res.message || "Could not send message");
    }
  })
  .catch(function(e) { console.error("Send error", e); });
}

// ?? CREATE GROUP MODAL ????????????????????????????????????????????????????
function openGroupModal() {
  document.getElementById("groupModal").style.display = "flex";
  document.getElementById("groupNameInput").value = "";

  // Load all users for the member picker
  fetch("BrowseServlet?json=true")
    .then(function(r) { return r.json(); })
    .then(function(users) {
      allUsers = users;
      renderMemberPicker(users);
    })
    .catch(function() {
      // If BrowseServlet doesn't support JSON yet, show a fallback message
      document.getElementById("membersList").innerHTML =
        '<p style="font-size:13px;color:var(--text3);">Could not load users. See setup note.</p>';
    });
}

function closeGroupModal() {
  document.getElementById("groupModal").style.display = "none";
}

function renderMemberPicker(users) {
  var list = document.getElementById("membersList");
  if (!users || users.length === 0) {
    list.innerHTML = '<p style="font-size:13px;color:var(--text3);">No other users found.</p>';
    return;
  }
  list.innerHTML = users.map(function(u) {
    return '<label style="display:flex;align-items:center;gap:10px;padding:8px 10px;' +
           'border-radius:8px;cursor:pointer;border:1px solid var(--border);' +
           'background:var(--bg);">' +
             '<input type="checkbox" value="' + u.id + '" style="width:16px;height:16px;' +
             'accent-color:var(--brand);">' +
             '<span style="font-size:14px;color:var(--text);">' + escHtml(u.name) + '</span>' +
           '</label>';
  }).join("");
}

function submitCreateGroup() {
  var groupName = document.getElementById("groupNameInput").value.trim();
  if (!groupName) { showToast("Please enter a group name"); return; }

  var checked = document.querySelectorAll("#membersList input[type=checkbox]:checked");
  var memberIds = Array.from(checked).map(function(cb) { return cb.value; }).join(",");

  fetch("GroupServlet", {
    method:  "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body:    "action=create&groupName=" + encodeURIComponent(groupName) +
             "&memberIds=" + encodeURIComponent(memberIds)
  })
  .then(function(r) { return r.json(); })
  .then(function(res) {
    if (res.success) {
      closeGroupModal();
      showToast("Group \"" + res.groupName + "\" created!");
      fetch("GroupServlet")
        .then(function(r) { return r.json(); })
        .then(function(data) {
          groups = data;
          renderSidebar();
          openGroupChat(res.groupId, res.groupName);
        });
    } else {
      showToast(res.message || "Could not create group");
    }
  })
  .catch(function() { showToast("Network error"); });
}

// ?? HELPERS ???????????????????????????????????????????????????????????????
function filterConvos(val)  { renderSidebar(val); }
function handleEnter(e)     { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }
function autoResize(el)     { el.style.height = "auto"; el.style.height = el.scrollHeight + "px"; }
function viewProfile()      { showToast("Profile view coming soon!"); }
function showExchangeInfo() { showToast("Skill exchange details coming soon!"); }

function showToast(msg) {
  var t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(function() { t.classList.remove("show"); }, 3000);
}

// ?? INIT ??????????????????????????????????????????????????????????????????
document.addEventListener("DOMContentLoaded", function() {
  loadAll();
  setInterval(loadAll, 10000);

  // Auto-open if coming from browse page
  var params      = new URLSearchParams(window.location.search);
  var startChatId = params.get("startChat");
  var startName   = params.get("name") || "User";
  if (startChatId) {
    var parts    = startName.trim().split(/\s+/);
    var initials = parts.length >= 2
      ? (parts[0].charAt(0) + parts[parts.length-1].charAt(0)).toUpperCase()
      : parts[0].charAt(0).toUpperCase();
    setTimeout(function() { openChat(parseInt(startChatId), startName, initials); }, 300);
  }
});

</script>
<!-- CREATE GROUP MODAL -->
<div id="groupModal" style="display:none;position:fixed;inset:0;z-index:200;
     background:rgba(0,0,0,0.45);align-items:center;justify-content:center;">
  <div style="background:var(--surface);border-radius:var(--radius);padding:1.75rem;
              width:420px;max-width:90vw;box-shadow:0 16px 48px rgba(0,0,0,0.18);">
    <h2 style="font-family:var(--font-display);font-size:20px;margin-bottom:1.25rem;
               color:var(--text);">Create Group</h2>

    <label style="font-size:12px;font-weight:600;color:var(--text3);
                  text-transform:uppercase;letter-spacing:.05em;">Group Name</label>
    <input id="groupNameInput" type="text" placeholder="e.g. Design Squad"
           style="width:100%;margin:6px 0 1rem;padding:10px 13px;border-radius:8px;
                  border:1px solid var(--border2);background:var(--bg);
                  font-size:14px;font-family:var(--font-body);color:var(--text);outline:none;">

    <label style="font-size:12px;font-weight:600;color:var(--text3);
                  text-transform:uppercase;letter-spacing:.05em;">Add Members</label>
    <div id="membersList" style="margin:8px 0 1.25rem;display:flex;flex-direction:column;
                                  gap:8px;max-height:220px;overflow-y:auto;"></div>

    <div style="display:flex;gap:10px;justify-content:flex-end;">
      <button onclick="closeGroupModal()"
              style="padding:9px 18px;border-radius:8px;border:1px solid var(--border2);
                     background:none;font-size:13px;font-family:var(--font-body);
                     color:var(--text2);cursor:pointer;">Cancel</button>
      <button onclick="submitCreateGroup()"
              style="padding:9px 18px;border-radius:8px;border:none;background:var(--brand);
                     color:#fff;font-size:13px;font-weight:500;font-family:var(--font-body);
                     cursor:pointer;">Create Group</button>
    </div>
  </div>
</div>

</body>
</html>
