<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    // SIMULATED user for demo
    class User {
        String name = "Student";
        String email = "student@example.com";
        String role = "Student";
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getRole() { return role; }
    }

    User user = (User) session.getAttribute("user");
    if (user == null) {
        user = new User(); // simulate logged in user
    }

    // Simulate form submission success
    String submitted = request.getParameter("submitted");
%>

<html>
<head>
    <title>Add Skill</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --primary: #2e7d32;
            --secondary: #66bb6a;
            --accent: #f9a825;
            --background: #f4f6f9;
        }

        body {
            font-family: Arial, sans-serif;
            background: var(--background);
            margin: 0;
        }

        .navbar {
            background: var(--primary);
            padding: 15px;
            text-align: center;
        }

        .navbar a {
            color: #fff;
            margin: 0 15px;
            text-decoration: none;
            font-weight: bold;
        }

        .navbar a:hover { color: var(--accent); }

        .hero {
            background: linear-gradient(to right, var(--primary), var(--secondary));
            color: #fff;
            padding: 50px 20px;
            text-align: center;
        }

        .hero h1 { margin-bottom: 10px; }
        .hero p { font-size: 1.1em; }

        .form-card {
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            width: 400px;
            margin: 40px auto;
        }

        .form-card h3 { color: var(--primary); margin-bottom: 20px; text-align: center; }
        label { display: block; margin: 10px 0 5px; font-weight: bold; color: #555; }
        input[type="text"], textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px; }
        textarea { resize: vertical; min-height: 80px; }
        input[type="submit"] {
            margin-top: 20px;
            padding: 12px;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
        }
        input[type="submit"]:hover { background: var(--secondary); }

        .success {
            text-align: center;
            color: green;
            font-weight: bold;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <a href="home.jsp"><i class="fas fa-home"></i> Dashboard</a>
        <a href="profile.jsp"><i class="fas fa-user"></i> My Profile</a>
        <a href="skills.jsp"><i class="fas fa-lightbulb"></i> Browse Skills</a>
        <a href="index.jsp"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <!-- Hero Section -->
    <div class="hero">
        <h1>Add a New Skill</h1>
        <p>Share your talent with the community, <%= user.getName() %>.</p>
    </div>

    <!-- Form Card -->
    <div class="form-card">
        <h3><i class="fas fa-plus"></i> Post Your Skill</h3>

        <% if (submitted != null) { %>
            <div class="success">Skill successfully added!</div>
        <% } %>

        <!-- SIMULATED FORM -->
        <form action="addSkill.jsp" method="get">
            <input type="hidden" name="submitted" value="1">

            <label for="name">Skill Name</label>
            <input type="text" id="name" name="name" required>

            <label for="description">Description</label>
            <textarea id="description" name="description" required></textarea>

            <input type="submit" value="Add Skill">
        </form>
    </div>
</body>
</html>