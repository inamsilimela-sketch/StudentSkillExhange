<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
if ("invalidEmail".equals(request.getParameter("error"))) {
%>
<p style="color:red; text-align:center;">Only UMP email addresses are allowed!</p>
<%
}
if ("passwordMismatch".equals(request.getParameter("error"))) {
%>
<p style="color:red; text-align:center;">Passwords do not match!</p>
<%
}
if ("weakPassword".equals(request.getParameter("error"))) {
%>
<p style="color:red; text-align:center;">Password must be at least 8 characters with 1 number, 1 uppercase letter, and 1 special character (@!#$%* etc).</p>
<%
}
%>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
    :root {
        --primary: #2e7d32;
        --secondary: #66bb6a;
        --danger: #c0392b;
        --success: #27ae60;
    }

    body {
        font-family: Arial, sans-serif;
        background: #f4f6f9;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .container {
        background: #fff;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        width: 380px;
    }

    h2 {
        text-align: center;
        color: var(--primary);
    }

    form {
        display: flex;
        flex-direction: column;
    }

    label {
        margin: 10px 0 5px;
        font-weight: bold;
        color: #555;
    }

    input[type="text"],
    input[type="email"],
    input[type="password"],
    select {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
        width: 100%;
    }

    input:focus,
    select:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 5px rgba(46, 125, 50, 0.3);
    }

    select {
        appearance: none;
        background: #fff url("data:image/svg+xml;utf8,<svg fill='%23666' height='20' viewBox='0 0 24 24' width='20' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/></svg>") no-repeat right 10px center;
        background-size: 16px;
        cursor: pointer;
    }

    input[type="submit"] {
        margin-top: 20px;
        padding: 12px;
        background: var(--primary);
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
    }

    input[type="submit"]:hover {
        background: var(--secondary);
    }

    .message {
        text-align: center;
        margin-bottom: 10px;
        font-size: 14px;
        color: #555;
    }

    .back {
        display: block;
        text-align: center;
        margin-top: 15px;
        text-decoration: none;
        color: #2e7d32;
        font-weight: bold;
    }

    /* Password strength meter */
    .password-field {
        position: relative;
    }
    .toggle-password {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        color: #999;
        font-size: 14px;
    }
    .requirements {
        font-size: 11px;
        color: #999;
        margin-top: 4px;
    }
    .req-item {
        display: flex;
        align-items: center;
        gap: 4px;
    }
    .req-item.met {
        color: var(--success);
    }
    .req-item.unmet {
        color: var(--danger);
    }
    .match-indicator {
        font-size: 12px;
        margin-top: 4px;
    }
    .match-yes { color: var(--success); }
    .match-no { color: var(--danger); }
    </style>
</head>

<body>
    <div class="container">
        <h2><i class="fas fa-user-plus"></i> Create Profile</h2>

        <div class="message">
            Fill in your details to create an account
        </div>

        <form action="RegisterServlet" method="post" onsubmit="return validateForm()">

            <label>Full Name</label>
            <input type="text" name="name" id="name" required>

            <label>Email</label>
            <input type="email" name="email" id="email" required>

            <label>Password</label>
            <div class="password-field">
                <input type="password" name="password" id="password" required oninput="checkStrength()">
                <span class="toggle-password" onclick="togglePassword('password')">👁</span>
            </div>
            <div class="requirements" id="requirements" style="display:none;">
                <div class="req-item unmet" id="req-length">✗ At least 8 characters</div>
                <div class="req-item unmet" id="req-upper">✗ At least 1 uppercase letter</div>
                <div class="req-item unmet" id="req-number">✗ At least 1 number</div>
                <div class="req-item unmet" id="req-special">✗ At least 1 special character (@!#$%* etc)</div>
            </div>

            <label>Confirm Password</label>
            <div class="password-field">
                <input type="password" name="confirmPassword" id="confirmPassword" required oninput="checkMatch()">
                <span class="toggle-password" onclick="togglePassword('confirmPassword')">👁</span>
            </div>
            <div class="match-indicator" id="matchMsg"></div>

            <label>Role</label>
            <select name="role" required>
              <option value="" disabled selected>Select Role</option>
              <option value="student">Student</option>
              <option value="tutor">Tutor</option>
            </select>

            <input type="submit" value="Register & Continue">
        </form>

        <a href="index.jsp" class="back">← Back to Home</a>
    </div>

    <script>
    function checkStrength() {
    var pwd = document.getElementById('password').value;
    var reqDiv = document.getElementById('requirements');
    
    // Show requirements only when user starts typing
    if (pwd.length > 0) {
        reqDiv.style.display = 'block';
    } else {
        reqDiv.style.display = 'none';
    }
        var hasLength = pwd.length >= 8;
        var hasUpper = /[A-Z]/.test(pwd);
        var hasNumber = /[0-9]/.test(pwd);
        var hasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pwd);

        updateReq('req-length', hasLength);
        updateReq('req-upper', hasUpper);
        updateReq('req-number', hasNumber);
        updateReq('req-special', hasSpecial);

        checkMatch();
    }

    function updateReq(id, met) {
        var el = document.getElementById(id);
        if (met) {
            el.className = 'req-item met';
            el.innerHTML = '✓ ' + el.innerHTML.substring(2);
        } else {
            el.className = 'req-item unmet';
            el.innerHTML = '✗ ' + el.innerHTML.substring(2);
        }
    }

    function checkMatch() {
        var pwd = document.getElementById('password').value;
        var confirm = document.getElementById('confirmPassword').value;
        var msg = document.getElementById('matchMsg');

        if (confirm.length === 0) {
            msg.textContent = '';
            msg.className = 'match-indicator';
        } else if (pwd === confirm) {
            msg.textContent = '✓ Passwords match';
            msg.className = 'match-indicator match-yes';
        } else {
            msg.textContent = '✗ Passwords do not match';
            msg.className = 'match-indicator match-no';
        }
    }

    function togglePassword(fieldId) {
        var field = document.getElementById(fieldId);
        field.type = field.type === 'password' ? 'text' : 'password';
    }

    function validateForm() {
        var pwd = document.getElementById('password').value;
        var confirm = document.getElementById('confirmPassword').value;

        var hasLength = pwd.length >= 8;
        var hasUpper = /[A-Z]/.test(pwd);
        var hasNumber = /[0-9]/.test(pwd);
        var hasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pwd);

        if (!hasLength || !hasUpper || !hasNumber || !hasSpecial) {
            alert('Password does not meet all requirements. Please check the list below the password field.');
            return false;
        }

        if (pwd !== confirm) {
            alert('Passwords do not match!');
            return false;
        }

        return true;
    }
    </script>
</body>
</html>